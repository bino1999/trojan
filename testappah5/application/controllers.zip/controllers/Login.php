<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->model('login_model');
        $this->login_model->ensure_default_user();
        $this->login_model->ensure_default_role();
    }

    public function index()
    {
        // If already logged in, redirect to dashboard
        if ($this->session->userdata('userid')) {
            redirect('home');
        }
        $this->load->view('auth/login');
    }

    public function login_validation()
    {
        // Set validation rules
        $this->form_validation->set_rules('email', 'Email', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            // Validation failed
            $this->session->set_flashdata('error', validation_errors());
            redirect('login');
        } else {
            // Attempt login
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $login_result = $this->login_model->can_login($email, $password);

            if ($login_result === '') {
                // Successful login
                $user = $this->login_model->get_user_details($this->session->userdata('userid'));


                $this->load->model('systemRolePermissions_model');
                // Get assigned permissions for the role
                $assignedPermissions = $this->systemRolePermissions_model->getPermissionsByRole($user->Role);
                // Extract only permission ID
                $permissions = array_column($assignedPermissions, 'permission_id');

                // Set user session data
                $session_data = [
                    'userid' => $user->UserID,
                    'email' => $user->Email,
                    'uname' => $user->UserName,
                    'fname' => $user->FirstName,
                    'name' => $user->FirstName . ' ' . $user->LastName,
                    'role' => $user->Role,
                    'department' => $user->Department,
                    'isActive' => $user->IsActive,
                    'logged_in' => TRUE,
                    'permissions' => $permissions
                ];
                $this->session->set_userdata($session_data);

                $this->load->model('logs_model');
                $this->logs_model->log_activity('Login', 'Loged In');
                redirect('home');
            } else {
                // Login failed
                $this->session->set_flashdata('error', $login_result);
                redirect('login');
            }
        }
    }

    public function logout()
    {
        // Destroy session
        $this->session->sess_destroy();

        $this->load->model('logs_model');
        $this->logs_model->log_activity('Signout', 'Loged Out');
        redirect('login');
    }


}
