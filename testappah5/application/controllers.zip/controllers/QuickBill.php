<?php
defined('BASEPATH') or exit('No direct script access allowed');

class QuickBill extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('purchase_model');
        $this->load->model('services_model');
        $this->load->model('products_model');
    }

    public function quickBill()
    {
        $data['mainMenuName'] = 'Quick Bill';
        $data['subMenuName'] = 'quick-bill';

        $data['itemBrands'] = $this->services_model->loadItemBrands();
        $data['itemCategories'] = $this->services_model->loadItemCategories();
        $data['suppliers'] = $this->services_model->loadSuppliers();
        //$data['products'] = $this->services_model->loadProducts();
        $data['products'] = $this->services_model->loadAvailablePurchaseProducts();

        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('quick-bill/quick-bill', $data);
        $this->load->view('layout/footer');
    }

    public function quickBillList()
    {
        $data['mainMenuName'] = 'Quick Bill';
        $data['subMenuName'] = 'quick-bill-list';

        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('quick-bill/quick-bill-invoice', $data);
        $this->load->view('layout/footer');
    }

    public function loadQuickBillList()
    {
        $sdate = $this->input->post('sdate');
        $edate = $this->input->post('edate');

        // Load all quick bills within date range
        $this->load->model('QuickBill_model');
        $data['quickBills'] = $this->QuickBill_model->get_all_quick_bills($sdate, $edate);
        $this->load->view('quick-bill/quick-bill-invoice-list', $data);
    }   

    public function loadServiceProductsFilterListByProduct()
    {
        $categoryId = $this->input->post('categoryId');
        $brandId = $this->input->post('brandId');
        $supplierId = $this->input->post('supplierId');
        $data['products'] = $this->services_model->loadAvailablePurchaseProducts(null, $supplierId, $brandId, $categoryId);
        $this->load->view('quick-bill/product-items-filter-list', $data);
    }

    public function addProductToBill()
    {
        $jobId = $this->input->post('jobId');
        $productId = $this->input->post('productID');
        $po_item_id = $this->input->post('po_item_id');
        $quantity = $this->input->post('quantity');
        $discountPercent = $this->input->post('discountPercent');
        $discountAmount = $this->input->post('discountAmount');

        //$productDetails = $this->services_model->loadProducts($productId);
        $productDetails = $this->services_model->loadPurchaseProduct($po_item_id);
        if (empty($productDetails)) {
            echo json_encode(['status' => 'error', 'message' => 'Product not found']);
            return;
        }

        $productPrice = isset($productDetails->sale_price) ? $productDetails->sale_price : 0;
        if ($productPrice <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Product price is invalid']);
            return;
        }

        $discountPercent = floatval($discountPercent);
        $discountAmount = floatval($discountAmount);

        // Apply discount logic: only one type allowed
        if ($discountPercent > 0 && $discountAmount > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Cannot apply both discount percent and discount amount']);
            return;
        }

        if ($discountPercent > 0) {
            $discountAmount = ($totalBeforeDiscount * $discountPercent) / 100;
        } elseif ($discountAmount > 0) {
            $discountPercent = 0;
        } else {
            $discountAmount = 0;
            $discountPercent = 0;
        }

        $product_name = htmlspecialchars($productDetails->product_name, ENT_QUOTES, 'UTF-8');
        $total = ($productPrice - $discountAmount) * $quantity;

        $productItem = [
            'po_item_id'       => $po_item_id,
            'product_id'       => $productId,
            'product_name'     => $product_name,
            'quantity'         => $quantity,
            'unit_price'       => $productPrice,
            'discount_percent' => $discountPercent,
            'discount_amount'  => $discountAmount,
            'total'            => $total
        ];

        // Retrieve existing cart from session
        $cart = $this->session->userdata('pos_cart');
        if (!is_array($cart)) {
            $cart = [];
        }

        $found = false;

        // Retrieve existing cart from session
        if (!is_array($cart)) {
            $cart = [];
        }

        $found = false;

        // Check if product already exists in cart with same price and discount
        foreach ($cart as &$item) {
            if (
                $item['po_item_id'] == $po_item_id &&
                $item['product_id'] == $productId &&
                $item['unit_price'] == $productPrice &&
                $item['discount_percent'] == $discountPercent &&
                $item['discount_amount'] == $discountAmount
            ) {
                $item['quantity'] += $quantity;
                $item['total'] = ($item['unit_price'] * $item['quantity']) - $item['discount_amount'];
                $found = true;
                break;
            }
        }
        unset($item);

        // If not found, add as new item
        if (!$found) {
            $cart[] = [
                'po_item_id'       => $po_item_id,
                'product_id'       => $productId,
                'product_name'     => $productDetails->product_name,
                'quantity'         => $quantity,
                'unit_price'       => $productPrice,
                'discount_percent' => $discountPercent,
                'discount_amount'  => $discountAmount,
                'total'            => ($productPrice - $discountAmount) * $quantity
            ];
        }

        // Save updated cart to session
        $this->session->set_userdata('pos_cart', $cart);
        echo json_encode(['status' => 'success', 'message' => 'Product added to cart successfully']);
    }

    public function loadBillItems()
    {
        $cart = $this->session->userdata('pos_cart');
        if (!is_array($cart)) {
            $cart = [];
        }

        // Calculate cart total
        $total = 0;
        foreach ($cart as $item) {
            $total += $item['total'];
        }

        $data = [
            'cart' => $cart,
            'total' => $total,
            'customers' => $this->products_model->getAllCustomers(),
            'payment_methods' => ['Cash', 'Card', 'Cheque'],
        ];

        $this->load->view('quick-bill/quick-bill-items-list', $data);
    }


    public function deleteCartItem()
    {
        $index = $this->input->post('index');
        $cart = $this->session->userdata('pos_cart');

        if (!is_array($cart) || !isset($cart[$index])) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid cart item index']);
            return;
        }

        unset($cart[$index]);
        // Reindex the array
        $cart = array_values($cart);
        $this->session->set_userdata('pos_cart', $cart);

        echo json_encode(['status' => 'success', 'message' => 'Item removed']);
    }

    public function saveCompletedBill()
    {
        $customerId      = $this->input->post('customerId');
        $paymentMethod   = $this->input->post('paymentMethod');
        $paidAmount      = $this->input->post('paidAmount');
        $cardOrChequeNo  = $this->input->post('cardOrChequeNo');
        $chequeDate      = $this->input->post('chequeDate');
        $bankName        = $this->input->post('bankName');
        $note            = $this->input->post('note');
        $cart            = $this->session->userdata('pos_cart');

        if (empty($cart)) {
            echo json_encode(['status' => 'error', 'message' => 'Cart is empty.']);
            return;
        }

        if ($paymentMethod == 'Card' && (empty($cardOrChequeNo) || empty($bankName))) {
            echo json_encode(['status' => 'error', 'message' => 'Card details & bank required for card payments.']);
            return;
        }

        if ($paymentMethod == 'Cheque' && (empty($cardOrChequeNo) || empty($chequeDate) || empty($bankName))) {
            echo json_encode(['status' => 'error', 'message' => 'Cheque details required for cheque payments.']);
            return;
        }

        //customer>0 for credit
        if (!$customerId> 0 && $paymentMethod == 'Credit') {
            echo json_encode(['status' => 'error', 'message' => 'Please select a customer for credit bill.']);
            return;
        }

        // Calculate totals
        $billAmount = 0;
        foreach ($cart as $item) {
            $billAmount += $item['total'];
        }

        // Save bill
        $billData = [
            'customer_id'       => $customerId,
            'description'       => $note,
            'bill_amount'       => $billAmount,
            'discount_percent'  => 0,
            'discount_amount'   => 0,
            'final_bill_amount' => $billAmount,
            'total_paid'        => $paidAmount,
            'total_balance' => $billAmount - $paidAmount,
            'created_at'        => date('Y-m-d H:i:s'),
            'created_by'        => $this->session->userdata('userid'),
        ];

        $this->db->insert('quick_bill', $billData);
        $billId = $this->db->insert_id();

        foreach ($cart as $item) {
            $itemData = [
                'quick_bill_id'     => $billId,
                'item_id'           => $item['product_id'],
                'po_item_id'        => $item['po_item_id'],
                'quantity'          => $item['quantity'],
                'price'             => $item['unit_price'],
                'discount_percent'  => $item['discount_percent'],
                'discount_amount'   => $item['discount_amount'],
                //'total_price'       => $item['total'],
                'created_at'        => date('Y-m-d H:i:s'),
                'created_by'        => $this->session->userdata('userid'),
            ];
            $this->db->insert('quick_bill_items', $itemData);
        }

        // Save payment info
        $paymentData = [
            'quick_bill_id'      => $billId,
            'paid_amount'        => $paidAmount,
            'payment_date'       => date('Y-m-d H:i:s'),
            'payment_method'     => $this->input->post('paymentMethod'),
            'card_or_cheque_no'  => $this->input->post('cardOrChequeNo') ?: null,
            'cheque_date'        => $this->input->post('chequeDate') ?: null,
            'bank_name'          => $this->input->post('bankName') ?: null,
            'note'               => $this->input->post('note') ?: null,
            'created_by'         => $this->session->userdata('userid'),
            'created_at'         => date('Y-m-d H:i:s'),
        ];

        $paymentData2 = [
            'service_job_id'      => 0,
            'quick_bill_id'      => $billId,
            'payment_method'     => $this->input->post('paymentMethod'),
            'paid_amount'        => $paidAmount,
            'bank_name'          => $this->input->post('bankName') ?: null,
            'cheque_number'  => $this->input->post('cardOrChequeNo') ?: null,
            'cheque_date'        => $this->input->post('chequeDate') ?: null,
            'payment_date'       => date('Y-m-d H:i:s'),         
            'note'               => $this->input->post('note') ?: null,
            'created_by'         => $this->session->userdata('userid'),
            'created_at'         => date('Y-m-d H:i:s'),
        ];

        $this->db->insert('quick_bill_payments', $paymentData);
        $this->db->insert('services_job_payments', $paymentData2);

        // Clear session cart
        $this->session->unset_userdata('pos_cart');
        echo json_encode([
            'status' => 'success',
            'message' => 'Bill saved successfully.',
            'bill_id' => $billId
        ]);
    }


    public function print_receipt($bill_id)
    {
        $this->load->model('QuickBill_model');
        $data['bill'] = $this->QuickBill_model->get_bill_by_id($bill_id);
        $data['items'] = $this->QuickBill_model->get_bill_items($bill_id);

        if (empty($data['bill'])) {
            show_404();
        }

        $data['quick_bill_id'] = $bill_id;
        $data['logo_url'] = base_url('assets/images/logo.png');
        $data['shop_name'] = 'TROJA AUTO HUB';
        $data['shop_address'] = "No 664/1, Yatihena, Malwana";
        $data['shop_phone'] = 'Hotline: 075 500 500 9  |  Tel: 011 299 68 68';


        $this->load->view('quick-bill/print_receipt', $data);
    }
}
