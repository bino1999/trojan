<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Purchase extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('purchase_model');
    }

    public function purchaseManage() {
        $data['mainMenuName'] = 'Purchase Order';
        $data['subMenuName'] = 'purchase-manage';

        $data['suppliers'] = $this->purchase_model->loadActiveSuppliers();
        $data['products'] = $this->purchase_model->loadActiveProducts();
        $data['productCategories'] = $this->purchase_model->loadProductCategories();
        $data['productBrands'] = $this->purchase_model->loadProductBrands();
        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('purchase/purchase-manage', $data);
        $this->load->view('layout/footer');
    }

    public function filterProducts() {
        $category_id = $this->input->post('category_id');
        $brand_id = $this->input->post('brand_id');

        $data['products'] = $this->purchase_model->loadActiveProductsByCategoryBrand($category_id, $brand_id);
        $this->load->view('purchase/product-filter-list', $data);
    }

    public function createPurchase()
{
    $supplier_id = $this->input->post('supplier_id');
    $bill_no = trim($this->input->post('bill_no'));
    $bill_date = $this->input->post('bill_date');
    $payment_method = $this->input->post('payment_method');
    $description = trim($this->input->post('description'));
    $vat_type = $this->input->post('vat_type');
    $vat_percent = $this->input->post('vat_percent');

    if (!$supplier_id || !$bill_no || !$bill_date) {
        echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields.']);
        return;
    }

    if(!$payment_method){
        echo json_encode(['status' => 'error', 'message' => 'Please select a payment method.']);
        return;
    }

    if ($vat_type == 'vat') {
        if ($vat_percent === '' || !is_numeric($vat_percent) || $vat_percent < 0 || $vat_percent > 100) {
            echo json_encode(['status' => 'error', 'message' => 'Please enter a valid VAT percent (0 - 100).']);
            return;
        }
    } else {
        $vat_percent = 0;
    }

    if($payment_method == 'cash'){
        $payment_method = 1;
    }else if($payment_method == 'cheque'){
        $payment_method = 2;
    }else{
        $payment_method = 0;
    }

    $data = [
        'supplier_id' => $supplier_id,
        'bill_no' => $bill_no,
        'bill_date' => $bill_date,
        'payment_method' => $payment_method,
        'vat_type' => $vat_type,
        'vat_percent' => $vat_percent,
        'description' => $description,
        'created_by' => $this->session->userdata('userid'),
        'created_at' => date('Y-m-d H:i:s')
    ];

    $this->db->insert('purchase_orders', $data);
    echo json_encode(['status' => 'success', 'message' => 'Purchase order created.']);
}

public function loadPurchases(){

    $sdate = $this->input->post('sdate');
    $edate = $this->input->post('edate');

    $data['purchases'] = $this->purchase_model->loadPurchases($sdate, $edate);
    $this->load->view('purchase/purchase-manage-list', $data);
}

public function addPurchaseOrderItem()
{
    $company_price = (float)$this->input->post('company_price');
    $sale_price = (float)$this->input->post('sale_price');
    $discount_percent = (float)$this->input->post('discount_percent');
    $discount_amount = (float)$this->input->post('discount_amount');

    // Business Rule 1: Sale price must not be less than company price
    if ($sale_price < $company_price) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Sale price must not be less than company price.'
        ]);
        return;
    }

    // Business Rule 2: Only one discount method allowed
    if ($discount_percent > 0 && $discount_amount > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Only one of discount percent or amount can be entered.'
        ]);
        return;
    }

    if (!$this->input->post('product_id') > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please select a product.'
        ]);
        return;
    }

    $genuine = $this->input->post('genuine') !== null ? 1 : 0;

    $insertData = [
        'po_id'            => $this->input->post('po_id'),
        'supplier_id'      => $this->input->post('supplier_id'),
        'product_id'       => $this->input->post('product_id'),
        'purchase_date'    => $this->input->post('purchase_date'),
        'genuine'          => $genuine,
        'uom'              => $this->input->post('uom'),
        'inventory_type'   => $this->input->post('inventory_type'),
        'quantity'         => $this->input->post('quantity'),
        'discount_percent' => $discount_percent,
        'discount_amount'  => $discount_amount,
        'company_price'    => $company_price,
        'sale_price'       => $sale_price,
        'rack_no'          => $this->input->post('rack_no'),
        'bin_no'           => $this->input->post('bin_no'),
        'reorder_level'    => $this->input->post('reorder_level'),
        'note'             => $this->input->post('note'),
        'created_at'       => date('Y-m-d H:i:s'),
        'created_by'       => $this->session->userdata('userid'),
        'available_stock' => $this->input->post('quantity')
    ];

    $this->load->model('purchase_model');
    $insertId = $this->purchase_model->addPurchaseOrderItem($insertData);

    if ($insertId) {
        // Optional: Log the activity
        $this->load->model('logs_model');
        $this->logs_model->log_activity('Inventory Item Added', 'Product ID: ' . $this->input->post('product_id'));

        echo json_encode(['status' => 'success', 'message' => 'Item added successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to add item.']);
    }
}

public function loadPurchaseOrderItems(){

    $po_id = $this->input->post('po_id');
   
      $data['purchases'] = $this->purchase_model->loadPurchaseOrderItems($po_id);
       $this->load->view('purchase/purchase-order-item-list', $data);
   }

   public function loadPurchaseOrderItems2(){

    $po_id = $this->input->post('po_id');
   
      $data['purchases'] = $this->purchase_model->loadPurchaseOrderItems($po_id);
       $this->load->view('purchase/purchase-order-item-list-2', $data);
   }

public function deletePurchaseOrderItem($po_item_id = null)
{
    if (!$this->input->is_ajax_request()) {
        show_error('No direct script access allowed');
    }

    if ($po_item_id && is_numeric($po_item_id)) {
        $deleted = $this->purchase_model->deletePurchaseOrderItem($po_item_id);
        if ($deleted) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete item']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
    }
}

public function completePurchaseOrder()
{
    $po_id = $this->input->post('po_id');
    $grand_total = $this->input->post('grand_total');

    if (!$po_id) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Purchase Order ID']);
        return;
    }
    
    $this->db->where('po_id', $po_id);
    $update = $this->db->update('purchase_orders', [
        'total_amount' => $grand_total,
        'status' => 'Completed',
        'completed_at' => date('Y-m-d H:i:s'),
        'completed_by' => $this->session->userdata('userid') // if using session
    ]);

    if ($update) {
        echo json_encode(['status' => 'success', 'message' => 'Purchase order marked as complete.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update purchase order.']);
    }
}

public function deletePurchase()
{
    $po_id = $this->input->post('po_id');

    if (!$po_id) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
        return;
    }

    $this->db->trans_start();

    // Delete items first
    $this->db->where('po_id', $po_id);
    $this->db->delete('purchase_order_items');

    // Then delete the purchase order
    $this->db->where('po_id', $po_id);
    $this->db->delete('purchase_orders');

    $this->db->trans_complete();

    if ($this->db->trans_status()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error occurred.']);
    }
}

public function purchaseHistoryManage() {
    $data['mainMenuName'] = 'Purchase Order';
    $data['subMenuName'] = 'purchase-history-manage';

    $data['suppliers'] = $this->purchase_model->loadActiveSuppliers();
    $data['products'] = $this->purchase_model->loadActiveProducts();
    
    $this->load->view('layout/header');
    $this->load->view('layout/top_navbar');
    $this->load->view('layout/left_sidebar', $data);
    $this->load->view('purchase/purchase-history-manage', $data);
    $this->load->view('layout/footer');
}

public function loadPurchasesItemHistory(){

    $sdate = $this->input->post('sdate');
    $edate = $this->input->post('edate');
    $supplier_id = $this->input->post('supplier_id');
    $product_id = $this->input->post('product_id');

    $data['purchases'] = $this->purchase_model->loadPurchasesItemHistory($sdate, $edate, $supplier_id, $product_id);
    $this->load->view('purchase/purchase-history-item-list', $data);
}

public function stockManage() {
        $data['mainMenuName'] = 'Purchase Order';
        $data['subMenuName'] = 'item-stock';

 
        $data['suppliers'] = $this->purchase_model->loadActiveSuppliers();
        $data['products'] = $this->purchase_model->loadActiveProducts();
        $data['productCategories'] = $this->purchase_model->loadProductCategories();
        $data['productBrands'] = $this->purchase_model->loadProductBrands();
        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('stock/stock-manage', $data);
        $this->load->view('layout/footer');
    }

    public function loadAvailableStock()
{
    $sdate = $this->input->post('sdate');
    $edate = $this->input->post('edate');
    $category_id = $this->input->post('category_id');
    $brand_id = $this->input->post('brand_id');
    $supplier_id = $this->input->post('supplier_id');

    // Validate date
    if (strtotime($sdate) <= strtotime('2025-04-31')) {
        echo "Start date should be after 2025-04-31";
        return;
    }

    // Define open balance date range
    $data['openBalanceSdate'] = '2025-03-01';
    $data['openBalanceEdate'] = date('Y-m-d', strtotime($sdate . ' -1 day'));

    // Step 1: Get filtered product purchase list
    $products = $this->purchase_model->loadPurchaseProductsAsGroup($category_id, $brand_id, $supplier_id);
    $product_ids = array_column($products, 'product_id');

    // Step 2: Get stock summary for date range
    $stock_summary = $this->purchase_model->getStockInOutSummary($product_ids, $sdate, $edate);

    // Step 3: Loop and enrich each product row
    foreach ($products as &$p) {
        $pid = $p->product_id;

        // Open balance (as of sdate)
        $open_balance = $this->purchase_model->getOpenBalance($pid, $sdate);

        // Stock movements
        $stock_in = $stock_summary[$pid]['stock_in'] ?? 0;
        $job_out = $stock_summary[$pid]['job_out'] ?? 0;
        $bill_out = $stock_summary[$pid]['bill_out'] ?? 0;
        $stock_out = $job_out + $bill_out;

        // Closing balance
        $closing = $open_balance + $stock_in - $stock_out;

        // Assign to product object
        $p->open_balance = $open_balance;
        $p->stock_in = $stock_in;
        $p->stock_out = $stock_out;
        $p->closing_balance = $closing;
    }
    unset($p);

    // Step 4: Pass data to view
    $data['stock'] = $products;
    $this->load->view('stock/available-stock-list', $data);
}









}