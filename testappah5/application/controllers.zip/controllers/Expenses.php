<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Expenses extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('expenses_model');
    }

    public function expensesManage()
    {
        $data['mainMenuName'] = 'Expenses';
        $data['subMenuName'] = 'Expenses';

        $data['expenseCategories'] = $this->expenses_model->loadExpensesCategory();
        $data['users'] = $this->expenses_model->loadUsers();
        $data['sections'] = $this->expenses_model->loadSection();

        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('expenses/expenses-manage', $data);
        $this->load->view('layout/footer');
    }


    public function saveExpense()
{
    if ($this->input->method() === 'post') {

        $this->form_validation->set_rules('expense_category', 'Expense Category', 'required|trim');
        $this->form_validation->set_rules('expense_amount', 'Amount', 'required|numeric|trim');
        $this->form_validation->set_rules('expense_date', 'Date', 'required|trim');
        $this->form_validation->set_rules('payment_method', 'Payment Method', 'required|trim');
        $this->form_validation->set_rules('reference', 'Voucher Number', 'required|trim');

        $paymentMethod = $this->input->post('payment_method');

        if ($paymentMethod === 'cheque') {
            $this->form_validation->set_rules('reference', 'Cheque Number / Reference', 'required|trim');
            $this->form_validation->set_rules('cheque_date', 'Cheque Date', 'required|trim');
        }

        if ($paymentMethod === 'card') {
            $this->form_validation->set_rules('reference', 'Card / Reference Number', 'required|trim');
        }

        if ($this->form_validation->run() == FALSE) {
            echo json_encode([
                'status' => 'error',
                'message' => validation_errors()
            ]);
            return;
        }

        if ($paymentMethod === 'cheque') {
            $cheque_date = $this->input->post('cheque_date');
        }else{
            $cheque_date = null;
        }

        // Validate expense_date is today or within last 7 days
        $expenseDate = strtotime($this->input->post('expense_date'));
        $today = strtotime(date('Y-m-d'));
        $sevenDaysAgo = strtotime('-7 days');

        if ($expenseDate > $today || $expenseDate < $sevenDaysAgo) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Expense Date must be today or within the last 7 days.'
            ]);
            return;
        }

        $data = [
            'category_id'     => $this->input->post('expense_category'),
            'amount'          => $this->input->post('expense_amount'),
            'expense_date'    => $this->input->post('expense_date'),
            'employee_id'     => $this->input->post('expense_user'),
            'section_id'      => $this->input->post('expense_section'),
            'payment_method'  => $paymentMethod,
            'reference_no'    => $this->input->post('reference'),
            'cheque_date'     => $cheque_date,
            'description'     => $this->input->post('description'),
            'created_by'      => $this->session->userdata('userid'),
            'created_at'      => date('Y-m-d H:i:s'),
            'updated_at'      => date('Y-m-d H:i:s'),
        ];

        $saved = $this->expenses_model->saveExpense($data);

        echo json_encode([
            'status' => $saved ? 'success' : 'error',
            'message' => $saved ? 'Expense saved successfully.' : 'Failed to save expense.'
        ]);
    }
}



    public function loadExpenses()
    {
        $sdate = $this->input->post('sdate');
        $edate = $this->input->post('edate');
        $expenseCategory = $this->input->post('expenseCategory');
        echo $filterSection = $this->input->post('filterSection');
        $data['expenses'] = $this->expenses_model->loadExpenses($sdate, $edate, $expenseCategory, $filterSection);
        
        $this->load->view('expenses/expense-list', $data);
    }

    public function delete()
{
    $id = $this->input->post('id');
    
    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Expense ID.']);
        return;
    }

    $expense = $this->expenses_model->getById($id);

    if (!$expense) {
        echo json_encode(['status' => 'error', 'message' => 'Expense not found.']);
        return;
    }

    $createdDate = date('Y-m-d', strtotime($expense->created_at));
    $today = date('Y-m-d');

    if ($createdDate !== $today) {
        echo json_encode(['status' => 'error', 'message' => 'Only today\'s records can be deleted.']);
        return;
    }

    $deleted = $this->expenses_model->deleteExpense($id);
    if ($deleted) {
        echo json_encode(['status' => 'success', 'message' => 'Expense deleted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete expense.']);
    }
}





}
