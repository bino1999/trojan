<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SystemRole extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('settings_model');
        $this->load->model('systemRolePermissions_model');
    }


    public function manageSystemRole()
    {
        $data['mainMenuName'] = 'settings';
        $data['subMenuName'] = 'system-role-manage'; 

        $data['results'] = $this->settings_model->loadSystemRole();    
        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar'); 
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('masters/system-role-manage', $data);
        $this->load->view('layout/footer');
    }

    public function saveSystemRole()
{
    $this->load->library('form_validation');
    $this->form_validation->set_rules(
        'name',
        'Name',
        'required|trim|regex_match[/^[a-zA-Z0-9 ]+$/]',
        array('regex_match' => 'The %s field may only contain letters, numbers, and spaces.')
    );

    if ($this->form_validation->run() == FALSE) {
        echo json_encode(['status' => 'error', 'message' => validation_errors()]);
    } else {
        $name = strtoupper($this->input->post('name', true));
        $exists = $this->settings_model->getSystemRoleByName($name);

        if ($exists) {
            echo json_encode(['status' => 'error', 'message' => 'Record already exists!']);
        } else {
            $this->settings_model->saveSystemRole($name);
            echo json_encode(['status' => 'success', 'message' => 'New category added successfully!']);
        }
    }
}


public function updateSystemRole() {
    // Load form validation
    $this->load->library('form_validation');
    $this->form_validation->set_rules(
        'name',
        'Name',
        'required|trim|regex_match[/^[a-zA-Z0-9 ]+$/]',
        array('regex_match' => 'The %s field may only contain letters, numbers, and spaces.')
    );
    

    if ($this->form_validation->run() == FALSE) {
        // Validation failed
        echo json_encode(['status' => 'error', 'message' => validation_errors()]);
    } else {
        
        $recordId = $this->input->post('id');
        $name = strtoupper($this->input->post('name'));  // Convert to upper case

        $result = $this->settings_model->getSystemRoleByName($name);

        if ($result && $result->vehicleCategoryId  != $recordId) {
            //name already exists
            echo json_encode(['status' => 'error', 'message' => 'Record already exists!']);
        } else {
            // Update in the database
            $data = [
                'system_role_name' => $name,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            $this->db->where('system_role_id', $recordId);
            $this->db->update('system_roles', $data);

            echo json_encode(['status' => 'success', 'message' => 'Record updated successfully!', 'data' => $data]);
        }
    }
}

public function deleteSystemRole() {
    $recordId = $this->input->post('recordId');
    $result = $this->settings_model->loadSystemRole($recordId);  
    
    if ($result) {
        $this->db->where('system_role_id', $recordId);
        $this->db->update('system_roles', ['is_deleted' => 1]);
        echo json_encode(['status' => 'success', 'message' => 'Record deleted successfully!']);
        $this->load->model('logs_model');
        $this->logs_model->log_activity('Role Inactive', 'Role ID: '.$recordId);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Record not found.']);
    }  

}

public function undoDeleteSystemRole() {
    $recordId = $this->input->post('recordId');
    $result = $this->settings_model->loadSystemRole($recordId);  
    
    if ($result) {
        $this->db->where('system_role_id', $recordId);
        $this->db->update('system_roles', ['is_deleted' => 0]);
        echo json_encode(['status' => 'success', 'message' => 'Record activated successfully!']);
        $this->load->model('logs_model');
        $this->logs_model->log_activity('Role Active', 'Role ID: '.$recordId);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Record not found.']);
    }  

}

public function loadPermissionsList() {
    $role_id = $this->input->post('recordId');

    $data['assignedPermissions'] = $this->systemRolePermissions_model->getPermissionsByRole($role_id);
    $data['allPermissions'] = $this->systemRolePermissions_model->getAllPermissions();

    $this->load->view('masters/system-role-permissions-list', $data);
}

public function saveRolePermissions() {
    $role_id = $this->input->post('role_id');
    $permissions = $this->input->post('permissions');

    if (!$role_id) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Role ID.']);
        return;
    }

    // Remove existing permissions for this role
    $this->systemRolePermissions_model->removeRolePermissions($role_id);    
    // Insert new permissions
    if (!empty($permissions)) {
        foreach ($permissions as $permissionKey) {
            $this->systemRolePermissions_model->assignPermission($role_id, $permissionKey);
        }
    }

    echo json_encode(['status' => 'success', 'message' => 'Permissions assigned successfully.']);
}


}
?>