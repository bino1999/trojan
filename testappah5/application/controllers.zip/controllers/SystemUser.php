<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SystemUser extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('settings_model');
    }


    public function manageSystemUser()
    {
        $data['mainMenuName'] = 'members';
        $data['subMenuName'] = 'system-user-manage'; 

        
        $data['results'] = $this->settings_model->loadSystemUsers();

        $data['roles'] = $this->settings_model->loadSystemRole();    
        $data['sections'] = $this->settings_model->loadEmployeeSection();    
        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar'); 
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('masters/system-user-manage', $data);
        $this->load->view('layout/footer');
    }

    public function saveSystemUser()
{
    $this->load->library('encrypt');

    // Validate fields
    $this->form_validation->set_rules('userName', 'User Name', 'required|alpha_numeric');
    $this->form_validation->set_rules('firstName', 'First Name', 'required|alpha_numeric_spaces');
    $this->form_validation->set_rules('lastName', 'Last Name', 'required|alpha_numeric_spaces');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('phone', 'Phone Number', 'required|numeric');
    $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
    $this->form_validation->set_rules('password2', 'Confirm Password', 'required|matches[password]');
    $this->form_validation->set_rules('role', 'Role', 'required|numeric|greater_than[0]',['greater_than' => 'Please select a valid Role.']);
    $this->form_validation->set_rules('section', 'Department', 'required|numeric|greater_than[0]',['greater_than' => 'Please select a valid Department.']);
    $this->form_validation->set_rules('hireDate', 'Hire Date', 'required');
    $this->form_validation->set_rules('isActive', 'Is Active', 'required|in_list[0,1]');

    if ($this->form_validation->run() == FALSE) {
        echo json_encode(['status' => 'error', 'message' => validation_errors()]);
        return;
    }

    // Check if UserName already exists
    $userName = ucfirst(strtolower(trim($this->input->post('userName'))));
    $email = $this->input->post('email');

    $this->db->where('UserName', $userName);
    $userExist = $this->db->get('users')->row();

    if ($userExist) {
        echo json_encode(['status' => 'error', 'message' => 'User Name already exists.']);
        return;
    }

    // Check if Email already exists
    $this->db->where('Email', $email);
    $emailExist = $this->db->get('users')->row();

    if ($emailExist) {
        echo json_encode(['status' => 'error', 'message' => 'Email already exists.']);
        return;
    }

    $encrypted_password = $this->encrypt->encode($this->input->post('password'));
    $data = [
        'UserName' => ucfirst(strtolower(trim($this->input->post('userName')))),
        'FirstName' => $this->input->post('firstName'),
        'LastName' => $this->input->post('lastName'),
        'Email' => $this->input->post('email'),
        'PhoneNumber' => $this->input->post('phone'),
        'Password' => $encrypted_password,
        'Role' => $this->input->post('role'),
        'EmployeeID' => $this->input->post('employeeID'),
        'Department' => $this->input->post('section'),
        'HireDate' => $this->input->post('hireDate'),
        'IsActive' => $this->input->post('isActive'),
        'CreatedAt' => date('Y-m-d H:i:s'),
        'UpdatedAt' => date('Y-m-d H:i:s')
    ];

    // Save to database
    if ($this->db->insert('users', $data)) {
        echo json_encode(['status' => 'success', 'message' => 'User successfully created.']);
        $this->load->model('logs_model');
        $this->logs_model->log_activity('User Create', 'User Email: '.$this->input->post('email'));
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save user. Please try again.']);
    }
}



public function updateSystemUser() {
    // Get the POST data
    $userId = $this->input->post('userId');
    $userName = $this->input->post('userName');
    $firstName = $this->input->post('firstName');
    $lastName = $this->input->post('lastName');
    $email = $this->input->post('email');
    $phone = $this->input->post('phone');
    $employeeID = $this->input->post('employeeID');
    $role = $this->input->post('role');
    $section = $this->input->post('section');
    $hireDate = $this->input->post('hireDate');
    $isActive = $this->input->post('isActive');

    // Validate required fields (Optional: you can add more validation rules here)
    if (!$userName || !$firstName || !$lastName || !$email || !$phone) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
        return;
    }

    if ($this->settings_model->checkUserEmailExists($email, $userId)) {
        echo json_encode(['status' => 'error', 'message' => 'The email address is already in use by another user.']);
        return;
    }
   
    $data = [
        'FirstName' => $firstName,
        'LastName' => $lastName,
        'Email' => $email,
        'PhoneNumber' => $phone,
        'EmployeeID' => $employeeID,
        'Role' => $role,
        'Department' => $section,
        'HireDate' => $hireDate,
        'IsActive' => $isActive,
        'UpdatedAt' => date('Y-m-d H:i:s')  // Set the update timestamp
    ];

    $this->db->where('UserID', $userId);
    $updateStatus = $this->db->update('users', $data);

    if ($updateStatus) {
        echo json_encode(['status' => 'success', 'message' => 'User details updated successfully.']);
        $this->load->model('logs_model');
        $this->logs_model->log_activity('User Update', 'User Email: '.$email);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update user. Please try again.']);
    }
}



}
?>