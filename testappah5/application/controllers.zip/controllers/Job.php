<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Job extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('purchase_model');
        $this->load->model('services_model');
    }

    public function servicesManage()
    {

        // Get the status parameter from the URL
        $url_status = $this->input->get('status');
        $url_manager = $this->input->get('manager');

        if ($url_status === null) {
            $url_status = 'all';
        }

        $this->session->set_userdata('filter_job_status', $url_status);
        $this->session->set_userdata('filter_job_status_is_invoices', 0);


        if ($url_status == 5) {
            $data['mainMenuName'] = 'Invoices';
        } else {
            $data['mainMenuName'] = 'Services Manager';
        }


        if ($url_status == 4 && $url_manager == 'yes') {
            $data['mainMenuName'] = 'Manager Approval';
        }

        $data['subMenuName'] = $url_status;
        $data['url_status'] = $url_status;

        $data['customers'] = $this->services_model->loadCustomer();
        $data['vehicles'] = $this->services_model->loadvehicles();
        $data['vehicleBrands'] = $this->services_model->loadvehicleBrands();
        $data['vehicleCategories'] = $this->services_model->loadvehicleCategories();
        $data['serviceItemCategory'] = $this->services_model->loadServiceItemsCategory();
        $data['employeeSections'] = $this->services_model->loadEmployeeSections();
        $data['itemBrands'] = $this->services_model->loadItemBrands();
        $data['itemCategories'] = $this->services_model->loadItemCategories();
        $data['suppliers'] = $this->services_model->loadSuppliers();

        $data['servicePackages'] = $this->services_model->loadServicesPackages();
        $data['serviceItems'] = $this->services_model->loadServicesItems();

        
        $data['products'] = $this->services_model->loadAvailablePurchaseProducts();


        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('job/services-manage', $data);
        $this->load->view('layout/footer');
    }

    public function loadServiceItemsFilterListByCategory()
    {
        $categoryId = $this->input->post('categoryId');
        $sectionId = $this->input->post('sectionId');
        $data['serviceItems'] = $this->services_model->loadServicesItemsByCategory($categoryId, $sectionId);
        $this->load->view('job/service-items-filter-list', $data);
    }

    public function loadServiceProductsFilterListByProduct()
    {
        $categoryId = $this->input->post('categoryId');
        $brandId = $this->input->post('brandId');
        $supplierId = $this->input->post('supplierId');
        $data['products'] = $this->services_model->loadAvailablePurchaseProducts(null, $supplierId, $brandId, $categoryId);
        $this->load->view('job/product-items-filter-list', $data);
    }

    public function invoices()
    {

        $this->session->set_userdata('filter_job_status', 5);

        $data['mainMenuName'] = 'Invoices';
        $data['subMenuName'] = 'Invoices';
        $data['url_status'] = 5;

        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('job/invoices', $data);
        $this->load->view('layout/footer');
    }

    public function saveServiceJob()
    {
        $errors = [];
        $isNewCustomer = ($this->input->post('btnradio') === 'new_customer');

        // Only validate new customer fields if it's a new customer
        if ($isNewCustomer) {
            if (!$this->input->post('new_salutation')) {
                $errors[] = 'Salutation is required for new customer.';
            }

            if (!$this->input->post('new_customer_name')) {
                $errors[] = 'Customer name is required for new customer.';
            }

            if (!$this->input->post('new_vehicle_no')) {
                $errors[] = 'Vehicle number is required for new customer.';
            } else {
                // Additional validation if needed
                $vehicleNo = $this->input->post('new_vehicle_no');
                if (strlen(trim($vehicleNo)) === 0) {
                    $errors[] = 'Vehicle number cannot be empty.';
                }
            }
        }

        // Common validations (for both new and existing customers)
        if (!$this->input->post('new_mobile')) {
            $errors[] = 'Mobile number is required for new customer.';
        }

        //check mobile number has 10 digit and is numeric
        if (!preg_match('/^[0-9]{10}$/', $this->input->post('new_mobile'))) {
            $errors[] = 'Mobile number must be 10 digits and numeric.';
        }

        if (!$this->input->post('current_mileage')) {
            $errors[] = 'Current mileage is required.';
        }

        if (!$this->input->post('next_service_mileage')) {
            $errors[] = 'Next service mileage is required.';
        }

        //check both millage are same
        if ($this->input->post('current_mileage') >= $this->input->post('next_service_mileage')) {
            $errors[] = 'Next service mileage must be greater than current mileage.';
        }

        //if not select status then set default value as "Pending"
        $job_status = $this->input->post('status');
        if (!$this->input->post('status')) {
            $job_status = 0;
        }

        if ($errors) {
            echo json_encode(['status' => 'error', 'messages' => $errors]);
            return;
        }

        // Process form data
        $data = [
            'job_contact_no' => $this->input->post('new_mobile'),
            'current_mileage' => $this->input->post('current_mileage'),
            'next_service_mileage' => $this->input->post('next_service_mileage'),
            'next_service_date' => $this->input->post('next_service_date'),
            'service_type' => $this->input->post('type'),
            'status' => $job_status,
            'description' => $this->input->post('description'),
            'service_date' => date('Y-m-d'),
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('userid'),
        ];

        // Handle customer type
        if ($this->input->post('btnradio') === 'new_customer') {
            // Insert new customer
            $customer_data = [
                'salutation' => $this->input->post('new_salutation'),
                'name' => $this->input->post('new_customer_name'),
                'mobile' => $this->input->post('new_mobile'),
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $this->session->userdata('userid'),
            ];
            $this->db->insert('customers', $customer_data);
            $customer_id = $this->db->insert_id();

            // Insert new vehicle
            $vehicle_data = [
                'owner_id' => $customer_id,
                'vehicle_no' => $this->formatVehicleNumber($this->input->post('new_vehicle_no')),
                'category_id' => $this->input->post('new_category_id'),
                'brand_id' => $this->input->post('new_brand_id'),
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $this->session->userdata('userid'),
            ];
            $this->db->insert('vehicles', $vehicle_data);
            $data['vehicle_id'] = $this->db->insert_id();
            $data['customer_id'] = $customer_id;
        } else {
            // Existing customer
            $data['vehicle_id'] = $this->input->post('use_vehicle_id');
            $data['customer_id'] = $this->input->post('use_customer_id');
        }

        // Save service job
        if ($this->db->insert('services_job', $data)) {
            echo json_encode(['status' => 'success', 'message' => 'Service Job created successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to create Service Job. Please try again.']);
        }
    }

    protected function formatVehicleNumber($vehicleNo)
    {
        if (empty($vehicleNo)) return '';

        // Remove all special characters (keep only letters and numbers)
        $cleaned = preg_replace('/[^A-Za-z0-9]/', '', $vehicleNo);

        // Add space between letters and numbers (e.g. "ABC123" → "ABC 123")
        $formatted = preg_replace('/([A-Za-z]+)([0-9]+)/i', '$1 $2', $cleaned);

        return strtoupper($formatted);
    }

    public function loadServicesJobs()
    {

        $sdate = $this->input->post('sdate');
        $edate = $this->input->post('edate');
        $filter_service_type = $this->input->post('filter_service_type');
        $is_credit = $this->input->post('invoicePayType');

        $data['jobs'] = $this->services_model->loadServicesJobs($sdate, $edate, $filter_service_type, $is_credit);
        $this->load->view('job/services-manage-list', $data);
    }

    public function loadInvoices()
    {

        $sdate = $this->input->post('sdate');
        $edate = $this->input->post('edate');

        $data['jobs'] = $this->services_model->loadServicesJobs($sdate, $edate);
        $this->load->view('job/invoices-list', $data);
    }

    public function showServicePackageItems()
    {
        $packageId = $this->input->post('packageId');

        $data['packageItems'] = $this->services_model->showServicePackageItems($packageId);

        if (!empty($data['packageItems'])) {
            // Start the table
            $html = '<table class="table table-sm table-normal">';
            $html .= '<thead class="table-info">';
            $html .= '<tr>';
            $html .= '<th>Item Name</th>';
            $html .= '<th>Original Price</th>';
            $html .= '<th>Discount</th>';
            $html .= '<th>Final Amount</th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';

            $totalPrice = 0;
            foreach ($data['packageItems'] as $item) {
                // Calculate final amount based on discount type
                $finalAmount = $item->price;
                $discountDisplay = '-';

                if ($item->discount_type == 'percentage' && $item->discount_value > 0) {
                    $discountAmount = $item->price * ($item->discount_value / 100);
                    $finalAmount = $item->price - $discountAmount;
                    $discountDisplay = $item->discount_value . '% (LKR ' . number_format($discountAmount, 2) . ')';
                } elseif ($item->discount_type == 'fixed' && $item->discount_value > 0) {
                    $finalAmount = $item->price - $item->discount_value;
                    $discountDisplay = 'LKR ' . number_format($item->discount_value, 2);
                }

                // Ensure final amount doesn't go below 0
                $finalAmount = max(0, $finalAmount);
                $totalPrice += $finalAmount;

                $html .= '<tr>';
                $html .= '<td style="text-align: left;">' . htmlspecialchars($item->name) . '</td>';
                $html .= '<td>LKR ' . number_format($item->price, 2) . '</td>';
                $html .= '<td>' . $discountDisplay . '</td>';
                $html .= '<td>LKR ' . number_format($finalAmount, 2) . '</td>';
                $html .= '</tr>';
            }

            $html .= '</tbody>';
            $html .= '<tfoot>';
            $html .= '<tr>';
            $html .= '<td colspan="3" style="text-align: left;"><strong>Total:</strong></td>';
            $html .= '<td><strong>LKR ' . number_format($totalPrice, 2) . '</strong></td>';
            $html .= '</tr>';
            $html .= '</tfoot>';
            $html .= '</table>';

            echo $html;
        } else {
            echo '<div class="alert alert-info">No items found for this package.</div>';
        }
    }


    public function addServicePackageToJob()
    {
        $jobId = $this->input->post('jobId');
        $packageId = $this->input->post('packageId');

        // Get package items
        $packageItems = $this->services_model->showServicePackageItems($packageId);

        // Start transaction for data integrity
        $this->db->trans_start();

        foreach ($packageItems as $item) {
            $quantity = 1;
            $price = $item->price;
            $discount_type = $item->discount_type;
            $discount_value = $item->discount_value;

            // Initialize discount variables
            $discountPercent = 0;
            $discountAmount = 0;

            // Calculate discounts based on type
            if ($discount_type == 'percentage' && $discount_value > 0) {
                $discountPercent = $discount_value;
                $discountAmount = $price * ($discount_value / 100);
            } elseif ($discount_type == 'fixed' && $discount_value > 0) {
                $discountAmount = $discount_value;
            }

            // Ensure discount doesn't make price negative
            $discountAmount = min($discountAmount, $price);

            // Prepare data for insertion
            $data = [
                'service_job_id' => $jobId,
                'item_id' => $item->id,
                'item_type' => 'service',
                'package_id' => $packageId,
                'quantity' => $quantity,
                'price' => $price,
                'discount_percent' => $discountPercent,
                'discount_amount' => $discountAmount,
                // total_price will be calculated automatically by the database
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $this->session->userdata('userid')
            ];

            $this->db->insert('services_job_items', $data);
        }

        // Complete transaction
        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            // Log error or handle transaction failure
            log_message('error', 'Failed to add package to job: ' . print_r($this->db->error(), TRUE));
            return false;
        }

        return true;
    }

    public function addServiceItemToJob()
    {
        $jobId = $this->input->post('jobId');
        $itemId = $this->input->post('itemID');

        if (empty($jobId) || empty($itemId)) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID or Item ID is missing']);
            return;
        }

        $itemDetails = $this->services_model->loadServicesItems($itemId);
        if (empty($itemDetails)) {
            echo json_encode(['status' => 'error', 'message' => 'Item not found']);
            return;
        }

        $itemPrice = $itemDetails->price;
        $itemName = $itemDetails->name;

        $data = [
            'service_job_id' => $jobId,
            'item_id' => $itemId,
            'item_type' => 'service',
            'package_id' => null,
            'quantity' => 1,  // Default quantity for now
            'price' => $itemPrice,
            'discount_percent' => 0,
            'discount_amount' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('userid')
        ];

        // Insert into the database
        if ($this->db->insert('services_job_items', $data)) {
            echo json_encode(['status' => 'success', 'message' => 'Service item added successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add service item']);
        }
    }

    public function addProductToJob()
    {
        $jobId = $this->input->post('jobId');
        $productId = $this->input->post('productID');
        $po_item_id = $this->input->post('po_item_id');
        $quantity = $this->input->post('quantity');

        if (empty($jobId) || empty($productId) || empty($po_item_id) || empty($quantity)) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID, Product ID or Quantity is missing']);
            return;
        }

        //$productDetails = $this->services_model->loadProducts($productId);
        $productDetails = $this->services_model->loadPurchaseProduct($po_item_id);
        if (empty($productDetails)) {
            echo json_encode(['status' => 'error', 'message' => 'Product not found']);
            return;
        }

        // Check if product price is available
        $productPrice = isset($productDetails->sale_price) ? $productDetails->sale_price : 0; // Set default to 0 if no price
        if ($productPrice <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Product price is invalid ']);
            return;
        }

        $productName = $productDetails->product_name;
        $discount_percent = $productDetails->discount_percent;
        $discount_amount = $productDetails->discount_amount;
        $totalPrice = $productPrice * $quantity;

        

        $data = [
            'service_job_id' => $jobId,
            'item_id' => $productId,
            'po_item_id' => $po_item_id,
            'item_type' => 'product',
            'package_id' => null,
            'quantity' => $quantity,
            'price' => $productPrice,
            'discount_percent' => $discount_percent,
            'discount_amount' => $discount_amount,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('userid')
        ];

        if ($this->db->insert('services_job_items', $data)) {
            echo json_encode(['status' => 'success', 'message' => 'Product added successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add product']);
        }
    }

    public function addOthersItemToJob()
    {
        $jobId = $this->input->post('jobId');
        $model = $this->input->post('model');
        $description = $this->input->post('description');
        $amount = $this->input->post('amount');

        if (empty($jobId)) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID is missing']);
            return;
        }

        if (empty($description) || empty($amount)) {
            echo json_encode(['status' => 'error', 'message' => 'Description or Amount is missing']);
            return;
        }

        $model = strtolower($model);

        if($model == 'labour') {
            $description = 'Labour charges';
        }

        $data = [
            'service_job_id' => $jobId,
            'item_id' => 0,
            'item_type' => $model,
            'package_id' => null,
            'description' => $description,
            'quantity' => 1,  // Default quantity for now
            'price' => $amount,
            'discount_percent' => 0,
            'discount_amount' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => $this->session->userdata('userid')
        ];

        // Insert into the database
        if ($this->db->insert('services_job_items', $data)) {
            echo json_encode(['status' => 'success', 'message' => 'Record added successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add item']);
        }
    }

    public function loadJobItems()
    {
        $jobId = $this->input->post('jobId');
        $data['jobData'] = $this->services_model->loadJobData($jobId);
        $data['jobPayment'] = $this->services_model->loadJobTotalPayment($jobId);
        $data['jobItems'] = $this->services_model->loadJobItems($jobId);
        $data['paymentHistory'] = $this->services_model->loadJobPayment($jobId);
        $this->load->view('job/services-job-items-list', $data);
    }

    public function deleteJobItem()
    {
        $itemId = $this->input->post('id');
        $package_id = $this->input->post('package_id');
        $job_id = $this->input->post('job_id');


        if (!$package_id > 0) {
            // Make sure you check for a valid item ID
            if (!is_null($itemId)) {
                $this->db->where('id', $itemId);
                if ($this->db->delete('services_job_items')) {
                    echo json_encode(['status' => 'success', 'message' => 'Item deleted successfully!']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to delete item.']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Invalid item ID.']);
            }
        }


        //if package_id > 0 then delete the all package item
        if ($package_id > 0) {
            $this->db->where('service_job_id', $job_id);
            $this->db->where('package_id', $package_id);
            if ($this->db->delete('services_job_items')) {
                echo json_encode(['status' => 'success', 'message' => 'Item deleted successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to delete item.']);
            }
        }
    }

    public function addDiscountToJob()
    {
        $jobId = $this->input->post('jobId');
        $discountRate = $this->input->post('discountRate');
        $discountAmount = $this->input->post('discountAmount');

        // Validate inputs
        if (empty($jobId)) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID is missing']);
            return;
        }

        // Check if either discountRate or discountAmount is numeric
        if ((!is_numeric($discountRate) || $discountRate < 0) && (!is_numeric($discountAmount) || $discountAmount < 0)) {
            echo json_encode(['status' => 'error', 'message' => 'Discount Rate and Amount must be numeric and non-negative']);
            return;
        }

        // Validate only one of them is entered
        if ($discountRate > 0 && $discountAmount > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Please enter either a discount rate or amount, not both']);
            return;
        }

        if ($discountRate > 0) {
            $discountAmount = 0;
        } else {
            $discountRate = 0;
        }

        // Update the services_job table with the discount rate and amount
        $this->db->where('job_id', $jobId);
        $this->db->update('services_job', [
            'discount_percent' => $discountRate,
            'discount_amount' => $discountAmount
        ]);

        if ($this->db->affected_rows() > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Discount added successfully!']);
            $this->load->model('logs_model');
            $this->logs_model->log_activity('Discount added to job', 'Job ID: ' . $jobId . ', Discount Rate: ' . $discountRate . ', Discount Amount: ' . $discountAmount);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add discount.']);
        }
    }

    public function addPaymentToJob()
    {
        $jobId = $this->input->post('jobId');
        $paymentMethod = $this->input->post('paymentMethod');
        $paidAmount = $this->input->post('paidAmount');
        $bankName = $this->input->post('bankName');
        $chequeNumber = $this->input->post('chequeNumber');
        $chequeDate = $this->input->post('chequeDate');
        $creditPersonName = $this->input->post('creditPersonName');
        $creditRemark = $this->input->post('creditRemark');
        $creditPayDate = $this->input->post('creditPayDate');

        // Validate required inputs
if (empty($jobId) || empty($paymentMethod)) {
    echo json_encode(['status' => 'error', 'message' => 'Job ID and Payment Method are required']);
    return;
}

// Validate paid amount based on payment method
if ($paymentMethod !== 'credit') {
    if (!is_numeric($paidAmount) || $paidAmount <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Paid Amount must be a positive number']);
        return;
    }
} else {
    // For credit method, allow 0 or null paidAmount
    if (!is_numeric($paidAmount)) {
        $paidAmount = 0.00; // Optional normalization
    }
}

        if ($paymentMethod === 'credit' && empty($creditPersonName)) {
            echo json_encode(['status' => 'error', 'message' => 'Credit Person Name is required when payment method is credit']);
            return;
        }

        if ($paymentMethod === 'credit' && empty($creditRemark)) {
            echo json_encode(['status' => 'error', 'message' => 'Credit Remark is required when payment method is credit']);
            return;
        }

        if ($paymentMethod === 'credit' && empty($creditPayDate)) {
            echo json_encode(['status' => 'error', 'message' => 'Credit Pay Date is required when payment method is credit']);
            return;
        }

        //credit pay date should be today or future date
        if ($paymentMethod === 'credit' && $creditPayDate < date('Y-m-d')) {
            echo json_encode(['status' => 'error', 'message' => 'Credit Pay Date should be today or future date']);
            return;
        }

        // If payment method is cheque, ensure that the cheque number is provided
        if ($paymentMethod === 'cheque' && empty($chequeNumber)) {
            echo json_encode(['status' => 'error', 'message' => 'Cheque number is required when payment method is cheque']);
            return;
        }

        if ($paymentMethod === 'cheque' && empty($chequeDate)) {
            echo json_encode(['status' => 'error', 'message' => 'Cheque date is required when payment method is cheque']);
            return;
        }

        //validate cheque date, its should be today or future date
        if ($paymentMethod === 'cheque' && $chequeDate < date('Y-m-d')) {
            echo json_encode(['status' => 'error', 'message' => 'Cheque date should be today or future date']);
            return;
        }

        $paymentDate = date('Y-m-d H:i:s');
        $createdBy = $this->session->userdata('userid');
        $createdAt = date('Y-m-d H:i:s');

        // Prepare data to insert
        $data = [
            'service_job_id' => $jobId,
            'payment_method' => $paymentMethod,
            'paid_amount' => $paidAmount,
            'bank_name' => $bankName,
            'cheque_number' => $chequeNumber,
            'cheque_date' => $chequeDate,
            'payment_date' => $paymentDate,
            'created_at' => $createdAt,
            'created_by' => $createdBy,
            'deleted_by' => null,
            'deleted_reason' => null,
        ];

        // If payment method is credit, update services_job table with credit data
if ($paymentMethod === 'credit') {
    $creditData = [
        'is_credit'     => 1,
        'credit_person' => $creditPersonName,
        'credit_remark' => $creditRemark,
        'credit_pay_date'   => $creditPayDate
    ];

    $this->db->where('job_id', $jobId);
    $this->db->update('services_job', $creditData);
}

        if ($paidAmount > 0) {
    if ($this->db->insert('services_job_payments', $data)) {
        echo json_encode(['status' => 'success', 'message' => 'Payment added successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to add payment.']);
    }
} else {
    echo json_encode(['status' => 'success', 'message' => 'Credit recorded without payment.']);
}
    }

    public function printInvoice($encodedJobId)
    {
        $jobId = base64_decode(urldecode($encodedJobId));

        // Get the job details from the model using the job ID
        $data['jobData'] = $this->services_model->loadJobData($jobId);
        $data['jobLastPayment'] = $this->services_model->getJobLastPayment($jobId);
        $data['jobItems'] = $this->services_model->loadJobItems($jobId);

        // Check if the job data exists
        if (empty($data['jobData'])) {
            show_404(); // If no job found, show a 404 error
        }

        // Load the view to generate the invoice
        $this->load->view('job/print_invoice', $data);
    }

    public function printMiniInvoice($encodedJobId)
    {
        $jobId = base64_decode(urldecode($encodedJobId));

        // Get the job details from the model using the job ID
        $data['jobData'] = $this->services_model->loadJobData($jobId);
        $data['jobLastPayment'] = $this->services_model->getJobLastPayment($jobId);
        $data['jobItems'] = $this->services_model->loadJobItems($jobId);

        // Check if the job data exists
        if (empty($data['jobData'])) {
            show_404(); // If no job found, show a 404 error
        }

        // Load the view to generate the invoice
        $this->load->view('job/print_mini_invoice', $data);
    }

    public function updateJobStatus()
    {
        $jobId = $this->input->post('jobId');
        $status = $this->input->post('jobStatus');
        $userId = $this->session->userdata('userid');

        if (!$jobId > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID is missing']);
            return;
        }

        if ($status == '') {
            echo json_encode(['status' => 'error', 'message' => 'Status must be a number']);
            return;
        }

        // Prepare data for update
        $updateData = [
            'status' => $status,
            'confirmed_by' => 0,
            'confirmed_at' => null,
            'print_access_at' => null,
            'print_access_by' => 0
        ];

        $updateData2 = [
            'confirmed_at' => null,
            'confirmed_by' => 0
        ];

        $this->db->where('job_id', $jobId);
        $this->db->update('services_job', $updateData);

        if ($this->db->affected_rows() > 0) {
            //update job item table
            $this->db->where('service_job_id', $jobId);
            $this->db->update('services_job_items', $updateData2);

            echo json_encode(['status' => 'success', 'message' => 'Status updated successfully!']);
            $this->load->model('logs_model');
            $this->logs_model->log_activity('Job status updated', 'Job ID: ' . $jobId . ', Status: ' . $status);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update status.']);
        }
    }

    public function confirmJobItem()
    {
        $jobItemId = $this->input->post('jobItemId');
        $status = $this->input->post('status');

        if (!$jobItemId > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Job Item ID is missing']);
            return;
        }

        $userId = $this->session->userdata('userid');
        // Update the job item status in the database
        if ($status == 1) {
            $this->db->where('id', $jobItemId);
            $this->db->update('services_job_items', ['confirmed_by' => $userId, 'confirmed_at' => date('Y-m-d H:i:s')]);
        } else {
            $this->db->where('id', $jobItemId);
            $this->db->update('services_job_items', ['confirmed_by' => 0, 'confirmed_at' => date('Y-m-d H:i:s')]);
        }


        if ($this->db->affected_rows() > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Status updated successfully!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to confirm job item..']);
        }
    }

    public function confirmJob()
    {
        $jobId = $this->input->post('jobId');
        $userId = $this->session->userdata('userid');

        if (!$jobId > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID is missing']);
            return;
        }

        // Update the job status in the database
        $this->db->where('job_id', $jobId);
        $this->db->update('services_job', ['status' => 5, 'confirmed_by' => $userId, 'confirmed_at' => date('Y-m-d H:i:s'), 'print_access_by' => $userId, 'print_access_at' => date('Y-m-d H:i:s')]);

        if ($this->db->affected_rows() > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Job confirmation updated successfully!']);
            //log set
            $this->load->model('logs_model');
            $this->logs_model->log_activity('Job confirmed', 'Job ID: ' . $jobId);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update job confirmation.']);
        }
    }

    public function addPrintAccess()
    {
        $jobId = $this->input->post('jobId');
        $userId = $this->session->userdata('userid');

        if (!$jobId > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Job ID is missing']);
            return;
        }

        // Update the job status in the database
        $this->db->where('job_id', $jobId);
        $this->db->update('services_job', ['print_access_by' => $userId, 'print_access_at' => date('Y-m-d H:i:s')]);

        if ($this->db->affected_rows() > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Print Access updated successfully!']);
            //log set
            $this->load->model('logs_model');
            $this->logs_model->log_activity('Job Print Access updated', 'Job ID: ' . $jobId);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update Print Access.']);
        }
    }

    public function updateItemDiscount()
    {

        // Get input data
        $itemId = $this->input->post('item_id');
        $discount = $this->input->post('discount');
        $discount_amount = $this->input->post('discount_amount');

        // Validate input
        if (!is_numeric($itemId)) {
            echo json_encode(['success' => false, 'message' => 'Invalid item ID']);
            return;
        }

        if (!is_numeric($discount)) {
            echo json_encode(['success' => false, 'message' => 'Discount must be a number']);
            return;
        }

        if (!is_numeric($discount_amount)) {
            echo json_encode(['success' => false, 'message' => 'Discount amount must be a number']);
            return;
        }


        $discount = floatval($discount);
        if ($discount < 0 || $discount > 100) {
            echo json_encode(['success' => false, 'message' => 'Discount must be between 0-100%']);
            return;
        }

        //check both discount and discount_amount are same
        if ($discount > 0 && $discount_amount > 0) {
            echo json_encode(['success' => false, 'message' => 'Please enter either a discount rate or amount, not both']);
            return;
        }


        $data = [
            'discount_percent' => $discount,
            'discount_amount' => $discount_amount,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->db->where('id', $itemId);
        $this->db->update('services_job_items', $data);

        if ($this->db->affected_rows() > 0) {
            echo json_encode(['success' => true, 'message' => 'Discount updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No changes made or item not found']);
        }
    }

}
