<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }

        $this->load->model('dashboard_model');

    }

    public function index()
{
    $data['mainMenuName'] = 'dashboard';
    $data['subMenuName'] = 'dashboard'; 

    $data['customerCount'] = $this->dashboard_model->loadCustomerCount();
    $data['vehicleCount'] = $this->dashboard_model->loadVehicleCount();

$this->load->view('layout/header');
$this->load->view('layout/top_navbar');
$this->load->view('layout/left_sidebar', $data);
$this->load->view('dashboard', $data);  
$this->load->view('layout/footer');

}

}
?>