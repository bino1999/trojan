<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Services extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('userid')) {
            redirect('login');
        }
        $this->load->model('products_model');
        $this->load->model('service_model');
    }

    public function serviceItemsManage() {
        $data['mainMenuName'] = 'Service Packages';
        $data['subMenuName'] = 'services-items-manage';
        $data['sections'] = $this->products_model->loadSections();
        $data['serviceItemCategory'] = $this->products_model->loadServiceItemsCategory();
        
        $this->load->view('layout/header');
        $this->load->view('layout/top_navbar');
        $this->load->view('layout/left_sidebar', $data);
        $this->load->view('general/service-items-manage', $data);
        $this->load->view('layout/footer');
    }
    
    public function loadServiceItems() {
        $section_id = $this->input->post('section_id');
        $data['items'] = $this->service_model->get_service_items($section_id);
        $this->load->view('general/service-items-list', $data);
    }
    
    public function saveServiceItem()
{
    $this->form_validation->set_rules('name', 'Service Name', 'required');
    $this->form_validation->set_rules('price', 'Price', 'required|numeric');
    $this->form_validation->set_rules('price', 'Price', 'required|numeric');
    $this->form_validation->set_rules('service_category', 'Service Category', 'required');

    if ($this->form_validation->run() == FALSE) {
        echo json_encode([
            'status' => 'error',
            'message' => validation_errors()
        ]);
        return;
    }

    $data = [
        'section_id' => $this->input->post('section'),
        'service_category_id' => $this->input->post('service_category'),
        'name' => $this->input->post('name'),
        'price' => $this->input->post('price'),
        'description' => $this->input->post('description'),
        'status' => $this->input->post('status'),
        'created_by' => $this->session->userdata('userid'),
        'created_at' => date('Y-m-d H:i:s')
    ];

    $item_id = $this->input->post('service_item_id');

    if ($item_id) {
        // Update existing item
        $data['updated_by'] = $this->session->userdata('userid');
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->service_model->update_service_item($item_id, $data);
        $message = 'Service item updated successfully';

        $this->load->model('logs_model');
        $this->logs_model->log_activity('Service Item Updated', $this->input->post('name'));
    } else {
        // Create new item
        $item_id = $this->service_model->add_service_item($data);
        $message = 'Service item added successfully';
        $this->load->model('logs_model');
        $this->logs_model->log_activity('Service Item Added', $this->input->post('name'));
    }

    echo json_encode([
        'status' => 'success',
        'message' => $message,
        'item_id' => $item_id
    ]);
}

    
    public function getServiceItem() {
        $item_id = $this->input->post('item_id');
        $item = $this->service_model->get_service_item($item_id);
        
        if ($item) {
            echo json_encode([
                'status' => 'success',
                'data' => $item
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Service item not found'
            ]);
        }
    }
    
    public function deleteServiceItem() {
        $item_id = $this->input->post('item_id');
        $result = $this->service_model->delete_service_item($item_id);
        
        if ($result) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Service item deleted successfully'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to delete service item'
            ]);
        }
    }

    public function servicePackagesManage()
{
    $data['mainMenuName'] = 'Service Packages';
    $data['subMenuName'] = 'service-packages-manage';
    $data['items'] = $this->service_model->loadServiceItems();

    $this->load->view('layout/header');
    $this->load->view('layout/top_navbar');
    $this->load->view('layout/left_sidebar', $data);
    $this->load->view('general/service-packages-manage', $data);
    $this->load->view('layout/footer');
}

public function saveServicePackage()
{
    $packageName = $this->input->post('package_name');
    $items = $this->input->post('items'); // This now contains item_id, discount_type, and discount_value for each item

    if (empty($packageName) || empty($items)) {
        echo json_encode(['status' => 'error', 'message' => 'Package name and items are required.']);
        return;
    }

    // Calculate total price with discounts applied
    $totalPrice = 0;
    $itemIds = [];
    
    // First get all item prices
    $this->db->select('id, price');
    $this->db->where_in('id', array_column($items, 'item_id'));
    $serviceItems = $this->db->get('service_items')->result_array();
    $itemPrices = array_column($serviceItems, 'price', 'id');

    // Calculate total with discounts
    foreach ($items as $item) {
        $itemId = $item['item_id'];
        $originalPrice = $itemPrices[$itemId] ?? 0;
        $discountType = $item['discount_type'] ?? 'none';
        $discountValue = $item['discount_value'] ?? 0;
        
        // Calculate discounted price
        $discountedPrice = $originalPrice;
        if ($discountType === 'percentage' && $discountValue > 0) {
            $discountedPrice = $originalPrice - ($originalPrice * $discountValue / 100);
        } elseif ($discountType === 'fixed' && $discountValue > 0) {
            $discountedPrice = $originalPrice - $discountValue;
            if ($discountedPrice < 0) $discountedPrice = 0;
        }
        
        $totalPrice += $discountedPrice;
        $itemIds[] = $itemId;
    }

    // Save package
    $packageData = [
        'package_name' => $packageName,
        'total_price' => $totalPrice,
        'created_by' => $this->session->userdata('userid'),
        'created_at' => date('Y-m-d H:i:s')
    ];
    $this->db->insert('service_packages', $packageData);
    $packageId = $this->db->insert_id();

    // Save package items with discounts
    foreach ($items as $item) {
        $this->db->insert('service_package_items', [
            'package_id' => $packageId,
            'item_id' => $item['item_id'],
            'discount_type' => $item['discount_type'] ?? 'none',
            'discount_value' => $item['discount_value'] ?? 0
        ]);
    }

    echo json_encode(['status' => 'success', 'message' => 'Service Package saved successfully.']);
}


public function updateServicePackage()
{
    // Get the data from the form (using POST)
    $packageId = $this->input->post('package_id');
    $packageName = $this->input->post('package_name');
    $itemIds = $this->input->post('item_ids');  // Selected item IDs (array)

    // Start a transaction to ensure data consistency
    $this->db->trans_start();

    // Update the package name in the 'service_packages' table
    $this->db->set('package_name', $packageName);
    $this->db->where('id', $packageId);
    $this->db->update('service_packages');

    // Delete the existing items associated with this package
    $this->db->where('package_id', $packageId);
    $this->db->delete('service_package_items');

    // Insert the new selected items into the 'service_package_items' table
    $totalPrice = 0;
    foreach ($itemIds as $itemId) {
        // Get the price of the item
        $itemPrice = $this->db->select('price')
                              ->from('service_items')
                              ->where('id', $itemId)
                              ->get()
                              ->row()
                              ->price;

        // Insert the new items into the pivot table
        $this->db->insert('service_package_items', [
            'package_id' => $packageId,
            'item_id' => $itemId
        ]);

        // Add the item price to the total price
        $totalPrice += $itemPrice;
    }

    // Update the total price in the 'service_packages' table
    $this->db->set('total_price', $totalPrice);
    $this->db->where('id', $packageId);
    $this->db->update('service_packages');

    // Complete the transaction
    $this->db->trans_complete();

    // Check if the transaction was successful
    if ($this->db->trans_status() === FALSE) {
        // Rollback transaction if there was an error
        $this->db->trans_rollback();
        echo json_encode(['error' => 'Failed to update service package']);
    } else {
        // Commit transaction if successful
        $this->db->trans_commit();
        echo json_encode(['success' => 'Service package updated successfully']);
    }
}



public function loadServicePackages()
{
    $packages = $this->service_model->loadServicePackages();
    $data['packages'] = $packages;
    $this->load->view('general/service-packages-list', $data);
}

public function getServicePackage($package_id = null)
{
    if (is_null($package_id)) {
        show_404();
    }
    
    $package = $this->service_model->getServicePackage($package_id);
    
    if (!$package) {
        show_404();
    }
    
    echo json_encode($package);
}

public function deleteServicePackage()
{
    $packageId = $this->input->post('package_id');

    $this->db->where('id', $packageId)->delete('service_packages');
    $this->db->where('package_id', $packageId)->delete('service_package_items');

    echo json_encode(['status' => 'success', 'message' => 'Service Package deleted successfully.']);
}

public function getServicePackageItem($packageId)
{
    $package = $this->db->select('sp.*, GROUP_CONCAT(si.id) as item_ids')
        ->from('service_packages sp')
        ->join('service_package_items spi', 'spi.package_id = sp.id')
        ->join('service_items si', 'si.id = spi.item_id')
        ->where('sp.id', $packageId)
        ->group_by('sp.id')
        ->get()
        ->row();

    if ($package) {
        $itemIds = explode(',', $package->item_ids);

        $response = [
            'package_name' => $package->package_name,
            'total_price' => $package->total_price,
            'item_ids' => $itemIds,
        ];

        echo json_encode($response);
    } else {
        echo json_encode(['error' => 'Package not found']);
    }
}


public function toggleServicePackage()
{
    $packageId = $this->input->post('package_id');
    $newStatus = $this->input->post('status');

    // Validate input
    if (empty($packageId) || !is_numeric($newStatus)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request parameters'
        ]);
        return;
    }

    $userId = $this->session->userdata('userid');
    // Update status
    $this->db->where('id', $packageId)
             ->update('service_packages', ['active' => $newStatus, 'updated_by' => $userId, 'updated_at' => date('Y-m-d H:i:s')]);

    if ($this->db->affected_rows() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Status updated successfully'
        ]);
    } else {
        // Check if package exists
        $exists = $this->db->where('id', $packageId)
                          ->count_all_results('service_packages') > 0;
        
        echo json_encode([
            'success' => false,
            'message' => $exists ? 'No changes made' : 'Package not found'
        ]);
    }
}



 



}
?>
