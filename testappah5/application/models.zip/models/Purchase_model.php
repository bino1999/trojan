<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Purchase_model extends CI_Model
{

    public function loadActiveProducts($product_id = null)
    {
        $this->db->select('products.*, brands.itemBrandName as brand_name, categories.itemCategoryName as category_name');
        $this->db->from('products');
        $this->db->join('item_brands brands', 'brands.itemBrandId = products.item_brand_id', 'left');
        $this->db->join('item_categories categories', 'categories.itemCategoryId = products.item_category_id', 'left');
        if ($product_id > 0) {
            $this->db->where('products.product_id', $product_id);
        }
        $this->db->where('is_active', 1);
        $this->db->order_by('product_name', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadActiveProductsByCategoryBrand($category_id = null, $brand_id = null)
    {
        $this->db->select('products.*, brands.itemBrandName as brand_name, categories.itemCategoryName as category_name');
        $this->db->from('products');
        $this->db->join('item_brands brands', 'brands.itemBrandId = products.item_brand_id', 'left');
        $this->db->join('item_categories categories', 'categories.itemCategoryId = products.item_category_id', 'left');
        $this->db->where('is_active', 1);

        if ($category_id > 0) {
            $this->db->where('products.item_category_id', $category_id);
        }
        if ($brand_id > 0) {
            $this->db->where('products.item_brand_id', $brand_id);
        }

        $this->db->order_by('product_name', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadProductCategories($category_id = null)
    {
        $this->db->select('*');
        $this->db->from('item_categories');
        if ($category_id > 0) {
            $this->db->where('itemCategoryId', $category_id);
        }
        $this->db->where('isDeleted', 0);
        $this->db->order_by('itemCategoryName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadProductBrands($brand_id = null)
    {
        $this->db->select('*');
        $this->db->from('item_brands');
        if ($brand_id > 0) {
            $this->db->where('itemBrandId', $brand_id);
        }
        $this->db->where('isDeleted', 0);
        $this->db->order_by('itemBrandName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadActiveSuppliers($supplier_id = null)
    {
        $this->db->select('*');
        $this->db->from('suppliers');

        if ($supplier_id > 0) {
            $this->db->where('supplier_id', $supplier_id);
        }

        $this->db->order_by('name', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadPurchases($sdate = null, $edate = null)
    {
        $this->db->select('p.*, s.name as supplier_name');
        $this->db->from('purchase_orders p');
        $this->db->join('suppliers s', 's.supplier_id = p.supplier_id', 'left');

        if (!empty($sdate) && !empty($edate)) {
            $this->db->where('p.created_at >=', $sdate . ' 00:00:00');
            $this->db->where('p.created_at <=', $edate . ' 23:59:59');
        }

        $this->db->order_by('p.po_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    public function addPurchaseOrderItem($data)
    {
        return $this->db->insert('purchase_order_items', $data);
    }

    public function loadPurchaseOrderItems($po_id = null)
    {
        $this->db->select('poi.*, p.product_name, p.barcode, b.itemBrandName as brand_name, c.itemCategoryName as category_name, u.UserName as created_by');
        $this->db->from('purchase_order_items poi');
        $this->db->join('products p', 'p.product_id = poi.product_id', 'left');
        $this->db->join('item_brands b', 'b.itemBrandId = p.item_brand_id', 'left');
        $this->db->join('item_categories c', 'c.itemCategoryId = p.item_category_id', 'left');
        $this->db->join('users u', 'u.UserID = poi.created_by', 'left');

        if ($po_id > 0) {
            $this->db->where('poi.po_id', $po_id);
        }
        $this->db->order_by('poi.po_item_id', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }
    public function deletePurchaseOrderItem($po_item_id)
{
    $this->db->where('po_item_id', $po_item_id);
    return $this->db->delete('purchase_order_items');
}

public function loadPurchasesItemHistory($sdate = null, $edate = null, $supplier_id = null, $product_id = null) 
    {
        $this->db->select('poi.*, po.bill_no, po.bill_date, po.vat_type, p.product_name, p.barcode, b.itemBrandName as brand_name, c.itemCategoryName as category_name');
        $this->db->from('purchase_order_items poi');
        $this->db->join('products p', 'p.product_id = poi.product_id', 'left');
        $this->db->join('item_brands b', 'b.itemBrandId = p.item_brand_id', 'left');
        $this->db->join('item_categories c', 'c.itemCategoryId = p.item_category_id', 'left');
        $this->db->join('purchase_orders po', 'po.po_id = poi.po_id', 'left');

        $this->db->where('po.status', 'Completed');

        if ($supplier_id > 0) {
            $this->db->where('poi.supplier_id', $supplier_id);
        }

        if($product_id > 0) {
            $this->db->where('poi.product_id', $product_id);
        }

        if (!empty($sdate) && !empty($edate)) {
            $this->db->where('poi.created_at >=', $sdate . ' 00:00:00');
            $this->db->where('poi.created_at <=', $edate . ' 23:59:59');
        }
        $this->db->order_by('poi.po_item_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }


    public function loadPurchasesProductsList($sdate = null, $edate = null, $category_id = null, $brand_id = null, $supplier_id = null, $product_id = null) 
    {
        $this->db->select('poi.*, po.bill_no, po.bill_date, po.vat_type, p.product_name, p.barcode, b.itemBrandName as brand_name, c.itemCategoryName as category_name');
        $this->db->from('purchase_order_items poi');
        $this->db->join('products p', 'p.product_id = poi.product_id', 'left');
        $this->db->join('item_brands b', 'b.itemBrandId = p.item_brand_id', 'left');
        $this->db->join('item_categories c', 'c.itemCategoryId = p.item_category_id', 'left');
        $this->db->join('purchase_orders po', 'po.po_id = poi.po_id', 'left');

        $this->db->where('po.status', 'Completed');

        if ($supplier_id > 0) {
            $this->db->where('poi.supplier_id', $supplier_id);
        }

        if($product_id > 0) {
            $this->db->where('poi.product_id', $product_id);
        }

        if (!empty($sdate) && !empty($edate)) {
            $this->db->where('poi.created_at >=', $sdate . ' 00:00:00');
            $this->db->where('poi.created_at <=', $edate . ' 23:59:59');
        }
        $this->db->order_by('poi.po_item_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }


    public function loadPurchaseProductsAsGroup($category_id = null, $brand_id = null, $supplier_id = null, $product_id = null) 
    {
        $this->db->select('poi.*, po.bill_no, po.bill_date, po.vat_type, p.product_name, p.sku, b.itemBrandName as brand_name, c.itemCategoryName as category_name');
        $this->db->from('purchase_order_items poi');
        $this->db->join('products p', 'p.product_id = poi.product_id', 'left');
        $this->db->join('item_brands b', 'b.itemBrandId = p.item_brand_id', 'left');
        $this->db->join('item_categories c', 'c.itemCategoryId = p.item_category_id', 'left');
        $this->db->join('purchase_orders po', 'po.po_id = poi.po_id', 'left');

        $this->db->where('po.status', 'Completed');

        if ($supplier_id > 0) {
            $this->db->where('poi.supplier_id', $supplier_id);
        }

        if($category_id > 0) {
            $this->db->where('p.item_category_id', $category_id);
        }   

        if($brand_id > 0) {
            $this->db->where('p.item_brand_id', $brand_id);
        }

        if($product_id > 0) {
            $this->db->where('poi.product_id', $product_id);
        }
        $this->db->group_by('poi.product_id');
        $this->db->order_by('poi.po_item_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getOpenBalance($product_id, $sdate)
{
    // Total purchased before sdate
    $this->db->select_sum('quantity');
    $this->db->from('purchase_order_items');
    $this->db->where('product_id', $product_id);
    $this->db->where('purchase_date <', $sdate);
    $purchased = $this->db->get()->row()->quantity ?? 0;

    // Issued in jobs
    $this->db->select_sum('quantity');
    $this->db->from('services_job_items');
    $this->db->where('item_type', 'product');
    $this->db->where('item_id', $product_id);
    $this->db->where('confirmed_by >', 0);
    $this->db->where('DATE(created_at) <', $sdate);
    $job_issued = $this->db->get()->row()->quantity ?? 0;

    // Issued in quick bill (handle returns)
    $this->db->select('SUM(quantity - IFNULL(return_quantity, 0)) as issued');
    $this->db->from('quick_bill_items');
    $this->db->where('item_id', $product_id);
    $this->db->where('DATE(created_at) <', $sdate);
    $quick_issued = $this->db->get()->row()->issued ?? 0;

    $open_balance = $purchased - ($job_issued + $quick_issued);
    //return max($open_balance, 0); // no negative stock
    return $open_balance;
}

public function getStockInOutSummary($product_ids, $sdate, $edate)
{
    $summary = [];

    // === STOCK IN ===
    $this->db->select('product_id, SUM(quantity) as stock_in');
    $this->db->from('purchase_order_items');
    $this->db->where_in('product_id', $product_ids);
    $this->db->where('purchase_date >=', $sdate);
    $this->db->where('purchase_date <=', $edate);
    $this->db->group_by('product_id');
    $stock_in_result = $this->db->get()->result();
    foreach ($stock_in_result as $row) {
        $summary[$row->product_id]['stock_in'] = $row->stock_in;
    }

    // === STOCK OUT FROM JOB ===
    $this->db->select('item_id as product_id, SUM(quantity) as job_out');
    $this->db->from('services_job_items');
    $this->db->where('item_type', 'product');
    $this->db->where_in('item_id', $product_ids);
    $this->db->where('confirmed_by >', 0);
    $this->db->where('DATE(created_at) >=', $sdate);
    $this->db->where('DATE(created_at) <=', $edate);
    $this->db->group_by('item_id');
    $job_result = $this->db->get()->result();
    foreach ($job_result as $row) {
        $summary[$row->product_id]['job_out'] = $row->job_out;
    }

    // === STOCK OUT FROM QUICK BILL ===
    $this->db->select('item_id as product_id, SUM(quantity - IFNULL(return_quantity, 0)) as bill_out');
    $this->db->from('quick_bill_items');
    $this->db->where_in('item_id', $product_ids);
    $this->db->where('DATE(created_at) >=', $sdate);
    $this->db->where('DATE(created_at) <=', $edate);
    $this->db->group_by('item_id');
    $bill_result = $this->db->get()->result();
    foreach ($bill_result as $row) {
        $summary[$row->product_id]['bill_out'] = $row->bill_out;
    }

    return $summary;
}


public function updateAvailableStock()
{
    // Get all purchase items
    $this->db->select('po_item_id, quantity');
    $purchase_items = $this->db->get('purchase_order_items')->result();

    foreach ($purchase_items as $item) {
        $po_item_id = $item->po_item_id;
        $qty = $item->quantity;

        // Get issued from jobs
        $this->db->select_sum('quantity');
        $this->db->from('services_job_items');
        $this->db->where('po_item_id', $po_item_id);
        $this->db->where('item_type', 'product');
        $job_issued = $this->db->get()->row()->quantity ?? 0;

        // Get issued from quick bill (minus returns)
        $this->db->select('SUM(quantity - IFNULL(return_quantity, 0)) as issued');
        $this->db->from('quick_bill_items');
        $this->db->where('po_item_id', $po_item_id);
        $quick_issued = $this->db->get()->row()->issued ?? 0;

        // Calculate available stock
        $available = $qty - ($job_issued + $quick_issued);

        // Update
        $this->db->where('po_item_id', $po_item_id);
        $this->db->update('purchase_order_items', ['available_stock' => $available, 'available_stock_at' => date('Y-m-d H:i:s')]);
    }

    echo "Available stock updated successfully.";
}




 
}
