<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{

    public function loadVehicleCount()
    {
        $this->db->select('COUNT(*) AS vehicle_count');
        $this->db->from('vehicles');
        
        $query = $this->db->get();
        $result = $query->row();
    
        return $result->vehicle_count;
    }
    



    

public function loadCustomerCount($customers_id = null)
{
    $this->db->from('customers');
    
    if ($customers_id > 0) {
        $this->db->where('customers_id', $customers_id);
    }

    return $this->db->count_all_results(); // Returns the row count
}


}
