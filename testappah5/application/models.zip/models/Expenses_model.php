<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Expenses_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function saveExpense($data)
    {
        return $this->db->insert('expenses', $data);
    }

    public function loadExpensesCategory($id = null)
    {
        $this->db->select('*');
        $this->db->from('expenses_categories');
        $this->db->where('isDeleted', 0);
        if ($id > 0) {
            $this->db->where('expensesCategoryId', $id);
        }
        $this->db->order_by('expensesCategoryName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadUsers($UserID = null)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('IsActive', 1);
        if ($UserID > 0) {
            $this->db->where('UserID', $UserID);
        }
        $this->db->order_by('FirstName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadSection($employeeSectionId = null)
    {
        $this->db->select('*');
        $this->db->from('employee_sections');
        $this->db->where('isDeleted', 0);
        if ($employeeSectionId > 0) {
            $this->db->where('employeeSectionId', $employeeSectionId);
        }
        $this->db->order_by('employeeSectionName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function loadExpenses($sdate, $edate, $category_id, $filterSection)
{
    $this->db->select('
        expenses.*,
        expenses_categories.expensesCategoryName AS category_name,
        created_by_user.UserName AS UserName,
        created_by_user.LastName AS created_by_lname,
        employee_user.FirstName AS employee_fname,
        employee_user.LastName AS employee_lname,
        section.employeeSectionName AS section_name
    ');
    $this->db->from('expenses');
    $this->db->join('expenses_categories', 'expenses_categories.expensesCategoryId = expenses.category_id', 'left');
    $this->db->join('users AS created_by_user', 'created_by_user.UserID = expenses.created_by', 'left');
    $this->db->join('users AS employee_user', 'employee_user.UserID = expenses.employee_id', 'left');
    $this->db->join('employee_sections AS section', 'section.employeeSectionId = expenses.section_id', 'left');
    $this->db->where('expense_date >=', $sdate);
    $this->db->where('expense_date <=', $edate);
    if ($category_id > 0) {
        $this->db->where('expenses.category_id', $category_id);
    }
    if ($filterSection > 0) {
        $this->db->where('expenses.section_id', $filterSection);
    }
    $this->db->order_by('expenses.id', 'DESC');
    $query = $this->db->get();
    return $query->result();
}

public function getById($id)
{
    return $this->db->get_where('expenses', ['id' => $id])->row();
}

public function deleteExpense($id)
{
    return $this->db->delete('expenses', ['id' => $id]);
}



}
