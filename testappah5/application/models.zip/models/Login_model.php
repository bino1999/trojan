<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

    public function ensure_default_user()
    {
        $query = $this->db->get('users');
        if ($query->num_rows() === 0) {
            $default_password = '123';
            $encrypted_password = $this->encrypt->encode($default_password);

            $data = [
                'UserName'   => 'Admin',
                'FirstName'  => 'Sudath',
                'LastName'   => 'Bandara',
                'Email'      => 'usjpsudath@gmail.com',
                'PhoneNumber'   => '0711381628',
                'Password'   => $encrypted_password,
                'Role'       => 1,
                'EmployeeID'   => '0',
                'Department'   => 0,
                'HireDate'   => date('Y-m-d'),
                'IsActive'   => 1,
                'CreatedAt'  => date('Y-m-d H:i:s')
            ];
            $this->db->insert('users', $data);
        }
    }

    public function ensure_default_role()
    {
        $query = $this->db->get('system_roles');
        if ($query->num_rows() === 0) {

            $data = [
                'system_role_name'   => 'ADMIN',
                'is_deleted'   => 0,
                'created_at'  => date('Y-m-d H:i:s')
            ];
            $this->db->insert('system_roles', $data);
        }
    }

    public function can_login($email, $password)
    {
        if (empty($email) || empty($password)) {
            return 'Email and password are required.';
        }

        // Query to find user by email
        $this->db->where('Email', $email);
        $this->db->or_where('UserName', $email);
        $query = $this->db->get('users');

        if ($query->num_rows() > 0) {
            $user = $query->row();

            // Check if account is active
            if ($user->IsActive == 0) {
                return 'Your account has been disabled. Please contact the system administrator.';
            }

            // Verify password (replace with password_verify if using password hashing)
            if ($this->encrypt->decode($user->Password) === $password) {
                // Store user ID in session
                $this->session->set_userdata('userid', $user->UserID);
                return '';  // Empty string indicates successful login
            } else {
                return 'Invalid email or password. Please try again.';
            }
        } else {
            return 'User not found. Please check your email.';
        }
    }

    public function get_user_details($UserID)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('UserID', $UserID);
        $query = $this->db->get();
        return $query->row();
    }

    public function find_userByName($UserName = null)
    {
        $this->db->select('*');
        $this->db->from('users');
        if ($UserName) {
            $this->db->where('UserName', $UserName);
        }
        $this->db->order_by('UserName', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function changeMyPassword($UserID, $password)
    {
        $UserID = $this->session->userdata('userid');
        $password = $this->encrypt->encode($password);
        $data = array(
        'password'    => trim($password),
    );
        $this->db->where('UserID', $UserID);
        $this->db->update('users', $data);
        if ($this->db->affected_rows() == '1') {
        return 1;
    } else {
        return 0;
    }
    }    

}
?>