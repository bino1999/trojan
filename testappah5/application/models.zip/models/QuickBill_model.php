<?php
defined('BASEPATH') or exit('No direct script access allowed');

class QuickBill_model extends CI_Model
{

    public function get_bill_by_id($bill_id) {
        $this->db->select('quick_bill.*, customers.name as customer_name');
        $this->db->from('quick_bill');
        $this->db->join('customers', 'customers.customers_id = quick_bill.customer_id', 'left');
        $this->db->where('quick_bill_id', $bill_id);
        $this->db->order_by('quick_bill_id', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_bill_items($bill_id) {
        $this->db->select('quick_bill_items.*, products.product_name as item_name');
        $this->db->from('quick_bill_items');
        $this->db->join('products', 'products.product_id = quick_bill_items.item_id', 'left');
        $this->db->where('quick_bill_id', $bill_id);
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_all_quick_bills($sdate = null, $edate = null) {
        $this->db->select('quick_bill.*, customers.name as customer_name, users.UserName as created_by');
        $this->db->from('quick_bill');
        $this->db->join('customers', 'customers.customers_id = quick_bill.customer_id', 'left');
        //join users
        $this->db->join('users', 'users.UserID = quick_bill.created_by', 'left');

        if ($sdate && $edate) {
            $this->db->where('DATE(quick_bill.created_at) >=', $sdate);
            $this->db->where('DATE(quick_bill.created_at) <=', $edate);
        } 

        $this->db->order_by('quick_bill_id', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }



}
?>