<table id="table1" class="table table-striped table-responsive">
    <thead>
        <tr>
            <th>#</th>
            <th>Permission Name</th>
            <th>Assign</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($allPermissions)) : ?>
            <?php foreach ($allPermissions as $index => $permission) : ?>
                <?php
                // Check if permission is already assigned
                $isChecked = in_array($permission->permission_id, array_column($assignedPermissions, 'permission_id')) ? "checked" : "";
                ?>
                <tr>
                    <td><?= $index + 1; ?></td>
                    <td><?= $permission->permission_name; ?></td>
                    <td>
                        <input type="checkbox"
                            class="form-check-input permission-checkbox"
                            name="permissions[]"
                            value="<?= $permission->permission_id; ?>"
                            <?= $isChecked; ?>>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="3" class="text-center text-danger">No permissions available.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>