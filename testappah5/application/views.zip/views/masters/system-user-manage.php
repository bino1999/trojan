<div class="row">
<div class="col-12">
<div class="page-title-box d-sm-flex align-items-center justify-content-between">
<h4 class="mb-sm-0">Users</h4>

<div class="page-title-right">
<ol class="breadcrumb m-0">
<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
<li class="breadcrumb-item active">Users</li>
</ol>
</div>

</div>
</div>
</div>

<div class="row">
<div class="col-lg-12">

<style>
.mainCard {
margin: -10px;
}
</style>

<div class="card mainCard">
<div class="card-header align-items-center d-flex">
<h4 class="card-title mb-0 flex-grow-1">All Users</h4>
<div class="flex-shrink-0">
<button type="button" class="btn btn-success btn-label waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#exampleModalgrid"><i class="fa fa-plus label-icon align-middle fs-16 me-2"></i> Create New Users</button>
</div>
</div><!-- end card header -->
<div class="card-body">

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
<?php endif; ?>

<table id="table1" class="table table-striped table-responsive">
<thead class="table-info">
<tr>
<th>ID</th>
<th>User Name</th>
<th>Name</th>
<th>Contacts</th>
<th>Role</th>
<th>Department</th>
<th>Hire Date/ Employee ID</th>
<th>Is Active</th>
<th>Created At</th>
<th>Updated At</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach ($results as $key => $result) { ?>
<tr>
<td><?= $result->UserID; ?></td>
<td><?= $result->UserName; ?></td>
<td><?= $result->FirstName; ?> <?= $result->LastName; ?></td>
<td><?= $result->Email; ?> <?= $result->PhoneNumber; ?></td>
<td><?= $result->system_role_name; ?></td>
<td><?= $result->employeeSectionName; ?></td>
<td><?= $result->HireDate; ?><br><?= $result->EmployeeID; ?></td>
<td>
    <span class="badge <?= $result->IsActive ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'; ?> p-2">
        <?= $result->IsActive ? 'Active' : 'Inactive'; ?>
    </span>
</td>

<td><?= date('Y-m-d', strtotime($result->CreatedAt)); ?></td>
<td><?= date('Y-m-d', strtotime($result->UpdatedAt)); ?></td>
<td>
<div class="d-flex gap-2">

<button class="btn btn-sm btn-secondary edit-user-btn"
data-id="<?= $result->UserID; ?>"
data-username="<?= $result->UserName; ?>"
data-firstname="<?= $result->FirstName; ?>"
data-lastname="<?= $result->LastName; ?>"
data-email="<?= $result->Email; ?>"
data-phone="<?= $result->PhoneNumber; ?>"
data-employeeid="<?= $result->EmployeeID; ?>"
data-role="<?= $result->Role; ?>"
data-section="<?= $result->Department; ?>"
data-hiredate="<?= $result->HireDate; ?>"
data-isactive="<?= $result->IsActive; ?>"
data-bs-toggle="modal"
data-bs-target="#editModal">
<i class="fa fa-pencil"></i> Edit
</button>

</div>
</td>
</tr>
<?php } ?>
</tbody>
</table>



</div>
</div>
</div>
<!--end col-->
</div>





<div class="modal fade zoomIn" id="exampleModalgrid" tabindex="-1" aria-labelledby="exampleModalgridLabel" aria-modal="true">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalgridLabel">Create New User Account</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form id="createUserForm">
<div class="alert alert-danger" id="createError" style="display:none;"></div>
<div class="row g-3">

<div class="col-md-4">
<label for="UserName" class="form-label">User Name</label>
<input type="text" class="form-control" id="userName" name="userName" placeholder="Enter User Name" required>
</div>

<div class="col-md-4">
<label for="FirstName" class="form-label">First Name</label>
<input type="text" class="form-control" id="firstName" name="firstName" placeholder="Enter First Name" required>
</div>

<div class="col-md-4">
<label for="LastName" class="form-label">Last Name</label>
<input type="text" class="form-control" id="lastName" name="lastName" placeholder="Enter Last Name" required>
</div>

<div class="col-md-4">
<label for="Role" class="form-label">Role</label>
<select class="form-select" id="role" name="role" required>
<option value="0" selected>Select User Role</option>
<?php
foreach ($roles as $role) {
if ($role->isDeleted == 0) {
echo '<option value="' . $role->system_role_id . '">' . $role->system_role_name . '</option>';
}
}
?>
</select>
</div>

<div class="col-md-4">
<label for="Department" class="form-label">Department/Section</label>
<select class="form-select" id="section" name="section" required>
<option value="0" selected>Select Department</option>
<?php
foreach ($sections as $section) {
if ($section->isDeleted == 0) {
echo '<option value="' . $section->employeeSectionId . '">' . $section->employeeSectionName . '</option>';
}
}
?>
</select>
</div>

<div class="col-md-4">
<label for="EmployeeID" class="form-label">Employee ID</label>
<input type="text" class="form-control" id="employeeID" name="employeeID" placeholder="Enter Employee ID">
</div>

<div class="col-md-6">
<label for="Email" class="form-label">Email</label>
<input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required>
</div>

<div class="col-md-6">
<label for="PhoneNumber" class="form-label">Phone Number</label>
<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number" required>
</div>

<div class="col-md-6">
<label for="Password" class="form-label">Password</label>
<input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
</div>

<div class="col-md-6">
<label for="Password" class="form-label">Confirm Password</label>
<input type="password" class="form-control" id="password2" name="password2" placeholder="Confirm Password" required>
</div>

<div class="col-md-4">
<label for="HireDate" class="form-label">Hire Date</label>
<input type="date" class="form-control" id="hireDate" name="hireDate" required>
</div>

<div class="col-md-4">
<label for="IsActive" class="form-label">Is Active</label>
<select class="form-select" id="isActive" name="isActive" required>
<option value="1" selected>Active</option>
<option value="0">Inactive</option>
</select>
</div>

<div class="col-lg-12">
<div class="hstack gap-2 justify-content-end">
<button type="button" class="btn btn-link link-danger fw-medium shadow-none" data-bs-dismiss="modal">Close</button>
<button type="button" class="btn btn-success" id="saveUserBtn">Save User</button>
</div>
</div>
</div>
</form>
</div>

</div>
</div>
</div>


<!-- Update Category Modal -->
<div class="modal fade zoomIn" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-modal="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="editModalLabel">Edit User</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body">
<form id="editUserForm">
<input type="hidden" id="editUserId" name="userID">
<div class="alert alert-danger" id="editError" style="display:none;"></div>

<div class="row g-3">
<div class="col-md-4">
<label for="editUserName" class="form-label">User Name</label>
<input type="text" class="form-control" id="editUserName" name="userName" required disabled> 
</div>

<div class="col-md-4">
<label for="editFirstName" class="form-label">First Name</label>
<input type="text" class="form-control" id="editFirstName" name="firstName" required>
</div>

<div class="col-md-4">
<label for="editLastName" class="form-label">Last Name</label>
<input type="text" class="form-control" id="editLastName" name="lastName" required>
</div>

<div class="col-md-4">
<label for="editRole" class="form-label">Role</label>
<select class="form-select" id="editRole" name="role" required>
<option value="0">Select User Role</option>
<?php
foreach ($roles as $role) {
if ($role->isDeleted == 0) {
echo '<option value="' . $role->system_role_id . '">' . $role->system_role_name . '</option>';
}
}
?>
</select>
</div>

<div class="col-md-4">
<label for="editSection" class="form-label">Department/Section</label>
<select class="form-select" id="editSection" name="section" required>
<option value="0">Select Department</option>
<?php
foreach ($sections as $section) {
if ($section->isDeleted == 0) {
echo '<option value="' . $section->employeeSectionId . '">' . $section->employeeSectionName . '</option>';
}
}
?>
</select>
</div>

<div class="col-md-4">
<label for="editEmployeeID" class="form-label">Employee ID</label>
<input type="text" class="form-control" id="editEmployeeID" name="employeeID">
</div>

<div class="col-md-6">
<label for="editEmail" class="form-label">Email</label>
<input type="email" class="form-control" id="editEmail" name="email" required>
</div>

<div class="col-md-6">
<label for="editPhone" class="form-label">Phone Number</label>
<input type="text" class="form-control" id="editPhone" name="phone" required>
</div>

<div class="col-md-4">
<label for="editHireDate" class="form-label">Hire Date</label>
<input type="date" class="form-control" id="editHireDate" name="hireDate" required>
</div>

<div class="col-md-4">
<label for="editIsActive" class="form-label">Is Active</label>
<select class="form-select" id="editIsActive" name="editIsActive" required>
<option value="1">Active</option>
<option value="0">Inactive</option>
</select>
</div>

<div class="col-lg-12">
<div class="hstack gap-2 justify-content-end">
<button type="button" class="btn btn-link link-danger fw-medium shadow-none" data-bs-dismiss="modal">Close</button>
<button type="button" class="btn btn-warning" id="updateBtn">Update User</button>
</div>
</div>
</div> <!-- End row -->
</form>
</div>
</div>
</div>
</div>



</div>
</div>
</div>
<!--end row-->

<script type="text/javascript">
// Initialize DataTable
$('#table1').DataTable({
"lengthMenu": [
[150, 250, 500, -1],
[150, 250, 500, "All"]
],
searching: true,
responsive: true
});

$('#saveUserBtn').click(function(e) {
e.preventDefault();

$.ajax({
url: "<?php echo base_url('saveSystemUser'); ?>",
method: "POST",
data: $('#createUserForm').serialize(),
dataType: 'json',
success: function(response) {
if (response.status === 'success') {
Swal.fire('Saved!', response.message, 'success').then(() => {
location.reload(); // Or reset form / close modal as you need
});
} else {
$('#createError').html(response.message).show();
}
},
error: function() {
Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
}
});
});



$(document).on('click', '#updateBtn', function () {
// Get form data
let userId = $('#editUserId').val();
let userName = $('#editUserName').val();
let firstName = $('#editFirstName').val();
let lastName = $('#editLastName').val();
let email = $('#editEmail').val();
let phone = $('#editPhone').val();
let employeeID = $('#editEmployeeID').val();
let role = $('#editRole').val();
let section = $('#editSection').val();
let hireDate = $('#editHireDate').val();
let isActive = $('#editIsActive').val();

// Validation (Optional: You can add your own validation logic here)
if (!userName || !firstName || !lastName || !email || !phone) {
Swal.fire('Error!', 'All fields are required.', 'error');
return;
}

let formData = {
userId: userId,
userName: userName,
firstName: firstName,
lastName: lastName,
email: email,
phone: phone,
employeeID: employeeID,
role: role,
section: section,
hireDate: hireDate,
isActive: isActive
};

$.ajax({
url: "<?php echo base_url('updateSystemUser'); ?>",
type: "POST",
data: formData,
success: function (response) {
let res = JSON.parse(response);
if (res.status === 'success') {
Swal.fire('Success!', res.message, 'success').then(() => {
location.reload(); // Reload page or update the table
});
} else {
Swal.fire('Error!', res.message, 'error');
}
},
error: function () {
Swal.fire('Error!', 'Something went wrong. Please try again later.', 'error');
}
});
});


$(document).on('click', '.edit-user-btn', function () {
// Get data attributes
let userId = $(this).data('id');
let userName = $(this).data('username');
let firstName = $(this).data('firstname');
let lastName = $(this).data('lastname');
let email = $(this).data('email');
let phone = $(this).data('phone');
let employeeID = $(this).data('employeeid');
let role = $(this).data('role');
let section = $(this).data('section');
let hireDate = $(this).data('hiredate');
let isActive = $(this).data('isactive');

// Populate the modal fields
$('#editUserId').val(userId);
$('#editUserName').val(userName);
$('#editFirstName').val(firstName);
$('#editLastName').val(lastName);
$('#editEmail').val(email);
$('#editPhone').val(phone);
$('#editEmployeeID').val(employeeID);
$('#editRole').val(role);
$('#editSection').val(section);
$('#editHireDate').val(hireDate);
$('#editIsActive').val(isActive);
});

</script>