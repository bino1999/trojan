<?php
$jobCurrentStatus = $jobData->status;
// Initialize total counters
$serviceCost = 0;
$spareCost = 0;
$subTotal = 0;
$totalCost = 0;
$receivedAmount = 0;
$balanceAmount = 0;
foreach ($jobItems as $item) {
    if ($item->item_type == 'service') {
        $serviceCost += $item->total_price; // Add service cost
    } elseif ($item->item_type == 'product') {
        $spareCost += $item->total_price; // Add spare part cost
    }
}

// Calculate the total cost
$subTotal = $serviceCost + $spareCost;
?>

<div class="container">
    <!-- Scrollable Table Container -->
    <div class="table-container">
        <table id="table2" class="table table-striped table-sm table-hover table-responsive">
            <thead class="table-warning">
                <tr>
                    <th class="text-center">##</th>
                    <th class="text-center">Description</th>
                    <th class="text-end">Qty</th>
                    <th class="text-end">Price</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Amount</th>
                    <th class="text-end"><i class="fa fa-trash"></i></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $confirm_item = 0;
                $none_confirm_item = 0;
                $totalItemDiscuntedAmount = 0;
                foreach ($jobItems as $item) {
                    if ($item->item_type == 'service') {
                        $item_name = $item->item_name;
                    } elseif ($item->item_type == 'sparepart') {
                        $item_name = $item->package_name;
                    } elseif ($item->item_type == 'product') {
                        $item_name = $item->product_name.'<br><small>'.$item->sku.'</small>';
                    } elseif ($item->item_type == 'labour') {
                        $item_name = $item->description;
                    } elseif ($item->item_type == 'other') {
                        $item_name = $item->description;
                    } else {
                        $item_name = 'Unknown Item Type';
                    }

                    $package_id = 0;
                    if ($item->package_id > 0) {
                        $package_id = $item->package_id;
                    }
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $item_name ?></td>
                        <td class="text-end"><?= $item->quantity ?></td>
                        <td class="text-end"><?= number_format($item->price, 2) ?></td>
                        <?php
                        $display_value = '0%';
                        $discount = 0;

                        if ($item->discount_percent > 0) {
                            $discount = ($item->price * $item->discount_percent / 100) * $item->quantity;
                            $display_value = $item->discount_percent . '%';
                        } elseif ($item->discount_amount > 0) {
                            $discount = $item->discount_amount * $item->quantity;
                            $display_value = number_format($item->discount_amount, 2);
                        }

                        $totalItemDiscuntedAmount += $discount;
                        ?>

                        <td class="text-end" style="cursor: pointer;"
                            onclick="openDiscountModal(<?= $item->id ?>, '<?= htmlspecialchars($item_name, ENT_QUOTES) ?>', <?= $item->discount_percent ?>, <?= $item->discount_amount ?>)">
                            <?= $display_value ?>
                        </td>

                        <td class="text-end"><?= number_format($item->total_price, 2) ?></td>
                        <td class="text-end">
                            <?php if ($jobCurrentStatus < 4  && $item->confirmed_by == 0) { ?>
                                <button class="btn btn-danger btn-sm" id="delete_<?= $item->id ?>" onclick="deleteJobItem(<?= $item->id ?>,<?= $package_id ?>,<?= $item->service_job_id ?>)">
                                    <i class="fa fa-trash"></i>
                                </button>
                            <?php } ?>

                            <?php if ($jobCurrentStatus == 4 && $item->confirmed_by > 0) {
                                $confirm_item++;
                            ?>
                                <button class="btn btn-warning btn-sm" id="confirm_<?= $item->id ?>" onclick="confirmJobItem(<?= $item->id ?>, 0)">
                                    <i class="fa fa-undo"></i>
                                </button>
                            <?php } ?>

                            <?php if ($jobCurrentStatus == 4 && $item->confirmed_by == 0) {
                                $none_confirm_item++;
                            ?>
                                <button class="btn btn-info btn-sm" id="confirm_<?= $item->id ?>" onclick="confirmJobItem(<?= $item->id ?>, 1)">
                                    <i class="fa fa-check"></i>
                                </button>
                            <?php } ?>

                        </td>
                    </tr>
                <?php } ?>
                <tr>
                    <td colspan="4" class="text-end"><strong>Total Discount:</strong></td>
                    <td class="text-end text-danger"><strong><?= number_format($totalItemDiscuntedAmount, 2) ?></strong></td>
                    <td></td>
                    <td></td>
                </tr>

            </tbody>
        </table>
    </div>


    <?php
    $final_total_amount = $subTotal;
    $bill_discounted_amount = 0;

    $job_id = isset($jobData->job_id) ? $jobData->job_id : 0;
    $job_cost = isset($jobData->job_cost) ? $jobData->job_cost : 0;
    $job_discount_percent = isset($jobData->discount_percent) ? $jobData->discount_percent : 0;
    $job_discount_amount = isset($jobData->discount_amount) ? $jobData->discount_amount : 0;
    $job_final_bill_amount = isset($jobData->final_bill_amount) ? $jobData->final_bill_amount : 0;
    $job_total_paid = isset($jobData->total_paid) ? $jobData->total_paid : 0;
    $job_total_balance = isset($jobData->total_balance) ? $jobData->total_balance : 0;


    if ($job_discount_percent > 0) {
        $bill_discounted_amount = ($subTotal * $job_discount_percent) / 100;
        $final_total_amount = $subTotal - $bill_discounted_amount;
    }

    if ($job_discount_amount > 0) {
        $final_total_amount = $subTotal - $job_discount_amount;
    }

    $receivedAmount = isset($jobPayment->total_payment) ? $jobPayment->total_payment : 0;


    $balanceAmount = $final_total_amount - $receivedAmount;

    //update the job data with the calculated values
    if ($job_cost != $subTotal || $job_final_bill_amount != $final_total_amount || $job_total_paid != $receivedAmount || $job_total_balance != $balanceAmount) {
        $this->db->where('job_id', $job_id);
        $this->db->update('services_job', [
            'job_cost' => $subTotal,
            'final_bill_amount' => $final_total_amount,
            'total_paid' => $receivedAmount,
            'total_balance' => $balanceAmount
        ]);
    }

    ?>
    <!-- Bottom Section for additional features -->
    <div class="bottom-section">


        <div class="row">
            <div class="col-md-7" style="">
                <table id="table2" class="table table-striped table-responsive table-sm">
                    <tbody>
                        <tr>
                            <td class="text-left f3">Service Cost :</td>
                            <td class="text-end f3"><?= number_format($serviceCost, 2) ?> &nbsp;&nbsp; LKR</td>
                        </tr>
                        <tr>
                            <td class="text-left f3">Spare Cost :</td>
                            <td class="text-end f3"><?= number_format($spareCost, 2) ?> &nbsp;&nbsp; LKR</td>
                        </tr>
                        <tr>
                            <td class="text-left f3">Item Discounts Total:</td>
                            <td class="text-end f3 text-danger"><?= number_format($totalItemDiscuntedAmount, 2) ?> &nbsp;&nbsp; LKR</td>
                        </tr>
                        <tr>
                            <td class="text-left f3">Sub Total :</td>
                            <td class="text-end f3"><?= number_format($subTotal, 2) ?> &nbsp;&nbsp; LKR</td>
                        </tr>


                        <?php if ($jobData->status > 3) { ?>
                            <tr>
                                <td class="text-left f3">Invoice Discount Amount <?= $job_discount_percent ?>%:</td>
                                <?php if($job_discount_amount>0){ ?>
                                <td class="text-end f3"><?= number_format($job_discount_amount, 2) ?> &nbsp;&nbsp; LKR</td>
                                <?php }else{ ?>
                                    <td class="text-end f3"><?= number_format($bill_discounted_amount, 2) ?> &nbsp;&nbsp; LKR</td>
                                    <?php } ?>
                            </tr>
                            <tr>
                                <td class="text-left f3">Total:</td>
                                <td class="text-end f3"><?= number_format($final_total_amount, 2) ?> &nbsp;&nbsp; LKR</td>
                            </tr>
                            <tr>
                                <td class="text-left f3">Received Amount:</td>
                                <td class="text-end f3"><?= number_format($receivedAmount, 2) ?> &nbsp;&nbsp; LKR</td>
                            </tr>
                            <tr>
                                <td class="text-left f3">Balance Amount:</td>
                                <td class="text-end f3"><?= number_format($balanceAmount, 2) ?> &nbsp;&nbsp; LKR</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>


                <?php if ($jobData->status > 4 && $receivedAmount == 0 ) { ?>
                    <!-- add discount rate and discount amount and add button to same row -->
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <label for="discountRate" class="f4">Discount Rate:</label>
                            <input type="number" value="<?= $job_discount_percent ?>" id="discountRate" class="form-control" placeholder="Discount Rate" style="width: 100%;">
                        </div>
                        <div class="col-md-5">
                            <label for="discountAmount" class="f4">Discount Amount:</label>
                            <input type="number" value="<?= $job_discount_amount ?>" id="discountAmount" class="form-control" placeholder="Discount Amount" style="width: 100%;">
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-primary mt-4" id="addDiscountButton" onclick="addDiscount()">Add</button>
                        </div>
                    </div>
                <?php } ?>
            </div> <!-- end of first column -->


            <div class="col-md-5" style="border-left: 2px solid #044756">
    <?php if ($jobData->status > 4 && $balanceAmount > 0) { ?>

        <!-- Payment Method & Paid Amount in same row -->
        <div class="row mt-3">
            <div class="col-md-6">
                <label for="paymentMethod" class="f4">Payment Method:</label>
                <select id="paymentMethod" class="form-select" onchange="showBankChequeFields()">
                    <option value="" disabled selected>Select Payment Method</option>
                    <option value="cash">Cash Payment</option>
                    <option value="card">Card Payment</option>
                    <option value="credit">Credit Payment</option>
                    <option value="cheque">Cheque Payment</option>
                    <option value="bank_transfer">Bank Transfer</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="paidAmount" class="f4">Paid Amount:</label>
                <input type="number" id="paidAmount" class="form-control" placeholder="Enter Paid Amount" value="<?= $balanceAmount ?>">
            </div>
        </div>

        <!-- Bank & Cheque fields (same row) -->
        <div class="row" id="bankChequeFields" style="display: none;">
            <div class="col-md-12 mt-3">
                <label for="bankName" class="f4">Bank Name:</label>
                <input type="text" id="bankName" class="form-control" placeholder="Enter Bank Name">
            </div>
            <div class="col-md-12 mt-3">
                <label for="chequeNumber" class="f4">Cheque No/Transaction ID:</label>
                <input type="text" id="chequeNumber" class="form-control" placeholder="Transaction ID / Cheque No">
            </div>
            <div class="col-md-12 mt-3" id="chequeDateField">
                <label for="chequeDate" class="f4">Cheque Date:</label>
                <input type="date" id="chequeDate" class="form-control">
            </div>
        </div>

<!-- For credit payments -->
        <div class="row" id="creditFields" style="display: none;">
            <div class="col-md-12 mt-3">
                <label for="creditPersonName" class="f4">Name Of Person:</label>
                <input type="text" id="creditPersonName" class="form-control" placeholder="Name Of Person">
            </div>
            <div class="col-md-12 mt-3">
                <label for="creditPayDate" class="f4">Date Of Payment:</label>
                <input type="date" id="creditPayDate" class="form-control" placeholder="Date Of Payment" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="col-md-12 mt-3">
                <label for="creditRemark" class="f4">Note/Remark/Document No:</label>
                <input type="text" id="creditRemark" class="form-control" placeholder="Enter Remark">
            </div>
        </div>

        <!-- Payment buttons -->
        <div class="row mt-3">
            <div class="col-md-6">
                <button class="btn btn-success w-100" onclick="makePayment()">Make Payment</button>
            </div>
            <div class="col-md-6">
                <button class="btn btn-danger w-100" onclick="location.reload()">Cancel</button>
            </div>
        </div>


    <?php } else { ?>
        <div class="mt-3 text-danger d-none">
            <strong>Cannot Make Payment as Job is not Confirmed</strong>
        </div>
    <?php } ?>

    <!-- Print Invoice -->
    <?php
     if ($jobData->print_access_by > 0) { ?>
    <?php if ($jobData->is_credit > 0 || $balanceAmount == 0) { ?>
        <div class="row mt-3">
            <div class="col-md-6">
                <a class="btn btn-primary w-100" target="_blank" href="<?= base_url('print-job-mini/' . urlencode(base64_encode($job_id))) ?>">
                    <i class="fa fa-print"></i> Mini Invoice
                </a>
            </div>
            <div class="col-md-6">
                <a class="btn btn-primary w-100" target="_blank" href="<?= base_url('print-job/' . urlencode(base64_encode($job_id))) ?>">
                    <i class="fa fa-print"></i> A4 Invoice
                </a>
            </div>
        </div>
    <?php } ?>
    <?php } ?>

    <!-- Confirm Job -->
    <?php if ($jobData->confirmed_by == 0 && $jobData->status == 4) { ?>
        <div class="row mt-3">
            <div class="col-md-12">
                <button type="button" onclick="showConfirmAccessModal()" class="btn btn-success w-100">
                    <i class="ri-check-double-line me-2"></i> Confirm & Complete This Job
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- Add Print Access (hidden) -->
    <?php if ($jobData->print_access_by == 0 && $jobData->status > 4) { ?>
        <div class="row mt-3 d-none">
            <div class="col-md-12">
                <button type="button" onclick="showPrintAccessModal()" class="btn btn-success w-100">
                    <i class="ri-check-double-line me-2"></i> Add Print Access
                </button>
            </div>
        </div>
    <?php } ?>

    <!-- Change Job Status -->
    <?php if ($receivedAmount == 0 ) { ?>
    <?php if ($jobData->status < 4 || $this->session->userdata('role') == 1) { ?>
        <div class="row mt-4">
            <div class="col-md-6">
                <select id="job_new_status" class="form-select">
                    <option value="" disabled selected>Select Job Status</option>
                    <option value="0" <?= $jobData->status == 0 ? 'selected' : '' ?>>Pending</option>
                    <option value="1" <?= $jobData->status == 1 ? 'selected' : '' ?>>Ongoing</option>
                    <option value="2" <?= $jobData->status == 2 ? 'selected' : '' ?>>Hold</option>
                    <option value="3" <?= $jobData->status == 3 ? 'selected' : '' ?>>Cancelled</option>
                    <option value="4" <?= $jobData->status == 4 ? 'selected' : '' ?>>Completed</option>
                </select>
            </div>
            <div class="col-md-6">
                <button class="btn btn-info w-100" onclick="changeJobStatus()">Change Status</button>
            </div>
        </div>
    <?php }  } ?>
</div>

        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-12">
            <h5 class="text-center">Job Payment History</h5>

            <table id="table1" class="table table-striped table-responsive table-sm">
                <thead class="table-primary">
                    <tr>
                        <th class="text-center">#</th>
                        <th class="text-center">Payment Method</th>
                        <th class="text-center">Paid Amount</th>
                        <th class="text-center">Bank Name</th>
                        <th class="text-center">Cheque No/Transaction ID</th>
                        <th class="text-center">Cheque Status</th>
                        <th class="text-center">Date</th>
                        <th class="text-center">User</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    $totalPaidPfor_summary = 0;
                    foreach ($paymentHistory as $payment) {
                        $totalPaidPfor_summary += $payment->paid_amount;
                        echo '<tr>';
                        echo '<td class="text-center">' . $i . '</td>';
                        echo '<td class="text-center">' . $payment->payment_method . '</td>';
                        echo '<td class="text-end">' . number_format($payment->paid_amount, 2) . '</td>';
                        echo '<td class="text-center">' . $payment->bank_name . '</td>';
                        echo '<td class="text-center">' . $payment->cheque_number . '</td>';
                        //here cheque_return_by >0 show bounced
                        if ($payment->cheque_return_by > 0) {
                            echo '<td class="text-center text-danger">Bounced</td>';
                        } else {
                            echo '<td class="text-center text-success">Not Bounced</td>';
                        }
                        echo '<td class="text-center">' . $payment->payment_date . '</td>';
                        echo '<td class="text-center">' . $payment->UserName . '</td>';
                        echo '</tr>';
                        $i++;
                    }

                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="2" class="text-start">Total Paid:</th>
                        <th class="text-end"><?= number_format($totalPaidPfor_summary, 2) ?></th>
                        <th colspan="3"></th>
                    </tr>
            </table>
        </div>
    </div>


    <script>

        function makePayment() {
            var paymentMethod = document.getElementById("paymentMethod").value;
            var paidAmount = document.getElementById("paidAmount").value;
            var bankName = document.getElementById("bankName").value;
            var chequeNumber = document.getElementById("chequeNumber").value;
            var chequeDate = document.getElementById("chequeDate").value;

            var creditPersonName = document.getElementById("creditPersonName").value;
            var creditRemark = document.getElementById("creditRemark").value;
            var creditPayDate = document.getElementById("creditPayDate").value;

            var jobId = $('#job_id').val();

            // Perform validation
            if (paymentMethod === "") {
                Toastify({
                    text: 'Please select a payment method.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }
            
            if ((paymentMethod === "cheque" || paymentMethod === "bank_transfer" || paymentMethod === "card") && (bankName === "" || chequeNumber === "")) {
                Toastify({
                    text: 'Please enter bank name and cheque/card number.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }

            // Show confirmation dialog
            Swal.fire({
                title: 'Confirm Payment',
                text: `Are you sure you want to make a payment of LKR ${paidAmount} using ${paymentMethod}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, proceed!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If user confirms, proceed with AJAX request
                    $.ajax({
                        url: "<?php echo site_url('job/addPaymentToJob') ?>",
                        type: "POST",
                        data: {
                            jobId: jobId,
                            paymentMethod: paymentMethod,
                            paidAmount: paidAmount,
                            bankName: bankName,
                            chequeNumber: chequeNumber,
                            chequeDate: chequeDate,
                            creditPersonName: creditPersonName,
                            creditRemark: creditRemark,
                            creditPayDate: creditPayDate
                        },
                        success: function(response) {
                            var res = JSON.parse(response);
                            if (res.status === 'success') {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-success",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                                loadJobItems();
                            } else {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-error",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            Toastify({
                                text: 'An error occurred while processing the payment.',
                                className: "toastify-error",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                        }
                    });
                } else {
                    // If user cancels the confirmation
                    Toastify({
                        text: 'Payment was not processed.',
                        className: "toastify-info",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                }
            });
        }

        function showConfirmAccessModal() {
            var jobId = $('#job_id').val();
            var confirmItems = "<?php echo $confirm_item; ?>";
            var noneConfirmItems = "<?php echo $none_confirm_item; ?>";

            if (confirmItems == 0 && noneConfirmItems == 0) {
                Toastify({
                    text: 'Please add items to make invoice.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }

            if (noneConfirmItems > 0) {
                Toastify({
                    text: 'Please confirm all items before making invoice.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }

            Swal.fire({
                title: 'Confirm & Make Invoice',
                text: 'Are you sure you want to make a invoice:',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Save',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If user confirms, proceed with AJAX request
                    var print_access_by = $('#print_access_by').val();
                    $.ajax({
                        url: "<?php echo site_url('job/confirmJob') ?>",
                        type: "POST",
                        data: {
                            jobId: jobId,
                            print_access_by: print_access_by
                        },
                        success: function(response) {
                            var res = JSON.parse(response);
                            if (res.status === 'success') {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-success",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                                loadJobItems();
                                closeAddItemModal();
                                loadServicesJobs();

                            } else {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-error",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            Toastify({
                                text: 'An error occurred while processing the payment.',
                                className: "toastify-error",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                        }
                    });
                }
            })
        }

        function showPrintAccessModal() {
            var jobId = $('#job_id').val();

            Swal.fire({
                title: 'Add Print Access',
                text: 'Are you sure you want to add print access:',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Save',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If user confirms, proceed with AJAX request
                    var print_access_by = $('#print_access_by').val();
                    $.ajax({
                        url: "<?php echo site_url('job/addPrintAccess') ?>",
                        type: "POST",
                        data: {
                            jobId: jobId,
                            print_access_by: print_access_by
                        },
                        success: function(response) {
                            var res = JSON.parse(response);
                            if (res.status === 'success') {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-success",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                                loadJobItems();
                                loadServicesJobs();
                            } else {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-error",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            Toastify({
                                text: 'An error occurred while processing the payment.',
                                className: "toastify-error",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                        }
                    });
                }
            })
        }


        function changeJobStatus() {
            var jobId = $('#job_id').val();
            var jobStatus = document.getElementById("job_new_status").value;
            //get job status text
            var jobStatusText = document.getElementById("job_new_status").options[document.getElementById("job_new_status").selectedIndex].text;

            Swal.fire({
                title: 'Confirm Status Change',
                text: `Are you sure you want to change the status to ${jobStatusText}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, proceed!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If user confirms, proceed with AJAX request
                    $.ajax({
                        url: "<?php echo site_url('job/updateJobStatus') ?>",
                        type: "POST",
                        data: {
                            jobId: jobId,
                            jobStatus: jobStatus
                        },
                        success: function(response) {
                            var res = JSON.parse(response);
                            if (res.status === 'success') {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-success",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                                closeAddItemModal();
                                loadServicesJobs();
                            } else {
                                Toastify({
                                    text: res.message,
                                    className: "toastify-error",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "right"
                                }).showToast();
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            Toastify({
                                text: 'An error occurred while processing the payment.',
                                className: "toastify-error",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                        }
                    });
                } else {
                    // If user cancels the confirmation
                    Toastify({
                        text: 'Status was not changed.',
                        className: "toastify-info",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                }
            });
        }

        function confirmJobItem(jobItemId, status) {

            if (status > 0) {
                var buttonId = 'confirm_' + jobItemId;
              //  var deleteButtonId = 'delete_' + jobItemId;
                //disable button
                document.getElementById(buttonId).disabled = true;
                //document.getElementById(deleteButtonId).disabled = true;
            } else {

            }

            $.ajax({
                url: "<?php echo site_url('job/confirmJobItem') ?>",
                type: "POST",
                data: {
                    jobItemId: jobItemId,
                    status: status
                },
                success: function(response) {
                    var res = JSON.parse(response);
                    if (res.status === 'success') {
                        loadJobItems();
                        Toastify({
                            text: res.message,
                            className: "toastify-success",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "right"
                        }).showToast();
                        // closeAddItemModal();
                        // loadServicesJobs();
                    } else {
                        Toastify({
                            text: res.message,
                            className: "toastify-error",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "right"
                        }).showToast();
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    Toastify({
                        text: 'An error occurred while processing the payment.',
                        className: "toastify-error",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                }
            });
        }

        function showBankChequeFields() {
            var paymentMethod = document.getElementById("paymentMethod").value;
            var bankChequeFields = document.getElementById("bankChequeFields");
            var balanceAmount = "<?= $balanceAmount ?>";
            document.getElementById("paidAmount").value = balanceAmount;
            

            if (paymentMethod === "cheque" || paymentMethod === "bank_transfer" || paymentMethod === "card") {
                bankChequeFields.style.display = "block";
            } else {
                bankChequeFields.style.display = "none";
                document.getElementById("bankName").value = ""; // Clear the bank name field
                document.getElementById("chequeNumber").value = ""; // Clear the cheque number field
            }

            if (paymentMethod === "cheque") {
                chequeDateField.style.display = "block";
            } else {
                chequeDateField.style.display = "none";
                document.getElementById("chequeDate").value = "";
            }


            if (paymentMethod === "credit") {
                creditFields.style.display = "block";
                document.getElementById("paidAmount").value = 0
            } else {
                creditFields.style.display = "none";
                document.getElementById("creditPersonName").value = "";
                document.getElementById("creditRemark").value = "";
            }

        }


        function addDiscount() {
            var discountRate = document.getElementById("discountRate").value;
            var discountAmount = document.getElementById("discountAmount").value;
            var jobId = $('#job_id').val();

            if (discountRate === "" && discountAmount === "") {
                Toastify({
                    text: 'Please enter a discount rate or amount.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }

            if (discountRate > 0 && discountAmount > 0) {
                Toastify({
                    text: 'Please enter either a discount rate or amount, not both.',
                    className: "toastify-error",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();
                return;
            }

            if (discountRate > 0) {
                discountAmount = null;
            } else if (discountAmount > 0) {
                discountRate = null;
            }

            $.ajax({
                url: "<?php echo site_url('job/addDiscountToJob') ?>",
                type: "POST",
                data: {
                    jobId: jobId,
                    discountRate: discountRate,
                    discountAmount: discountAmount
                },
                success: function(response) {

                    var res = JSON.parse(response);

                    if (res.status === 'success') {
                        Toastify({
                            text: res.message,
                            className: "toastify-success",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "right"
                        }).showToast();

                        loadJobItems();
                    } else {
                        Toastify({
                            text: res.message,
                            className: "toastify-error",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "right"
                        }).showToast();
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    Toastify({
                        text: 'An error occurred while processing the discount.',
                        className: "toastify-error",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                }
            });

        }



        function openDiscountModal(itemId, itemName, currentDiscount, discount_amount) {
            // Set all the values
            $('#editItemId').val(itemId);
            $('#editItemName').val(itemName);

            if (currentDiscount > 0) {
                $('#currentDiscount').val(currentDiscount + '%');
            }

            if (discount_amount > 0) {
                $('#currentDiscount').val(discount_amount + ' LKR');
            }

            $('#newDiscount').val(currentDiscount);
            $('#newDiscountAmount').val(discount_amount);
            // Reset error messages
            $('#discountError').hide();
            $('#discountAmountError').hide();

            // Show the modal
            $('#discountModal').modal('show');

            // Focus after modal is fully shown
            $('#discountModal').on('shown.bs.modal', function() {
                $('#newDiscount').trigger('focus').select();
            });
        }

        $(document).ready(function() {
            $('#saveDiscountBtn').click(function() {
                var btn = $(this);
                var itemId = $('#editItemId').val();
                var newDiscount = $('#newDiscount').val();
                var newDiscountAmount = $('#newDiscountAmount').val();
                $('#discountError').hide();
                $('#discountAmountError').hide();

                if (newDiscount === '' || newDiscount < 0 || newDiscount > 100) {
                    $('#discountError').show();
                    return;
                }

                if (newDiscountAmount === '' || newDiscountAmount < 0) {
                    $('#discountAmountError').show();
                    return;
                }

                //check if have values for both discount and discount amount
                if (newDiscount > 0 && newDiscountAmount > 0) {
                    Toastify({
                        text: 'Please enter either a discount percentage or amount, not both.',
                        className: "toastify-error",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                    return;
                }

                btn.html('<i class="fa fa-spinner fa-spin"></i> Saving...');
                btn.prop('disabled', true);

                $.ajax({
                    url: '<?= site_url("job/updateItemDiscount") ?>',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        item_id: itemId,
                        discount: newDiscount,
                        discount_amount: newDiscountAmount
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#discountModal').modal('hide');
                            Toastify({
                                text: response.message,
                                className: "toastify-success",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                            loadJobItems();
                        } else {
                            Toastify({
                                text: response.message,
                                className: "toastify-error",
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "right"
                            }).showToast();
                        }
                    },
                    error: function(xhr) {
                        alert('Error: ' + xhr.statusText);
                    },
                    complete: function() {
                        // Reset button state
                        btn.html('Save Changes');
                        btn.prop('disabled', false);
                    }
                });
            });

            // Allow pressing Enter in discount field
            $('#newDiscount').keypress(function(e) {
                if (e.which === 13) {
                    $('#saveDiscountBtn').click();
                    return false;
                }
            });
        });
    </script>



    <!-- Discount Edit Modal -->
    <div class="modal fade" id="discountModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered zoomIn" role="document">
            <div class="modal-content">
                <div class="alert alert-primary shadow" role="alert">
                    <div class="modal-header">
                        <h5 class="modal-title" id="discountModalLabel">Update Discount</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"> </button>
                    </div>
                    <div class="modal-body">

                        <form id="discountForm">
                            <input type="hidden" id="editItemId">
                            <div class="form-group">
                                <label>Item Name</label>
                                <input type="text" class="form-control" id="editItemName" readonly>
                            </div>
                            <div class="form-group my-2">
                                <label>Current Discount</label>
                                <input type="text" class="form-control" id="currentDiscount" readonly>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <label>New Discount - Percentage (%)</label>
                                    <input type="number" class="form-control" id="newDiscount" min="0" max="100" required>
                                    <small class="text-danger" id="discountError" style="display:none">Please enter 0-100</small>
                                </div>
                                <div class="col-md-6">
                                    <label>New Discount - Amount</label>
                                    <input type="number" class="form-control" id="newDiscountAmount" min="0" required>
                                    <small class="text-danger" id="discountAmountError" style="display:none">Please enter valid amount</small>
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="saveDiscountBtn">Save Changes</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .f3 {
            font-size: 1em;
            font-weight: bold;
            color: #fff;
        }

        .f4 {
            font-size: 1em;
            font-weight: 500;
            color: rgb(18, 20, 20);
        }

        f55 {
            color: rgb(202, 0, 0);
            font-size: 0.8rem;
            font-weight: 600;
        }

        

        .bottom-section .row {
            margin-bottom: 10px;
        }

        .bottom-section .form-control {
            width: 100%;
        }

        .bottom-section .d-flex {
            align-items: center;
            justify-content: flex-end;
        }

        .bottom-section button {
            margin-left: 10px;
        }
    </style>