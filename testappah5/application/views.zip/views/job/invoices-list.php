<table id="table1" class="table table-striped table-responsive">
    <thead class="table-info">
        <tr>
        <th>##</th>
            <th>Job ID</th>
            <th>Vehicle</th>
            <th width="20%">Customer</th>
            <th>Date</th>
            <th>Type</th>
            <th>Amount</th>
            <th>Paid</th>
            <th>Balance</th>
            <th>Created</th>
            <th>Printed By</th>
            <th>Print</th>
        </tr>
    </thead>
     
    <tbody>
    <?php
        $no = 1;
        foreach ($jobs as $key => $job) { ?>
            <tr>
            <td><?= $no++; ?></td>
                <td><?= $job->job_id ?></td>
                <td><?= $job->vehicle_no ?></td>
                <td><?= $job->customer_name ?><br>
                <?= $job->job_contact_no ?></td>
                <td><?= date('Y-m-d', strtotime($job->service_date)); ?></td>

                <!--if service_type=N Normal, E=Estimate -->
                <td><?php if($job->service_type == 'N'){ ?>
                    Normal
                <?php }else if($job->service_type == 'E'){ ?>
                    Estimate
                <?php }else{ ?>
                    Unknown
                <?php } ?></td>

                
                <td class="text-end"><?= number_format($job->final_bill_amount ?? 0, 2) ?></td>
                <td class="text-end"><?= number_format($job->total_paid ?? 0, 2) ?></td>
                <td class="text-end">
                    <?= number_format($job->total_balance ?? 0, 2) ?>
                    <?php
                    if($job->total_balance > 0){
                        echo '<span class="badge bg-danger">Due</span>'; 
                    } ?>
                </td>
               
                <td><?= date('Y-m-d', strtotime($job->created_at)); ?></td>
                <td><?= $job->print_access_at ? date('Y-m-d', strtotime($job->print_access_at)) : ''; ?></td>
                <td>
                    <div class="d-flex gap-2">
                    <a class="btn btn-secondary btn-sm" target="_blank" style="width: 100%;" href="<?php echo base_url('print-job/' . urlencode(base64_encode($job->job_id))) ?>">
    <i class="fa fa-print"></i>
</a>

<a class="btn btn-warning btn-sm" target="_blank" style="width: 100%;" href="<?php echo base_url('print-job-mini/' . urlencode(base64_encode($job->job_id))) ?>">
    <i class="fa fa-print"></i>
</a>
                    </div>
                </td>
            </tr>
            <?php } ?>
    </tbody>
</table>

<style>
    

span.badge.bg-warning {
    background-color:rgb(225, 170, 5) !important;
    font-weight: 800;
}

span.badge.bg-info {
    background-color: rgb(0, 123, 255) !important;
    font-weight: 800;
}

span.badge.bg-secondary {
    background-color: rgb(1, 13, 23) !important;
    font-weight: 800;
}

span.badge.bg-danger {
    background-color: rgb(232, 0, 23) !important;
    font-weight: 800;
}

span.badge.bg-success {
    background-color: rgb(8, 165, 92) !important;
    font-weight: 800;
}
</style>

<script>
    serviceTableToDatatable();
    function serviceTableToDatatable() {
    // Destroy existing DataTable if it exists
    if ($.fn.DataTable.isDataTable('#table1')) {
        $('#table1').DataTable().destroy();
    }
    
    // Initialize new DataTable
    $('#table1').DataTable({
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        "searching": true,
        "responsive": true
    });
}
</script>
