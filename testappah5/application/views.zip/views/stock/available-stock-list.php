<div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Description</th>
                    <th>Sku</th>
                    <th>Open Balance</th>
                    <th>Stock In</th>
                    <th>Stock Out</th>
                    <th>Closing Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i = 1;
                foreach ($stock as $item) { 
                    ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= strtoupper($item->product_name) ?></td>
                        <td><?= $item->sku ?></td>
                        <td><?= $item->open_balance ?></td>
<td><?= $item->stock_in ?></td>
<td><?= $item->stock_out ?></td>
<td><?= $item->closing_balance ?></td>

                        
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>