<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Payments</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Payments</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <style>
            .mainCard {
                margin: -10px;
            }
        </style>


        <div class="card mainCard">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-2">
                        <input type="date" name="sdate" id="sdate" class="form-control" value="<?= date('Y-m-d', strtotime('-7 day')); ?>">
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="edate" id="edate" class="form-control" value="<?= date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-3">
                <select id="expenseCategory" class="form-select" onchange="loadExpenses()">
                    <option value="" selected>Select Category</option>
                    <?php
                    foreach ($expenseCategories as $category) {
                        echo '<option value="' . $category->expensesCategoryId . '">' . $category->expensesCategoryName . '</option>';
                    }
                    ?>
                </select>
            </div>

            <div class="col-md-2">
                <select id="filterSection" class="form-select" onchange="loadExpenses()">
                    <option value="" selected>Select Section</option>
                    <?php
                    foreach ($sections as $section) {
                        echo '<option value="' . $section->employeeSectionId . '">' . $section->employeeSectionName . '</option>';
                    }
                    ?>
                </select>
            </div>
                    <div class="col-md-1">
                        <button class="btn btn-primary" onclick="loadExpenses();"><i class="fa fa-search"></i></button>
                    </div>


                    <div class="col-md-2 flex-shrink-0">
                <button type="button" class="btn btn-success btn-label waves-effect waves-light" onclick="openExpenseModal()">
                        <i class="fa fa-plus label-icon align-middle fs-16 me-2"></i> Create Expense
                    </button>
                </div>
                </div>
            </div>

            <div class="card-body">
                <div id="expensesTable"></div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>



<script>
    loadExpenses();

    function loadExpenses() {
        let sdate = $('#sdate').val();
        let edate = $('#edate').val();
        let expenseCategory = $('#expenseCategory').val();
        let filterSection = $('#filterSection').val();

        if (!sdate || !edate) {
            Toastify({
    text: "Please select both start and end dates.",
    className: "toastify-success",
    duration: 5000,
    close: true,
    gravity: "top",
    position: "right"
}).showToast();
            return;
        }



        $('#expensesTable').html('<p>Loading...</p>');
        $.ajax({
            url: "<?php echo site_url('expenses/loadExpenses') ?>",
            type: "POST",
            data: {
                sdate: sdate,
                edate: edate,
                expenseCategory: expenseCategory
            },
            success: function(data) {
                $('#expensesTable').html(data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR.responseText);
                $('#expensesTable').html('<p>Error loading data.</p>');
            }
        });
    }

    function openExpenseModal() {
        $('#addExpenseModal select').select2({
            dropdownParent: $('#addExpenseModal')
        });

        $('#addExpenseModal').modal('show');
    }

    $(document).on('click', '#saveExpenseBtn', function (e) {
    e.preventDefault();
    $.ajax({
        url: "<?= base_url('expenses/saveExpense'); ?>",
        method: "POST",
        data: $('#createExpenseForm').serialize(),
        dataType: 'json',
        success: function (response) {
            if (response.status === 'success') {
                $('#addExpenseModal').modal('hide');
                Toastify({
                    text: response.message,
                    className: "toastify-success",
                    duration: 5000,
                    close: true,
                    gravity: "top",
                    position: "right"
                }).showToast();

                $('#createExpenseForm')[0].reset();
                $('#expenseError').hide();

                if (typeof loadExpenses === 'function') {
                    loadExpenses();
                }
            } else {
                $('#expenseError').html(response.message).show();
            }
        },
        error: function () {
            Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
        }
    });
});




$(document).on('click', '.delete-expense', function () {
    let id = $(this).data('id');
    Swal.fire({
        title: 'Are you sure?',
        text: "This expense will be permanently deleted.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post("<?= site_url('expenses/delete') ?>", { id: id }, function (res) {
                if (res.status === 'success') {
                    Toastify({
                        text: res.message,
                        className: "toastify-success",
                        duration: 3000
                    }).showToast();
                    loadExpenses(); // Refresh the table
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            }, 'json');
        }
    });
});

   </script>



<!-- Add Expense Modal -->
<div class="modal fade" id="addExpenseModal" tabindex="-1" aria-labelledby="addExpenseModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Expense</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="createExpenseForm">
                    <div class="row">
                        <!-- Category -->
                        <div class="col-md-12 mb-3">
                            <label for="expense_category" class="form-label">Expense Category*</label>
                            <select id="expense_category" name="expense_category" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php foreach ($expenseCategories as $cat): ?>
                                    <option value="<?= $cat->expensesCategoryId ?>"><?= $cat->expensesCategoryName ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Optional Reference Number -->
                        <div class="col-md-6 mb-3">
                            <label for="reference" class="form-label">Voucher Number</label>
                            <input type="text" class="form-control" id="reference" name="reference" placeholder="Voucher Number" required>
                        </div>

                        <!-- Amount -->
                        <div class="col-md-6 mb-3">
                            <label for="expense_amount" class="form-label">Amount*</label>
                            <input type="number" class="form-control" id="expense_amount" name="expense_amount" step="0.01" min="0" required>
                        </div>

                        <!-- Date -->
                        <div class="col-md-6 mb-3">
                            <label for="expense_date" class="form-label">Date*</label>
                            <input type="date" class="form-control" id="expense_date" name="expense_date" value="<?= date('Y-m-d') ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="expense_user" class="form-label">If Any Employee*</label>
                            <select id="expense_user" name="expense_user" class="form-control" required>
                                <option value="">Select Employee</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user->UserID ?>"><?= $user->FirstName . ' ' . $user->LastName ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="expense_section" class="form-label">If Any Department/Section*</label>
                            <select id="expense_section" name="expense_section" class="form-control" required>
                                <option value="">Select Section</option>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?= $section->employeeSectionId ?>"><?= $section->employeeSectionName ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Payment Method -->
                        <div class="col-md-6 mb-3">
                            <label for="payment_method" class="form-label">Payment Method*</label>
                            <select class="form-control" id="payment_method" name="payment_method" onchange="if(this.value === 'cheque') { $('.cheque-fields').show(); } else { $('.cheque-fields').hide(); }" required>
                                <option value="">Select Method</option>
                                <option value="cash" selected>Cash</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3 cheque-fields" style="display:none;">
                            <label for="cheque_date" class="form-label">Cheque Date</label>
                            <input type="date" class="form-control" id="cheque_date" name="cheque_date" placeholder="Cheque Date">
                        </div>

                        <!-- Description -->
                        <div class="col-12 mb-3">
                            <label for="description" class="form-label">Remarks / Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                        </div>
                    </div>

                    <!-- Footer Buttons -->
                    <div class="col-12">
                        <div class="hstack gap-2 justify-content-end">
                            <button type="button" class="btn btn-success" id="saveExpenseBtn">Save Expense</button>
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>

                <div id="expenseError" class="mt-3 text-danger errorDiv" style="display:none;"></div>
            </div>
        </div>
    </div>
</div>
