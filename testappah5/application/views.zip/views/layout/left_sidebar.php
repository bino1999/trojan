<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <a href="<?php echo base_url(); ?>dashboard" class="logo logo-dark">
            <span class="logo-sm">
                <img src="<?php echo base_url(); ?>assets/images/logo-sm.png" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="<?php echo base_url(); ?>assets/images/logo-dark.png" alt="Logo" height="17">
            </span>
        </a>
        <!-- Light Logo-->
        <a href="<?php echo base_url(); ?>dashboard" class="logo logo-light">
            <span class="logo-sm">
                <img src="<?php echo base_url(); ?>assets/images/logo-sm.png" alt="" height="32">
            </span>
            <span class="logo-lg">
                <img src="<?php echo base_url(); ?>assets/images/logo-light.png" alt="" height="37">
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span data-key="t-menu">Menu</span></li>

                <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'dashboard') ? 'active' : ''; ?>"
                        href="<?php echo base_url('dashboard'); ?>">
                        <i class="fa fa-home"></i> <span data-key="t-dashboards">Dashboard</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Quick Bill') ? 'active' : ''; ?>"
                        href="#QuickBillPanel"
                        data-bs-toggle="collapse"
                        role="button"
                        aria-expanded="<?php echo (isset($mainMenuName) && $mainMenuName == 'Quick Bill') ? 'true' : 'false'; ?>"
                        aria-controls="QuickBillPanel">
                        <i class="fa fa-clone"></i> <span data-key="t-base-ui">Quick Bill</span>
                    </a>

                    <div class="collapse menu-dropdown mega-dropdown-menu <?php echo (isset($mainMenuName) && $mainMenuName == 'Quick Bill') ? 'show' : ''; ?>" id="QuickBillPanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('quick-bill'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'quick-bill') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Quick Bill</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('quick-bill-list'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'quick-bill-list') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Quick Bill List</a>
                                    </li>                                  
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>




                <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Services Manager') ? 'active' : ''; ?>"
                        href="#servicesPanel"
                        data-bs-toggle="collapse"
                        role="button"
                        aria-expanded="<?php echo (isset($mainMenuName) && $mainMenuName == 'Services Manager') ? 'true' : 'false'; ?>"
                        aria-controls="servicesPanel">
                        <i class="fa fa-cogs"></i> <span data-key="t-base-ui">Services Job</span>
                    </a>

                    <div class="collapse menu-dropdown mega-dropdown-menu <?php echo (isset($mainMenuName) && $mainMenuName == 'Services Manager') ? 'show' : ''; ?>" id="servicesPanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-manage?status=0'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '0') ? 'active' : ''; ?>"
                                            data-key="t-alerts">New Job</a>
                                    </li>

                                    <li class="nav-item d-none">
                                        <a href="<?php echo base_url('services-manage?status=0'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '0') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Pending Job</a>
                                    </li> 

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-manage?status=1'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '1') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Ongoing Job</a>
                                    </li> 
                                    
                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-manage?status=4'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '4') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Completed Job</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-manage?status=2'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '2') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Hold Job</a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-manage?status=3'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == '3') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Cancelled Job</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </li>



                <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Manager Approval') ? 'active' : ''; ?>"
                            href="<?php echo base_url('services-manage?status=4&manager=yes'); ?>"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-list"></i> <span data-key="t-users">Manager Approval</span>
                        </a>
                    </li>



                <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Invoices') ? 'active' : ''; ?>"
                            href="<?php echo base_url('services-manage?status=5'); ?>"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-list"></i> <span data-key="t-users">Invoices</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Payments') ? 'active' : ''; ?>"
                            href="<?php echo base_url('payments'); ?>"
                            role="button"
                            aria-controls="payments">
                            <i class="fa fa-credit-card"></i> <span data-key="t-users">Payments</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Expenses') ? 'active' : ''; ?>"
                            href="<?php echo base_url('expenses-manage'); ?>"
                            role="button"
                            aria-controls="Expenses">
                            <i class="fa fa-bookmark"></i> <span data-key="t-users">Expenses</span>
                        </a>
                    </li>


                              

                <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Customers') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>customers"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-users"></i> <span data-key="t-users">Customers</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Vehicles') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>vehicles"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-car"></i> <span data-key="t-users">Vehicles</span>
                        </a>
                    </li>


                    

                    <!--

                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Invoices') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>invoices"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-list"></i> <span data-key="t-users">Invoices</span>
                        </a>
                    </li> -->


                    <li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">General</span></li>

                    

                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Supplier') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>supplier"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-shopping-bag"></i> <span data-key="t-users">Supplier</span>
                        </a>
                    </li>


                    <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Purchase Order') ? 'active' : ''; ?>"
                        href="#purchasePanel"
                        data-bs-toggle="collapse"
                        role="button"
                        aria-expanded="<?php echo (isset($mainMenuName) && $mainMenuName == 'Purchase Order') ? 'true' : 'false'; ?>"
                        aria-controls="purchasePanel">
                        <i class="fa fa-cart-plus"></i> <span data-key="t-base-ui">Purchase Order</span>
                    </a>

                    <div class="collapse menu-dropdown mega-dropdown-menu <?php echo (isset($mainMenuName) && $mainMenuName == 'Purchase Order') ? 'show' : ''; ?>" id="purchasePanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('purchase-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'purchase-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Purchase</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('purchase-history-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'purchase-history-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Purchase History</a>
                                    </li> 
                                    
                                    <li class="nav-item">
                                        <a href="<?php echo base_url('item-stock'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'item-stock') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Stock</a>
                                    </li> 

                                </ul>
                            </div>
                        </div>
                    </div>
                </li>



                <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Products') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>products"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-product-hunt"></i> <span data-key="t-users">Products</span>
                        </a>
                    </li>


                <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'Service Packages') ? 'active' : ''; ?>"
                        href="#servicePanel"
                        data-bs-toggle="collapse"
                        role="button"
                        aria-expanded="<?php echo (isset($mainMenuName) && $mainMenuName == 'Service Packages') ? 'true' : 'false'; ?>"
                        aria-controls="servicePanel">
                        <i class="fa fa-sliders"></i> <span data-key="t-base-ui">Service Packages</span>
                    </a>

                    <div class="collapse menu-dropdown mega-dropdown-menu <?php echo (isset($mainMenuName) && $mainMenuName == 'Service Packages') ? 'show' : ''; ?>" id="servicePanel">
                        <div class="row">
                            <div class="col-lg-4">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-items-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'services-items-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Service Items</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('services-packages-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'service-packages-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Service  Packages</a>
                                    </li>                             

                                </ul>
                            </div>
                        </div>
                    </div>
                </li>

                <li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">Master Files</span></li>


                <?php
                $permissions = $this->session->userdata('permissions');
                if (is_array($permissions) && in_array(1, $permissions)) {
                ?>
                    <li class="nav-item">
                        <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'members') ? 'active' : ''; ?>"
                            href="<?php echo base_url(); ?>system-user-manage"
                            role="button"
                            aria-controls="sidebaruserss">
                            <i class="fa fa-user"></i> <span data-key="t-users">Members</span>
                        </a>
                    </li>
                <?php
                }
                ?>

                <!-- Settings Menu -->
                <li class="nav-item">
                    <a class="nav-link menu-link <?php echo (isset($mainMenuName) && $mainMenuName == 'settings') ? 'active' : ''; ?>"
                        href="#sidebarUI"
                        data-bs-toggle="collapse"
                        role="button"
                        aria-expanded="<?php echo (isset($mainMenuName) && $mainMenuName == 'settings') ? 'true' : 'false'; ?>"
                        aria-controls="sidebarUI">
                        <i class="fa fa-cog"></i> <span data-key="t-base-ui">Settings</span>
                    </a>

                    <div class="collapse menu-dropdown mega-dropdown-menu <?php echo (isset($mainMenuName) && $mainMenuName == 'settings') ? 'show' : ''; ?>" id="sidebarUI">
                        <div class="row">
                            <div class="col-lg-4">
                                <ul class="nav nav-sm flex-column">

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('category-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'category-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Item Categories</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('brand-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'brand-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Item Brands</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('vehicle-category-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'vehicle-category-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Vehicle Categories</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('vehicle-brand-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'vehicle-brand-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Vehicle Brands</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('expenses-category-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'expenses-category-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Expenses Category</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('employee-section-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'employee-section-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">Employee Section</a>
                                    </li>

                                    <li class="nav-item">
                                        <a href="<?php echo base_url('system-role-manage'); ?>"
                                            class="nav-link <?php echo (isset($subMenuName) && $subMenuName == 'system-role-manage') ? 'active' : ''; ?>"
                                            data-key="t-alerts">System Access Level</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </li>


            </ul>
        </div>
    </div>


    <div class="sidebar-background"></div>
</div>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Rest in fooer page -->