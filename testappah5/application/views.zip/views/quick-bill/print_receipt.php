<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Receipt - Bill #<?= str_pad($bill[0]->quick_bill_id, 4, '0', STR_PAD_LEFT) ?></title>
    <style>
        /* Base Styles for 76mm Printer */
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.2;
            color: #000;
            background-color: #fff;
            margin: 0;
            padding: 2mm;
            width: 76mm;
        }

        @page {
            size: 76mm auto;
            margin: 0;
        }

        /* Header Section */
        .company-header {
            text-align: center;
            margin-bottom: 2mm;
            padding-bottom: 2mm;
            border-bottom: 1px dashed #000;
        }

        .company-logo {
            max-width: 50%;
            margin: 10px 0;
        }

        .company-name {
            font-size: 14px;
            font-weight: bold;
            margin: 0;
            padding: 0;
        }

        .company-details {
            font-size: 10px;
            margin: 1mm 0 0 0;
        }

        /* Invoice Header */
        .invoice-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3mm;
            font-size: 11px;
        }

        .invoice-title {
            font-size: 13px;
            font-weight: bold;
            margin: 0;
        }

        /* Customer Info */
        .customer-info {
            margin-bottom: 3mm;
            font-size: 11px;
        }

        .info-row {
            display: flex;
            margin-bottom: 1mm;
        }

        .info-label {
            font-weight: bold;
            min-width: 110px;
        }

        /* Items List */
        .items-list {
            width: 100%;
            margin-bottom: 3mm;
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
            padding: 2mm 0;
        }

        .item-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1mm;
        }

        .item-desc {
            flex: 2;
        }

        .item-qty {
            flex: 0.5;
            text-align: center;
        }

        .item-price {
            flex: 1;
            text-align: right;
        }

        .item-total {
            flex: 1;
            text-align: right;
            font-weight: bold;
        }

        /* Summary Section */
        .summary {
            width: 100%;
            margin-bottom: 3mm;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1mm;
        }

        .summary-label {
            font-weight: bold;
        }

        .total-row {
            font-weight: bold;
            border-top: 1px dashed #000;
            padding-top: 1mm;
            margin-top: 1mm;
        }

        /* Footer */
        .footer {
            font-size: 10px;
            text-align: center;
            border-top: 1px dashed #000;
            padding-top: 2mm;
        }

        /* Barcode styling */
        .barcode {
            margin: 2mm 0;
            font-family: monospace;
            font-weight: bold;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <!-- Company Header -->
        <div class="company-header">
            <img src="<?= $logo_url ?>" alt="Logo" class="company-logo" />
            <h1 class="company-name"><?= $shop_name ?></h1>
            <p class="company-details">
                    No 664/1, Yatihena, Malwana, Biyagama<br>
                    Phone: (011) 2 99 68 68 | Hotline: 075 500 500 9 | Email: info@trojaautohub.com<br>
                </p>
        </div>

        <!-- Invoice Header -->
        <div class="invoice-header">
            <div>
                <h2 class="invoice-title">RECEIPT</h2>
            </div>
            <div>
                <div>#<?= str_pad($quick_bill_id, 4, '0', STR_PAD_LEFT) ?></div>
                <div>
                    <?= isset($bill[0]->created_at) && $bill[0]->created_at
    ? date('d/m/Y H:i', strtotime($bill[0]->created_at))
    : 'N/A' ?>

                </div>
            </div>
        </div>

        <!-- Customer Info -->
        <div class="customer-info">
            <div class="info-row">
                <span class="info-label">Customer</span>: <?= htmlspecialchars($bill[0]->customer_name ?? 'Walk-in') ?>
            </div>
            <?php if (!empty($bill[0]->payment_method)): ?>
            <div class="info-row">
                <span class="info-label">Paid Via</span>: <?= htmlspecialchars($bill[0]->payment_method) ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Items List -->
        <div class="items-list">
            <?php if (!empty($items)): ?>
    <?php foreach ($items as $item): ?>
        <div class="item-row">
            <div class="item-desc"><?= htmlspecialchars($item->item_name) ?></div>
            <div class="item-qty"><?= $item->quantity  ?></div>
            <div class="item-price"><?= number_format($item->price, 2) ?></div>
            <div class="item-total"><?= number_format($item->total_price, 2) ?></div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="item-row"><em>No items found</em></div>
<?php endif; ?>



           <?php if (!empty($billData->discount_percent) || !empty($billData->discount_amount)): ?>
                <div class="summary-row">
                    <div class="summary-label">
                        Discount
                        <?php if (!empty($billData->discount_percent)): ?>
                            (<?= htmlspecialchars($billData->discount_percent) ?>%)
                        <?php endif; ?>:
                    </div>
                    <div>- <?= number_format($billData->discount_amount, 2) ?></div>
                </div>
           <?php endif; ?>
        </div>

        <!-- Summary Section -->
        <div class="summary">
            <div class="summary-row">
                <div class="summary-label">Subtotal:</div>
                <div><?= number_format($bill[0]->subtotal ?? $bill[0]->final_bill_amount ?? 0, 2) ?></div>
            </div>
            <?php 
            $discountPercent = $bill[0]->discount_percent ?? 0;
            $discountAmount = $bill[0]->discount_amount ?? 0;

            if ($discountPercent > 0 && $discountAmount == 0) {
                $discountAmount = ($bill[0]->subtotal ?? $bill[0]->final_bill_amount ?? 0) * $discountPercent / 100;
            }

            if ($discountPercent > 0 || $discountAmount > 0): ?>
            <div class="summary-row">
                <div class="summary-label">Discount (<?= $discountPercent ?>%):</div>
                <div>- <?= number_format($discountAmount, 2) ?></div>
            </div>
            <?php endif; ?>
            <div class="summary-row total-row">
                <div class="summary-label">Total:</div>
                <div><?= number_format($bill[0]->final_bill_amount ?? 0, 2) ?></div>
            </div>
            <?php if (isset($bill[0]->total_paid)): ?>
            <div class="summary-row">
                <div class="summary-label">Paid:</div>
                <div><?= number_format($bill[0]->total_paid, 2) ?></div>
            </div>
            <?php endif; ?>
            <?php if (isset($bill[0]->total_balance)): ?>
            <div class="summary-row total-row">
                <div class="summary-label">Balance:</div>
                <div><?= number_format($bill[0]->total_balance, 2) ?></div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="footer">
            <div>Thank you for your business!</div>
            <div class="barcode">* <?= str_pad($bill[0]->quick_bill_id, 4, '0', STR_PAD_LEFT) ?> *</div>
            <div>www.yourshopwebsite.com</div>
        </div>
    </div>
</body>
</html>
