<table id="table1" class="table table-striped table-responsive">
<thead class="table-info">
    <tr>
        <th>##</th>
        <th>Bill ID</th>
        <th>Customer</th>
        <th>Date</th>
        <th>Type</th>
        <th>Amount</th>
        <th>Paid</th>
        <th>Balance</th>
        <th>User</th>
        <th>Print</th>
    </tr>
</thead>

     
<tbody>
<?php
$no = 1;
foreach ($quickBills as $bill) { ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= str_pad($bill->quick_bill_id, 4, '0', STR_PAD_LEFT) ?></td>
        <td>
            <?php if ($bill->customer_id == 0): ?>
                <span class="badge bg-secondary">W-C</span>
            <?php endif; ?>  
            <?= htmlspecialchars($bill->customer_name ?? '') ?>
        </td>
        <td><?= date('Y-m-d', strtotime($bill->created_at)); ?></td>

        <td>Quick Bill</td> <!-- You can add a type field if needed -->
        <td class="text-end"><?= number_format($bill->final_bill_amount ?? 0, 2) ?></td>
        <td class="text-end"><?= number_format($bill->total_paid ?? 0, 2) ?></td>
        <td class="text-end">
            <?= number_format($bill->total_balance ?? 0, 2) ?>
            <?php if ($bill->total_balance > 0): ?>
                <span class="badge bg-danger">Due</span>
            <?php endif; ?>
        </td>
        <td><?= $bill->created_by; ?></td>
        <td>
            <div class="d-flex gap-2">
                <a class="btn btn-secondary btn-sm" target="_blank" style="width: 100%;" href="<?= base_url('quick_bill/print_receipt/' .$bill->quick_bill_id) ?>">
                    <i class="fa fa-print"></i>
                </a>
            </div>
        </td>
    </tr>
<?php } ?>
</tbody>
</table>

<script>
    $(document).ready(function() {
        $('#table1').DataTable({
            "pageLength": 25,
            "lengthMenu": [25, 50, 100, 200],
            "language": {
                "search": "Search:",
                "lengthMenu": "Show _MENU_ entries",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "No entries available",
                "infoFiltered": "(filtered from _MAX_ total entries)"
            }
        });
    });
</script>