<?php if (empty($cart)) : ?>
    <p>No items in the cart.</p>
<?php else : ?>
    <table id="productsTable" class="table table-striped">
        <thead class="table-info">
            <tr>
                <th>#</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Discount</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cart as $index => $item) : ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= ucfirst($item['product_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><?= number_format($item['unit_price'], 2) ?></td>
                    <td>
                        <?= $item['discount_percent'] > 0
                            ? $item['discount_percent'] . '%'
                            : '' . number_format($item['discount_amount'], 2) ?>
                    </td>
                    <td><?= number_format($item['total'], 2) ?></td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="deleteCartItem(<?= $index ?>)">
                            <i class="fa fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="5" class="text-end">Total</th>
                <th colspan="2">Rs. <?= number_format($total, 2) ?></th>
            </tr>
        </tfoot>
    </table>

    <div class="row mt-3">
        <div class="col-md-5">
            <label for="customer">Select Customer:</label>
            <select class="form-control" id="customer">
                <option value="">Select</option>
                <option value="0" selected>Walk-in Customer</option>
                <?php if (empty($customers)) : ?>
                    <option value="">No customers available</option>
                <?php endif; ?>
                <?php foreach ($customers as $cust) : ?>
                    <option value="<?= $cust->customers_id ?>"><?= ucfirst($cust->name) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="paymentMethod">Payment Method:</label>
            <select class="form-control" id="paymentMethod">
                <?php foreach ($payment_methods as $method) : ?>
                    <option value="<?= $method ?>"><?= $method ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="paidAmount">Paid Amount:</label>
            <input type="number" class="form-control" id="paidAmount" value="<?= $total ?>" name="paidAmount">
        </div>
    </div>

    <!-- Hidden fields shown only when payment is not cash -->
    <div class="row mt-3" id="additionalPaymentFields" style="display: none;">
        <div class="col-md-4">
            <label for="cardOrChequeNo">Card / Cheque No:</label>
            <input type="text" class="form-control" id="cardOrChequeNo" name="cardOrChequeNo">
        </div>

        <div class="col-md-4">
            <label for="chequeDate">Cheque Date:</label>
            <input type="date" class="form-control" id="chequeDate" name="chequeDate">
        </div>

        <div class="col-md-4">
            <label for="bankName">Bank Name:</label>
            <input type="text" class="form-control" id="bankName" name="bankName">
        </div>
    </div>


    <div class="row mt-3" id="additionalPaymentFields">
        <div class="col-md-12">
            <label for="note">Note:</label>
            <input type="text" class="form-control" id="note" name="note">
        </div>
    </div>

    <div class="row mt-3 mx-1" id="errorDiv"></div>

    <div class="text-end mt-3">
        <button class="btn btn-success" onclick="completeBill()">Complete Bill</button>
    </div>
<?php endif; ?>



<script>
    $(document).ready(function() {
        $('#paymentMethod').on('change', function() {
            const method = $(this).val().toLowerCase();
            if (method !== 'cash') {
                $('#additionalPaymentFields').slideDown();
            } else {
                $('#additionalPaymentFields').slideUp();
                // Optional: clear fields if hidden
                $('#cardOrChequeNo').val('');
                $('#chequeDate').val('');
                $('#bankName').val('');
            }
        });
    });
</script>