<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Service Packages Management</h4>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card mainCard">
            <div class="card-header d-flex justify-content-between">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#packageModal">
                    <i class="fa fa-plus"></i> Add New Package
                </button>
            </div>
            <div class="card-body">
                <div id="packagesTable"></div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="packageModal" tabindex="-1" aria-labelledby="packageModalLabel" aria-hidden="true">
    <div class="modal-dialog zoomIn modal-xl">
        <div class="modal-content">
            <form id="packageForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="packageModalLabel">Add Service Package</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-danger" id="packageError" style="display:none;"></div>
                    <input type="hidden" id="package_id" name="package_id" value="">

                    <div class="mb-3">
                        <label class="form-label">Package Name *</label>
                        <input type="text" class="form-control" id="package_name" name="package_name" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Select Service Items *</label>
                        <div class="row">
                            <div class="col-md-12">
                                <table id="table1" class="table table-striped table-responsive">
                                    <thead class="table-info">
                                        <tr>
                                            <th scope="col">Service Items</th>
                                            <th scope="col">Original Price</th>
                                            <th scope="col">Discount Type</th>
                                            <th scope="col">Discount Value</th>
                                            <th scope="col">Final Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($items as $item): ?>
                                            <tr class="item-row" data-item-id="<?= $item->id ?>">
                                                <td>
                                                    <div class="form-check">
                                                        <input class="form-check-input item-checkbox"
                                                            type="checkbox"
                                                            name="item_ids[]"
                                                            value="<?= $item->id ?>"
                                                            data-price="<?= $item->price ?>"
                                                            id="item<?= $item->id ?>">
                                                        <label class="form-check-label" for="item<?= $item->id ?>">
                                                            <?= htmlspecialchars($item->name) ?>
                                                        </label>
                                                    </div>
                                                </td>
                                                <td class="original-price">LKR <?= number_format($item->price, 2) ?></td>
                                                <td>
                                                    <select class="form-select discount-type" name="discount_type[<?= $item->id ?>]" disabled>
                                                        <option value="none">No Discount</option>
                                                        <option value="percentage">Percentage</option>
                                                        <option value="fixed">Fixed Amount</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control discount-value" 
                                                        name="discount_value[<?= $item->id ?>]" 
                                                        min="0" step="0.01" disabled>
                                                </td>
                                                <td class="final-price">LKR <?= number_format($item->price, 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Total Price:</label>
                        <h4>LKR <span id="totalPrice">0.00</span></h4>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="savePackageBtn">Save Package</button>
                    <button type="submit" class="btn btn-success d-none" id="updatePackageBtn">Update Package</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script>
   $(document).ready(function() {
    // Load packages when page loads
    loadServicePackages();

    // Enable/disable discount fields when checkbox is toggled
    $(document).on('change', '.item-checkbox', function() {
        const $row = $(this).closest('tr');
        const isChecked = $(this).is(':checked');
        
        // Toggle discount fields
        $row.find('.discount-type, .discount-value').prop('disabled', !isChecked);
        
        // Reset discount fields if unchecked
        if (!isChecked) {
            $row.find('.discount-type').val('none');
            $row.find('.discount-value').val('');
        }
        
        // Recalculate prices
        calculateItemPrice($row);
        calculateTotalPrice();
    });


    $(document).on('click', '.toggle-package', function(e) {
        e.preventDefault();
        const packageId = $(this).data('id');
        const currentStatus = $(this).data('status');
        toggleServicePackage(packageId, currentStatus);
    });

    // Calculate price when discount fields change
    $(document).on('change input', '.discount-type, .discount-value', function() {
        const $row = $(this).closest('tr');
        calculateItemPrice($row);
        calculateTotalPrice();
    });

    // Calculate price for individual item
    function calculateItemPrice($row) {
        const originalPrice = parseFloat($row.find('.item-checkbox').data('price'));
        const discountType = $row.find('.discount-type').val();
        const discountValue = parseFloat($row.find('.discount-value').val()) || 0;
        
        let finalPrice = originalPrice;
        
        if (discountType === 'percentage' && discountValue > 0) {
            // Apply percentage discount
            finalPrice = originalPrice - (originalPrice * discountValue / 100);
        } else if (discountType === 'fixed' && discountValue > 0) {
            // Apply fixed amount discount
            finalPrice = originalPrice - discountValue;
            // Ensure price doesn't go negative
            if (finalPrice < 0) finalPrice = 0;
        }
        
        // Update displayed final price
        $row.find('.final-price').text('LKR ' + finalPrice.toFixed(2));
    }

    // Calculate total price of all selected items
    function calculateTotalPrice() {
        let total = 0;
        
        $('.item-checkbox:checked').each(function() {
            const finalPriceText = $(this).closest('tr').find('.final-price').text().replace('LKR ', '');
            total += parseFloat(finalPriceText);
        });
        
        $('#totalPrice').text(total.toFixed(2));
    }

    // Form submission for saving package
    $('#packageForm').submit(function(e) {
        e.preventDefault();

        const packageId = $('#package_id').val();
        
        // Validate at least one item is selected
        if ($('.item-checkbox:checked').length === 0) {
            $('#packageError').html('Please select at least one service item.').show();
            return;
        }

        // Validate discount values
        let valid = true;
        $('.item-checkbox:checked').each(function() {
            const $row = $(this).closest('tr');
            const discountType = $row.find('.discount-type').val();
            const discountValue = parseFloat($row.find('.discount-value').val()) || 0;
            
            // Validate discount value is provided if discount type is selected
            if (discountType !== 'none' && discountValue <= 0) {
                valid = false;
                $row.find('.discount-value').addClass('is-invalid');
            } else {
                $row.find('.discount-value').removeClass('is-invalid');
            }
            
            // Validate percentage doesn't exceed 100%
            if (discountType === 'percentage' && discountValue > 100) {
                valid = false;
                $row.find('.discount-value').addClass('is-invalid');
            }
        });

        if (!valid) {
            $('#packageError').html('Please enter valid discount values.').show();
            return;
        }

        // Collect item data with discounts
        const items = [];
        $('.item-checkbox:checked').each(function() {
            const $row = $(this).closest('tr');
            items.push({
                item_id: $(this).val(),
                discount_type: $row.find('.discount-type').val(),
                discount_value: $row.find('.discount-value').val() || 0
            });
        });

        // Prepare data for AJAX
        const formData = {
            package_name: $('#package_name').val(),
            items: items
        };

        // Include package ID if editing
        if (packageId) {
            formData.package_id = packageId;
        }

        // Determine which button was clicked
        const isUpdate = $('#updatePackageBtn').is(':visible');
        const url = isUpdate ? "<?= site_url('services/updateServicePackage') ?>" : "<?= site_url('/saveServicePackage') ?>";
        const buttonId = isUpdate ? '#updatePackageBtn' : '#savePackageBtn';

        // Submit via AJAX
        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            dataType: "json",
            beforeSend: function() {
                $(buttonId).prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Processing...');
            },
            success: function(response) {
                if (response.status === 'success') {
                    $('#packageModal').modal('hide');
                    loadServicePackages();
                    showToast(response.message, 'success');
                } else {
                    $('#packageError').html(response.message).show();
                }
            },
            error: function(xhr, status, error) {
                $('#packageError').html('An error occurred. Please try again.').show();
            },
            complete: function() {
                $(buttonId).prop('disabled', false).html(isUpdate ? 'Update Package' : 'Save Package');
            }
        });
    });

    // Reset modal when closed
    $('#packageModal').on('hidden.bs.modal', function() {
        $('#packageForm')[0].reset();
        $('#packageError').hide();
        $('.item-checkbox').prop('checked', false);
        $('.discount-type').val('none').prop('disabled', true);
        $('.discount-value').val('').prop('disabled', true);
        $('.final-price').each(function() {
            const originalPrice = $(this).data('original');
            $(this).text('LKR ' + parseFloat(originalPrice).toFixed(2));
        });
        $('#totalPrice').text('0.00');
        $('#savePackageBtn').removeClass('d-none');
        $('#updatePackageBtn').addClass('d-none');
    });

    // Load service packages into table
    function loadServicePackages() {
        $.ajax({
            url: "<?= site_url('services/loadServicePackages') ?>",
            type: "GET",
            success: function(data) {
                $('#packagesTable').html(data);
            },
            error: function() {
                showToast('Error loading packages', 'error');
            }
        });
    }

    // Edit package
    $(document).on('click', '.edit-package', function() {
        const packageId = $(this).data('id');
        editServicePackage(packageId);
    });

    function editServicePackage(packageId) {
        alert(packageId);
        $.ajax({
            url: "<?= site_url('services/getServicePackageItem/') ?>" + packageId,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.error) {
                    showToast(response.error, 'error');
                    return;
                }

                // Set package info
                $('#package_id').val(packageId);
                $('#package_name').val(response.package_name);

                // Clear all selections first
                $('.item-checkbox').prop('checked', false);
                $('.discount-type').val('none').prop('disabled', true);
                $('.discount-value').val('').prop('disabled', true);

                // Set selected items and their discounts
                response.items.forEach(function(item) {
                    const $row = $(`tr[data-item-id="${item.item_id}"]`);
                    $row.find('.item-checkbox').prop('checked', true);
                    $row.find('.discount-type').val(item.discount_type || 'none').prop('disabled', false);
                    $row.find('.discount-value').val(item.discount_value || '').prop('disabled', false);
                    
                    // Calculate initial prices
                    calculateItemPrice($row);
                });

                // Calculate total
                calculateTotalPrice();

                // Toggle buttons
                $('#savePackageBtn').addClass('d-none');
                $('#updatePackageBtn').removeClass('d-none');
                
                // Show modal
                $('#packageModal').modal('show');
            },
            error: function(xhr, status, error) {
                showToast('Error loading package details', 'error');
            }
        });
    }

    // Delete package
    $(document).on('click', '.delete-package', function() {
        const packageId = $(this).data('id');
        deleteServicePackage(packageId);
    });



    // Open modal for new package
    $(document).on('click', '#addNewPackage', function() {
        openNewPackageModal();
    });

    function openNewPackageModal() {
        $('#packageForm')[0].reset();
        $('#package_id').val('');
        $('.item-checkbox').prop('checked', false);
        $('.discount-type').val('none').prop('disabled', true);
        $('.discount-value').val('').prop('disabled', true);
        $('.final-price').each(function() {
            const originalPrice = $(this).data('original');
            $(this).text('LKR ' + parseFloat(originalPrice).toFixed(2));
        });
        $('#totalPrice').text('0.00');
        $('#packageError').hide();
        $('#savePackageBtn').removeClass('d-none');
        $('#updatePackageBtn').addClass('d-none');
        $('#packageModal').modal('show');
    }

    // Helper function to show toast messages
    function showToast(message, type = 'success') {
        const className = type === 'success' ? 'toastify-success' : 
                         type === 'error' ? 'toastify-error' : 'toastify-info';
        
        Toastify({
            text: message,
            className: className,
            duration: 3000
        }).showToast();
    }
});
</script>