<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Purchase Orders</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Purchase Orders</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">

        <style>
            .mainCard {
                margin: -10px;
            }
        </style>

        <div class="card mainCard">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-2">
                        <input type="date" name="sdate" id="sdate" class="form-control" value="<?= date('Y-m-d', strtotime('-1 month')); ?>">
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="edate" id="edate" class="form-control" value="<?= date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6">
                        <button class="btn btn-primary" onclick="loadPurchases();">Load Purchase Orders</button>
                    </div>

                    <div class="col-md-2">
                        <button class="btn btn-success waves-effect waves-light" onclick="openAddPurchaseModal()"><i class="fa fa-plus"></i> New Purchase Order</button>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div id="purchaseTable"></div>
            </div>
        </div>
    </div>
    <!--end col-->
</div>


<!-- Add Purchase Modal -->
<div class="modal fade" id="addPurchaseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form id="purchaseForm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">New Purchase</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">

                    <div class="mb-3">
                        <label>Supplier</label>
                        <select class="form-control" name="supplier_id" required>
                            <option value="">-- Select Supplier --</option>
                            <?php foreach ($suppliers as $supplier) : ?>
                                <option value="<?= $supplier->supplier_id ?>"><?= $supplier->name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label>Bill No</label>
                        <input type="text" name="bill_no" class="form-control" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Bill Date</label>
                        <input type="date" name="bill_date" class="form-control" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Payment Method</label>
                        <select name="payment_method" class="form-control" required>
                            <option value="">Payment Method --</option>
                            <option value="cash">Cash</option>
                            <option value="cheque">Cheque</option>
                        </select>
                    </div>
                </div>


                    <div class="row">
                    <div class="col-md-6 mb-3">
    <label>VAT Type</label>
    <select name="vat_type" id="vat_type" class="form-control" required>
        <option value="">Select VAT Type --</option>
        <option value="none">Non-VAT</option>
        <option value="vat">VAT</option>
    </select>
</div>

<div class="col-md-6 mb-3" id="customVatDiv">
    <label>Custom VAT %</label>
    <input type="number" name="vat_percent" id="vat_percent" class="form-control" step="0.01" min="0" placeholder="Enter VAT %" />
</div>
                    </div>


                    <div class="mb-3">
                        <label>Description</label>
                        <textarea name="description" class="form-control"></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Save Purchase</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>





<script>
   
    $(document).ready(function() {

        loadPurchases();

        $('#purchaseForm').submit(function(e) {
    e.preventDefault();
    $.ajax({
        url: "<?= site_url('purchase/createPurchase') ?>",
        method: "POST",
        data: $(this).serialize(),
        dataType: 'json', // important to ensure JSON is parsed automatically
        success: function(response) {
            if (response.status === 'success') {
                $('#addPurchaseModal').modal('hide');
                $('#purchaseForm')[0].reset();
                loadPurchases();
                toastify({
                    text: "Purchase Order created successfully.",
                    className: "toastify-success",
                    duration: 3000,
                    gravity: "top",
                    position: "right"
                }).showToast();
                
            } else {
                Swal.fire('Validation Error', response.message, 'warning');
            }
        },
        error: function(xhr, status, error) {
            Swal.fire('Error!', 'Something went wrong. Please try again.', 'error');
            console.error("AJAX Error:", status, error);
        }
    });
});

    });

    function loadPurchases() {
        let sdate = $('#sdate').val();
        let edate = $('#edate').val();
        $.ajax({
            url: "<?php echo site_url('purchase/loadPurchases') ?>",
            type: "POST",
            data: {
                sdate: sdate,
                edate: edate
            },
            success: function(data) {
                $('#purchaseTable').html(data);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR.responseText);
            }
        });
    }


    function openAddPurchaseModal() {
        $('#addPurchaseModal').modal('show');
        $('#addPurchaseModal select').select2({
            dropdownParent: $('#addPurchaseModal')
        });
    }

    var currentBillDate = "";
    function openAddItemModal(po_id, supplier_id, supplier_name, bill_no, bill_date) {
        $('#purchaseItemForm')[0].reset();
        currentBillDate = bill_date;

        $('#po_id').val(po_id);
        $('#supplier_id').val(supplier_id);
        $('#supplier_name_div').text('Supplier : '+supplier_name);
        $('#purchase_date').val(bill_date);

        $('#addItemModal select').select2({
            dropdownParent: $('#addItemModal')
        });

        // Set the PO ID in the modal title
        //$('#purchaseOrderNoText').text('Add Item to Purchase Order No: ' + po_id);
        $('#purchaseOrderNoText2').text('You are adding items to purchase orer bill no: ' + bill_no);

        $('#addItemModal').modal('show');
        loadPurchaseItems();
    }


    function openViewItemModal(po_id, supplier_id, supplier_name, bill_no, bill_date) {
        $('#purchaseItemForm')[0].reset();

        $('#po_id2').val(po_id);
        $('#supplier_id2').val(supplier_id);
        $('#supplier_name_div2').text('Supplier : '+supplier_name);

        $('#viewItemModal select').select2({
            dropdownParent: $('#viewItemModal')
        });

        // Set the PO ID in the modal title
        //$('#purchaseOrderNoText').text('Add Item to Purchase Order No: ' + po_id);
        $('#purchaseOrderNoText3').text('Purchase Orer Bill No: ' + bill_no);

        $('#viewItemModal').modal('show');
        loadPurchaseItems2();
    }

    function loadPurchaseItems2(){
        let po_id = $('#po_id2').val();
     
        $.ajax({
            url: "<?php echo site_url('purchase/loadPurchaseOrderItems2') ?>",
            type: "POST",
            data: "po_id=" + po_id,
            success: function(data) {
                $('#itemList2').html(data);
            },
            error: function(jXHR, textStatus, errorThrown) {
                console.log(jXHR.responseText);
            }
        });
    }

    function savePurchaseItem() {
        var formData = $('#purchaseItemForm').serialize();
        $.ajax({
            url: "<?php echo site_url('purchase/addItemToPurchaseOrder'); ?>",
            type: "POST",
            data: formData,
            success: function(res) {
                var result = JSON.parse(res);
                if (result.status == 'success') {
                    alert('Item Added Successfully!');
                    $('#addItemModal').modal('hide');
                    // reload items if needed
                    loadPurchaseItems();
                } else {
                    alert('Error saving item');
                }
            }
        });
    }

    function loadPurchaseItems(){
        let po_id = $('#po_id').val();
     
        $.ajax({
            url: "<?php echo site_url('purchase/loadPurchaseOrderItems') ?>",
            type: "POST",
            data: "po_id=" + po_id,
            success: function(data) {
                $('#itemList').html(data);
            },
            error: function(jXHR, textStatus, errorThrown) {
                console.log(jXHR.responseText);
            }
        });
    }

    function setDefaultValues() {
        const productSelect = document.getElementById('product_id');
        const brandInput = document.getElementById('brand_name');
        const categoryInput = document.getElementById('category_name');
        const barcodeInput = document.getElementById('barcode');
        const uomSelect = document.getElementById('uom');
        const reorderLevelInput = document.getElementById('reorder_level');
        const salePriceInput = document.getElementById('sale_price');

        const selectedOption = productSelect.options[productSelect.selectedIndex];

        if (selectedOption.value !== "") {
            // Set values from data attributes
            brandInput.value = selectedOption.getAttribute('data-brand') || '';
            categoryInput.value = selectedOption.getAttribute('data-category') || '';
            barcodeInput.value = selectedOption.getAttribute('data-barcode') || '';
            reorderLevelInput.value = selectedOption.getAttribute('data-reorder_level') || '';
            salePriceInput.value = selectedOption.getAttribute('data-sale_price') || '';

            const measurementUnit = selectedOption.getAttribute('data-measurement_unit') || '';

            // Handle UOM selection
            if (measurementUnit !== '') {
                let matched = false;
                const unitLower = measurementUnit.trim().toLowerCase();

                // Search for matching option (case insensitive)
                for (let i = 0; i < uomSelect.options.length; i++) {
                    if (uomSelect.options[i].value.trim().toLowerCase() === unitLower) {
                        uomSelect.selectedIndex = i;
                        matched = true;
                        break;
                    }
                }

                // If not found, add it as a new option
                if (!matched) {
                    const newOption = document.createElement('option');
                    newOption.value = measurementUnit;
                    newOption.textContent = measurementUnit;
                    uomSelect.appendChild(newOption);
                    uomSelect.value = measurementUnit;
                }

                // Trigger events to update floating label
                uomSelect.dispatchEvent(new Event('change'));
                uomSelect.dispatchEvent(new Event('input'));
            } else {
                uomSelect.selectedIndex = 0; // default to "Select Unit"
            }

            // Disable brand, category, barcode inputs
            brandInput.disabled = true;
            categoryInput.disabled = true;
            barcodeInput.disabled = true;

        } else {
            // If no product selected, clear all fields
            brandInput.value = '';
            categoryInput.value = '';
            barcodeInput.value = '';
            uomSelect.selectedIndex = 0;

            // Enable brand, category, barcode inputs
            brandInput.disabled = false;
            categoryInput.disabled = false;
            barcodeInput.disabled = false;

            // Trigger events to update floating labels
            uomSelect.dispatchEvent(new Event('change'));
            brandInput.dispatchEvent(new Event('input'));
            categoryInput.dispatchEvent(new Event('input'));
            barcodeInput.dispatchEvent(new Event('input'));
        }
    }

    function deletePurchaseItem(po_item_id) {
        $.ajax({
            url: '<?= base_url('purchase/deletePurchaseOrderItem/') ?>' + po_item_id,
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    loadPurchaseItems(); // Refresh table
                    Toastify({
                        text: "Item deleted successfully.",
                        className: "toastify-success",
                        duration: 3000,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error occurred while deleting the item.');
            }
        });
    }

    function completePurchaseOrder(po_id) {
    const grandTotal = $('#grandTotalCell').data('grand');
    
    var po_id = $('#po_id').val();

    Swal.fire({
        title: 'Are you sure?',
        text: "You are about to complete this Purchase Order.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, complete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '<?= base_url('purchase/completePurchaseOrder') ?>',
                type: 'POST',
                data: {
                    po_id: po_id,
                    grand_total: grandTotal
                },
                success: function(response) {
                    response = JSON.parse(response);
                    if (response.status === 'success') {
                        loadPurchases(); // Refresh table
                        $('#addItemModal').modal('hide');
                        Toastify({
                            text: "Purchase Order completed successfully.",
                            className: "toastify-success",
                            duration: 3000,
                            gravity: "top",
                            position: "right"
                        }).showToast();
                    } else {
                        
                        Toastify({
                            text: response.message,
                            className: "toastify-error",
                            duration: 3000,
                            gravity: "top",
                            position: "right"
                        }).showToast();
                    }
                },
                error: function() {
                    alert('Error occurred while completing the purchase order.');
                }
            });
        }
    });
}
</script>





<div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-xl">
        <div class="modal-content">
            <div class="modal-body">

                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header" style="padding: 3px;">
    <div class="col-lg-12" id="supplier_name_div" style="font-weight: bold; font-size: 1.3em; color:rgb(207, 85, 14);">
                                        </div>
                            </div>
                            <div class="card-body">
                                <form id="purchaseItemForm">
                                    <input type="hidden" name="po_id" id="po_id">
                                    <input type="hidden" name="supplier_id" id="supplier_id">

                                    <div class="row mb-3">
                                        <div class="col-lg-6">
                                            <select name="filter_item_category" id="filter_item_category" class="form-select" onchange="filterProducts();">
                                                    <option value="">Select Category</option>
                                                    <?php foreach ($productCategories as $category) { ?>
                                                        <option value="<?= $category->itemCategoryId ?>"><?= $category->itemCategoryName ?></option>
                                                    <?php } ?>
                                                </select>
                                        </div>
                                        <div class="col-lg-6">
                                            <select name="filter_item_brand" id="filter_item_brand" class="form-select" onchange="filterProducts();">
                                                    <option value="">Select Brand</option>
                                                    <?php foreach ($productBrands as $brand) { ?>
                                                        <option value="<?= $brand->itemBrandId ?>"><?= $brand->itemBrandName ?></option>
                                                    <?php } ?>
                                                </select>
                                        </div>
                                    </div>

                                    <div class="row g-3">
                                        <!-- Product Dropdown -->
                                        <div class="col-lg-8">
                                            <div class="form" id="productSelectDiv">
                                                <select name="product_id" id="product_id" class="form-select" onchange="setDefaultValues();" required>
                                                    <option value="">Select Product</option>
                                                    <?php foreach ($products as $product) { ?>
                                                        <option value="<?= $product->product_id ?>"
                                                        data-brand-id="<?= $product->item_brand_id ?>"
    data-category-id="<?= $product->item_category_id ?>"
                                                            data-brand="<?= $product->brand_name ?>" ,
                                                            data-category="<?= $product->category_name ?>"
                                                            data-measurement_unit="<?= $product->measurement_unit ?>"
                                                            data-sale_price="<?= $product->sale_price ?>"
                                                            data-reorder_level="<?= $product->reorder_level ?>"
                                                            data-barcode="<?= $product->barcode ?>"><?= strtoupper($product->product_name) ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- UOM -->
                                        <div class="col-lg-2">
                                            <div class="form">
                                                <select name="uom" id="uom" class="form-select" required>
                                                    <option value="">Unit</option>
                                                    <option value="kg">Kilogram (kg)</option>
                                                    <option value="g">Gram (g)</option>
                                                    <option value="l">Liter (L)</option>
                                                    <option value="ml">Milliliter (mL)</option>
                                                    <option value="p">Piece</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Inventory Type -->
                                        <div class="col-lg-2">
                                            <div class="form">
                                                <select name="inventory_type" id="inventory_type" class="form-select" required>
                                                    <option value="sale">Sale</option>
                                                    <option value="Internal">Internal Use</option>
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Category -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="text" name="category_name" id="category_name" class="form-control" disabled placeholder="Category">
                                                <label for="brand">Category</label>
                                            </div>
                                        </div>

                                        <!-- Brand Name -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="text" name="brand_name" id="brand_name" class="form-control" disabled placeholder="Brand" required>
                                                <label for="brand_name">Brand Name</label>
                                            </div>
                                        </div>

                                        <!-- Barcode -->
                                         <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="text" name="barcode" id="barcode" class="form-control" disabled placeholder="Barcode">
                                                <label for="Barcode">Barcode</label>
                                            </div>
                                        </div>

                                        <!-- Purchase Date -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="date" name="purchase_date" id="purchase_date" class="form-control" placeholder="Purchase Date" required>
                                                <label for="purchase_date">Purchase Date *</label>
                                            </div>
                                        </div>

                                        <!-- Genuine Checkbox (Separate from floating) -->
                                        <div class="col-lg-6 d-flex align-items-center mt-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="genuine" id="genuine" value="1" checked>
                                                <label class="form-check-label" for="genuine">Genuine</label>
                                            </div>
                                        </div>

                                        <!-- Quantity -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="quantity" id="quantity" class="form-control" placeholder="Quantity" required>
                                                <label for="quantity">Quantity *</label>
                                            </div>
                                        </div>

                                        <!-- Reorder Level -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="reorder_level" id="reorder_level" class="form-control" placeholder="Reorder Level">
                                                <label for="reorder_level">Reorder Level *</label>
                                            </div>
                                        </div>

                                        <!-- Sale Price -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="sale_price" id="sale_price" class="form-control" placeholder="Sale Price" step="0.01" required>
                                                <label for="sale_price">Sale Price *</label>
                                            </div>
                                        </div>

                                        <!-- Company Price -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="company_price" id="company_price" class="form-control" placeholder="Company Price" step="0.01" required>
                                                <label for="company_price">Company Price *</label>
                                            </div>
                                        </div>

                                        <!-- Discount Percent -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="discount_percent" id="discount_percent" class="form-control" placeholder="Discount %" step="0.01">
                                                <label for="discount_percent">Discount %</label>
                                            </div>
                                        </div>

                                        <!-- Discount Amount -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="number" name="discount_amount" id="discount_amount" class="form-control" placeholder="Discount Amount" step="0.01" value="0">
                                                <label for="discount_amount">Discount Amount</label>
                                            </div>
                                        </div>

                                        <!-- Rack No -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="text" name="rack_no" class="form-control" placeholder="Rack No">
                                                <label for="rack_no">Rack No</label>
                                            </div>
                                        </div>

                                        <!-- Bin No -->
                                        <div class="col-lg-4">
                                            <div class="form-floating">
                                                <input type="text" name="bin_no" class="form-control" placeholder="Bin No">
                                                <label for="bin_no">Bin No</label>
                                            </div>
                                        </div>

                                        <!-- Note -->
                                        <div class="col-lg-12">
                                            <div class="form-floating">
                                                <textarea name="note" class="form-control" placeholder="Note" style="height: 60px;"></textarea>
                                                <label for="note">Note</label>
                                            </div>
                                        </div>

                                        <!-- Submit Button -->
                                        <div class="col-lg-12 mt-3">
                                            <div class="text-end">
                                                <button type="button" class="btn btn-primary" id="savePurchaseItemBtn">Add Item</button>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div id="createError" class="text-danger"></div>
                                        </div>

                                    </div>
                                </form>

                            </div>
                        </div>
                    </div><!-- end col -->


                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="card-title mb-0" id="purchaseOrderNoText2">Add Item to Purchase Order No</h6>
                            </div>
                            <div class="card-body">
                                                        <div id="itemList"></div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="viewItemModal" tabindex="-1" aria-labelledby="viewItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-xl">
        <div class="modal-content">
            <div class="modal-body">

                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                            <div class="col-lg-12" id="purchaseOrderNoText3" style="font-weight: bold; font-size: 1.3em; color:rgb(207, 85, 14);"></div>
                            <div class="col-lg-12" id="supplier_name_div2" style="font-weight: bold; font-size: 1.3em; color:rgb(207, 85, 14);"></div>
                            </div>
                            <div class="card-body">
                            <input type="hidden" name="po_id2" id="po_id2">
                            <input type="hidden" name="supplier_id2" id="supplier_id2">
                            <div id="itemList2"></div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<script>
   $(document).ready(function() {
    $('#savePurchaseItemBtn').click(function(e) {
        e.preventDefault();

        const companyPrice = parseFloat($('#company_price').val()) || 0;
        const salePrice = parseFloat($('#sale_price').val()) || 0;
        const discountPercent = parseFloat($('#discount_percent').val()) || 0;
        const discountAmount = parseFloat($('#discount_amount').val()) || 0;
        const quantity = parseFloat($('#quantity').val()) || 0;

        // Validation: Company Price > 0
        if (companyPrice <= 0) {
            Toastify({
                text: 'Company price must be greater than 0.',
                className: "toastify-error",
                duration: 5000,
                close: true,
                gravity: "top",
                position: "right"
            }).showToast();
            return;
        }

        // Validation: Quantity > 0
        if (quantity <= 0) {
            Toastify({
                text: 'Quantity must be greater than 0.',
                className: "toastify-error",
                duration: 5000,
                close: true,
                gravity: "top",
                position: "right"
            }).showToast();
            return;
        }

        // Validation: Sale price >= Company price
        if (salePrice < companyPrice) {
            Toastify({
                text: 'Sale price must not be less than company price.',
                className: "toastify-error",
                duration: 5000,
                close: true,
                gravity: "top",
                position: "right"
            }).showToast();
            return;
        }

        // Validation: Only one discount field allowed
        if (discountPercent > 0 && discountAmount > 0) {
            Toastify({
                text: 'Only one of discount percent or discount amount can be entered.',
                className: "toastify-error",
                duration: 5000,
                close: true,
                gravity: "top",
                position: "right"
            }).showToast();
            return;
        }

        // If all validations pass, proceed with AJAX
        $.ajax({
            url: "<?= base_url('addPurchaseOrderItem'); ?>",
            method: "POST",
            data: $('#purchaseItemForm').serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    $('#purchaseItemForm')[0].reset();
                    $('#purchase_date').val(currentBillDate);
                    // Manually reset disabled fields
                    $('#category_name, #brand_name, #barcode, #reorder_level').val('');
                    $('#product_id, #uom, #inventory_type').val('');

                    $('#createError').html('').show();
                    loadPurchaseItems();
                    Toastify({
                        text: response.message,
                        className: "toastify-success",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                } else {
                    $('#createError').html(response.message).show();
                    Toastify({
                        text: response.message,
                        className: "toastify-error",
                        duration: 5000,
                        close: true,
                        gravity: "top",
                        position: "right"
                    }).showToast();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR.responseText);
            }
        });
    });
});


function deletePurchase(po_id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This will delete the Purchase Order and all its items.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '<?= base_url('purchase/deletePurchase') ?>',
                type: 'POST',
                data: { po_id: po_id },
                success: function (response) {
                    const res = JSON.parse(response);
                    if (res.status === 'success') {
                        Swal.fire('Deleted!', 'The purchase order was deleted.', 'success');
                        loadPurchases();
                    } else {
                        Swal.fire('Error!', res.message, 'error');
                    }
                },
                error: function () {
                    Swal.fire('Error!', 'An error occurred while deleting.', 'error');
                }
            });
        }
    });
}

function filterProducts() {
    let selectedCategory = $('#filter_item_category').val();
    let selectedBrand = $('#filter_item_brand').val();

    $.ajax({
        url: '<?= base_url('purchase/filterProducts') ?>',
        type: 'POST',
        data: { category_id: selectedCategory, brand_id: selectedBrand },
        success: function (response) {
            $('#productSelectDiv').html(response);
            //product select convert to select2
            $('#product_id').select2({
                placeholder: 'Select Product',
                dropdownParent: $('#addItemModal')
            });
        },
        error: function () {
            console.log('Error loading product list.');
        }
    });


}





</script>