<table id="table1" class="table table-striped table-responsive">
    <thead class="table-info">
        <tr>
            <th>#</th>
            <th style="text-align: left;">PO ID</th>
            <th style="text-align: left;">Supplier</th>
            <th style="text-align: left;">Bill No</th>
            <th style="text-align: left;">Bill Date</th>
            <th style="text-align: left;">Payment</th>
            <th style="text-align: center;">Amount</th>
            <th style="text-align: left;">Vat</th>
            <th style="text-align: left;">Total</th>
            <th style="text-align: left;">Description</th>
            
            <th style="text-align: center;">Status</th>
            <th style="text-align: right;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($purchases as $index => $row) { ?>
            <tr>
                <td><?= ($index + 1); ?></td>
                <td><?= $row->po_id; ?></td>
                <td><?= $row->supplier_name; ?></td>
                <td><?= $row->bill_no; ?></td>
                <td><?= $row->bill_date; ?></td>
                <td>
                    <?php
                    if ($row->payment_method == 1) {
                        echo 'Cash';
                    } elseif ($row->payment_method == 2) {
                        echo 'Cheque';
                    } else {
                        echo 'Other';
                    }
                    ?>
                </td>
                <td style="text-align: right;"><?= number_format($row->total_amount, 2); ?></td>
                <td><?= $row->vat_percent > 0 ? 'Yes (' . $row->vat_percent . '%)' : 'No' ?></td>
                <td style="text-align: right;">
                <?php
                if($row->vat_percent > 0) {
                    $total = $row->total_amount - ($row->total_amount * $row->vat_percent / 100);
                } else {
                    $total = $row->total_amount;
                }
                echo number_format($total, 2);
                ?>
                </td>
                <td><?= $row->description; ?></td>
                
                <td style="text-align: center;">
                    <?php if ($row->status == 'Completed') { ?>
                        <span class="badge bg-success">Completed</span>
                    <?php } else { ?>
                        <span class="badge bg-warning">Pending</span>
                    <?php } ?>
                </td>
                <td style="text-align: right;">
                    <button class="btn btn-info btn-sm"
                        onclick="openViewItemModal(<?= $row->po_id ?>, <?= $row->supplier_id ?>, '<?= htmlspecialchars($row->supplier_name, ENT_QUOTES) ?>', '<?= htmlspecialchars($row->bill_no, ENT_QUOTES) ?>', '<?= htmlspecialchars($row->bill_date, ENT_QUOTES) ?>')">
                        <i class="fa fa-search"></i> View
                    </button>

                    <?php if ($row->status != 'Completed') { ?>
                        <button class="btn btn-success btn-sm"
                            onclick="openAddItemModal(<?= $row->po_id ?>, <?= $row->supplier_id ?>, '<?= htmlspecialchars($row->supplier_name, ENT_QUOTES) ?>', '<?= htmlspecialchars($row->bill_no, ENT_QUOTES) ?>', '<?= htmlspecialchars($row->bill_date, ENT_QUOTES) ?>')">
                            + Add Item
                        </button>
                        
                        <button class="btn btn-danger btn-sm" onclick="deletePurchase(<?= $row->po_id ?>)">Delete</button>
                    <?php } ?>
                </td>

            </tr>
        <?php } ?>
    </tbody>
</table>