<?php if (!empty($purchases)) { ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Uni</th>
                    <th>Buying Price</th>
                    <th>Discount</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i = 1;
                $total_no_of_items = 0;
                $grandTotal = 0;
                foreach ($purchases as $item) { 
                    $qty = (float)$item->quantity;
                    $price = (float)$item->company_price;
                    $discountAmount = 0;

                    if ($item->discount_percent > 0) {
                        $discountAmount = ($price * $item->discount_percent) / 100;
                    } elseif ($item->discount_amount > 0) {
                        $discountAmount = (float)$item->discount_amount;
                    }

                    $netPrice = $price - $discountAmount;
                    $lineTotal = $netPrice * $qty;
                    $grandTotal += $lineTotal;
                    $total_no_of_items += 1;

                    ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= strtoupper($item->product_name) ?></td>
                        <td><?= $qty ?></td>
                        <td><?= $item->uom ?></td>
                        <td><?= number_format($price, 2) ?></td>
                        <td>
                            <?php
                            if ($item->discount_percent > 0) {
                                echo $item->discount_percent . '%';
                            } elseif ($item->discount_amount > 0) {
                                echo 'Rs. ' . number_format($item->discount_amount, 2);
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?= number_format($lineTotal, 2) ?></td>
                        <td>
                            <button class="btn btn-sm btn-danger" onclick="deletePurchaseItem(<?= $item->po_item_id ?>)">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
            <tfoot class="table-light fw-bold">
            <tr>
    <td colspan="6" class="text-end">Grand Total</td>
    <td id="grandTotalCell" data-grand="<?= $grandTotal ?>"><?= number_format($grandTotal, 2) ?></td>
    <td></td>
</tr>
            </tfoot>
        </table>
    </div>
<?php } else {
    $total_no_of_items = 0;
     ?>
    <p class="text-muted">No purchase items found.</p>
<?php } ?>







<div class="text-end mt-3">
    <?php if($total_no_of_items > 0) { ?>
        <button type="button" class="btn btn-success" onclick="completePurchaseOrder()" id="completePurchaseOrderBtn">
        Complete Purchase Order</button>
    <?php }else{
        echo '<button type="button" class="btn btn-secondary" disabled>No items to complete</button>';
    } ?>
</div>
