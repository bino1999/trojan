<div class="row mb-3 pb-1">
<div class="col-12">
<div class="d-flex align-items-lg-center flex-lg-row flex-column">
<div class="flex-grow-1">
<h4 class="fs-16 mb-1">Hey, <?php echo $this->session->userdata('name'); ?>!</h4>
</div>
</div>
</div>
</div>






<div class="row">

<div class="col-lg-3 col-md-6">
    <div class="card">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="avatar-sm flex-shrink-0">
                    <span class="avatar-title bg-info rounded fs-3">
                        <i class="mdi mdi-truck-minus-outline"></i>
                    </span>
                </div>
                <div class="flex-grow-1 ms-3">
                    <p class="text-uppercase fw-semibold fs-12 text-muted mb-1">
                        Total Vehicles
                    </p>
                    <h4 class="mb-0">
    <span class="counter-value"><?= !empty($vehicleCount) ? $vehicleCount : '0'; ?></span>
</h4>

                </div>
            </div>
        </div>
    </div>
</div>



<div class="col-lg-3 col-md-6">
<div class="card">
<div class="card-body">
<div class="d-flex align-items-center">
<div class="avatar-sm flex-shrink-0">
<span class="avatar-title bg-warning rounded fs-3">
<i class="bx bx-user-circle"></i>
</span>
</div>
<div class="flex-grow-1 ms-3">
<p class="text-uppercase fw-semibold fs-12 text-muted mb-1">
Total Customers</p>
<h4 class=" mb-0"><span class="counter-value" data-target="10">0</span></h4>
</div>
</div>
</div>
</div>
</div>


<div class="col-lg-3 col-md-6">
<div class="card">
<div class="card-body">
<div class="d-flex align-items-center">
<div class="avatar-sm flex-shrink-0">
<span class="avatar-title bg-success rounded fs-3">
<i class="mdi mdi-car-wrench"></i>
</span>
</div>
<div class="flex-grow-1 ms-3">
<p class="text-uppercase fw-semibold fs-12 text-muted mb-1">
Total Jobs</p>
<h4 class=" mb-0"><span class="counter-value" data-target="10">0</span></h4>
</div>
</div>
</div>
</div>
</div>


<div class="col-lg-3 col-md-6">
<div class="card">
<div class="card-body">
<div class="d-flex align-items-center">
<div class="avatar-sm flex-shrink-0">
<span class="avatar-title bg-primary rounded fs-3">
<i class="mdi mdi-hammer-wrench"></i>
</span>
</div>
<div class="flex-grow-1 ms-3">
<p class="text-uppercase fw-semibold fs-12 text-muted mb-1">
Today Jobs</p>
<h4 class=" mb-0"><span class="counter-value" data-target="10">0</span></h4>
</div>
</div>
</div>
</div>
</div>






</div> 